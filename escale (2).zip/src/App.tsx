import React, { useState, useMemo, useEffect } from 'react';
import { Routes, Route, useNavigate, useLocation } from 'react-router-dom';
import { Header } from './components/Header';
import { HeroSection } from './components/HeroSection';
import { QuizIntroSection } from './components/QuizIntroSection';
import { HowItWorksSection } from './components/HowItWorksSection';
import { BrowseSection } from './components/BrowseSection';
import { ExploreNearby } from './components/ExploreNearby';
import { ResourcesSection } from './components/ResourcesSection';
import { TestimonialsSection } from './components/TestimonialsSection';
import { PeerGroupGrid } from './components/PeerGroupGrid';
import { DualCtaSection } from './components/DualCtaSection';
import { Footer } from './components/Footer';

// Page Views
import { AboutPage } from './components/pages/AboutPage';
import { ContactPage } from './components/pages/ContactPage';
import { TermsPage } from './components/pages/TermsPage';
import { PrivacyPage } from './components/pages/PrivacyPage';
import { CrisisPage } from './components/pages/CrisisPage';
import { RegisterResourcePage } from './components/pages/RegisterResourcePage';
import { FullQuizPage } from './components/pages/FullQuizPage';
import { NotFoundPage } from './components/pages/NotFoundPage';

// Modals
import { QuizModal } from './components/QuizModal';
import { TalkModal } from './components/TalkModal';
import { CrisisModal } from './components/CrisisModal';
import { GroupDetailModal } from './components/GroupDetailModal';
import { HowItWorksModal } from './components/HowItWorksModal';
import { AboutModal } from './components/AboutModal';
import { SensoryResetModal } from './components/SensoryResetModal';

import { PEER_GROUPS } from './data/mockData';
import { PeerGroup } from './types';

export default function App() {
  const navigate = useNavigate();
  const location = useLocation();

  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [selectedGroup, setSelectedGroup] = useState<PeerGroup | null>(null);

  // Modal Open States
  const [quizOpen, setQuizOpen] = useState(false);
  const [quizPersona, setQuizPersona] = useState<'myself' | 'someone' | 'work'>('myself');
  const [talkOpen, setTalkOpen] = useState(false);
  const [crisisOpen, setCrisisOpen] = useState(false);
  const [howItWorksOpen, setHowItWorksOpen] = useState(false);
  const [aboutOpen, setAboutOpen] = useState(false);
  const [sensoryResetOpen, setSensoryResetOpen] = useState(false);

  // Scroll to top on path change
  useEffect(() => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }, [location.pathname]);

  // Filter groups live based on search term & category selection
  const filteredGroups = useMemo(() => {
    return PEER_GROUPS.filter((group) => {
      // Category check
      const categoryMatch = 
        selectedCategory === 'all' || 
        group.category === selectedCategory ||
        (selectedCategory === 'burnout-recovery' && group.category === 'burnout') ||
        (selectedCategory === 'nature-healing' && group.category === 'burnout') ||
        (selectedCategory === 'quiet-reset' && group.category === 'burnout') ||
        (selectedCategory === 'caregiver-support' && group.category === 'caregiver') ||
        (selectedCategory === 'creative-unblock' && group.category === 'creative');

      // Search term check
      const query = searchTerm.toLowerCase().trim();
      if (!query) return categoryMatch;

      const searchMatch = 
        group.title.toLowerCase().includes(query) ||
        group.subtitle.toLowerCase().includes(query) ||
        group.description.toLowerCase().includes(query) ||
        group.tags.some(tag => tag.toLowerCase().includes(query)) ||
        group.facilitator.name.toLowerCase().includes(query);

      return categoryMatch && searchMatch;
    });
  }, [searchTerm, selectedCategory]);

  const scrollToBrowse = () => {
    if (location.pathname !== '/' && location.pathname !== '/browse') {
      navigate('/browse');
    } else {
      const el = document.getElementById('browse-section') || document.getElementById('peer-groups-grid');
      if (el) el.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const handleCategoryCardSelect = (catId: string) => {
    setSelectedCategory(catId);
    scrollToBrowse();
  };

  const handleStartQuizWithPersona = (persona?: 'myself' | 'someone' | 'work') => {
    if (persona) setQuizPersona(persona);
    navigate('/quiz');
  };

  const goHome = () => {
    navigate('/');
  };

  const categoryNameMap: Record<string, string> = {
    tech: 'Tech & Workplace',
    caregiver: 'Caregivers & Healthcare',
    creative: 'Creative & Solo',
    neurodivergent: 'Neurodivergent Spaces',
    burnout: 'General Burnout',
    'burnout-recovery': 'Workplace Burnout',
    'nature-healing': 'Outdoor & Walk Circles',
    'quiet-reset': 'Mindful Reset Spaces',
    'caregiver-support': 'Caregivers & Healthcare',
    'creative-unblock': 'Creative & Freelancer',
  };

  const HomePageContent = (
    <>
      {/* Hero Frame: "Find your way back from the burnout" */}
      <HeroSection
        onTakeQuiz={() => handleStartQuizWithPersona('myself')}
        onTalkToSomeone={() => setTalkOpen(true)}
      />

      {/* Quiz Introduction Frame */}
      <QuizIntroSection
        onStartQuiz={handleStartQuizWithPersona}
        onOpenHowItWorks={() => setHowItWorksOpen(true)}
      />

      {/* "How escale works" Frame */}
      <HowItWorksSection
        onStartQuiz={() => handleStartQuizWithPersona('myself')}
        onBrowseResources={scrollToBrowse}
        onOpenHowItWorksModal={() => setHowItWorksOpen(true)}
      />

      {/* Browse / "Find your people" Search Frame */}
      <BrowseSection
        searchTerm={searchTerm}
        onSearchChange={setSearchTerm}
        selectedCategory={selectedCategory}
        onCategorySelect={setSelectedCategory}
        onSearchSubmit={(e) => {
          e.preventDefault();
          const gridEl = document.getElementById('peer-groups-grid');
          if (gridEl) gridEl.scrollIntoView({ behavior: 'smooth' });
        }}
      />

      {/* "Explore nearby" Carousel Frame */}
      <ExploreNearby
        onSelectCategory={handleCategoryCardSelect}
      />

      {/* "The good stuff" Resources Directory Frame */}
      <ResourcesSection
        onSelectGroup={(group) => setSelectedGroup(group)}
        onViewAll={scrollToBrowse}
        groups={PEER_GROUPS}
      />

      {/* Community Testimonials Frame */}
      <TestimonialsSection />

      {/* Filtered Peer Group Grid */}
      <div id="peer-groups-grid" className="bg-[#b991b5] py-4">
        <PeerGroupGrid
          groups={filteredGroups}
          onSelectGroup={(group) => setSelectedGroup(group)}
          selectedCategoryName={selectedCategory !== 'all' ? (categoryNameMap[selectedCategory] || selectedCategory) : undefined}
          onResetFilters={() => {
            setSelectedCategory('all');
            setSearchTerm('');
          }}
        />
      </div>

      {/* Dual CTA Banner */}
      <DualCtaSection
        onBrowse={scrollToBrowse}
        onConnect={() => setTalkOpen(true)}
      />
    </>
  );

  return (
    <div className="min-h-screen bg-[#b991b5] text-[#2b222a] font-sans selection:bg-[#855b85] selection:text-white flex flex-col justify-between">
      
      {/* 1. Header Navigation */}
      <Header
        onGoHome={goHome}
        onOpenQuiz={() => handleStartQuizWithPersona('myself')}
        onOpenTalk={() => setTalkOpen(true)}
        onOpenCrisis={() => navigate('/crisis')}
        onOpenHowItWorks={() => setHowItWorksOpen(true)}
        onOpenAbout={() => navigate('/about')}
        onOpenContact={() => navigate('/contact')}
        onOpenTerms={() => navigate('/terms')}
        onOpenPrivacy={() => navigate('/privacy')}
        onOpenRegister={() => navigate('/register')}
        onScrollToBrowse={scrollToBrowse}
      />

      {/* Main View Router */}
      <main className="grow">
        <Routes>
          <Route path="/" element={HomePageContent} />
          <Route path="/browse" element={HomePageContent} />
          <Route path="/quiz" element={
            <FullQuizPage
              onSelectGroup={(group) => setSelectedGroup(group)}
              onTalkToSomeone={() => setTalkOpen(true)}
              onGoHome={goHome}
            />
          } />
          <Route path="/about" element={
            <AboutPage
              onStartQuiz={() => handleStartQuizWithPersona('myself')}
              onOpenCrisis={() => setCrisisOpen(true)}
              onOpenSensoryReset={() => setSensoryResetOpen(true)}
            />
          } />
          <Route path="/contact" element={
            <ContactPage
              onStartChat={() => setTalkOpen(true)}
              onOpenTerms={() => navigate('/terms')}
            />
          } />
          <Route path="/terms" element={
            <TermsPage
              onOpenCrisis={() => setCrisisOpen(true)}
            />
          } />
          <Route path="/privacy" element={
            <PrivacyPage
              onStartQuiz={() => handleStartQuizWithPersona('myself')}
              onOpenHowItWorks={() => setHowItWorksOpen(true)}
              onGoBack={goHome}
            />
          } />
          <Route path="/crisis" element={
            <CrisisPage
              onStartChat={() => setTalkOpen(true)}
              onOpenHowItWorks={() => setHowItWorksOpen(true)}
            />
          } />
          <Route path="/register" element={
            <RegisterResourcePage
              onOpenContact={() => navigate('/contact')}
              onOpenHowItWorks={() => setHowItWorksOpen(true)}
            />
          } />
          <Route path="*" element={
            <NotFoundPage
              onGoHome={goHome}
              onBrowse={scrollToBrowse}
              onStartChat={() => setTalkOpen(true)}
            />
          } />
        </Routes>
      </main>

      {/* Footer */}
      <Footer
        onGoHome={goHome}
        onOpenQuiz={() => handleStartQuizWithPersona('myself')}
        onOpenTalk={() => setTalkOpen(true)}
        onOpenCrisis={() => navigate('/crisis')}
        onOpenHowItWorks={() => setHowItWorksOpen(true)}
        onOpenAbout={() => navigate('/about')}
        onOpenContact={() => navigate('/contact')}
        onOpenTerms={() => navigate('/terms')}
        onOpenPrivacy={() => navigate('/privacy')}
        onOpenRegister={() => navigate('/register')}
      />

      {/* Interactive Modals */}
      <QuizModal
        isOpen={quizOpen}
        onClose={() => setQuizOpen(false)}
        initialPersona={quizPersona}
        onSelectGroupMatch={(group) => setSelectedGroup(group)}
      />

      <TalkModal
        isOpen={talkOpen}
        onClose={() => setTalkOpen(false)}
      />

      <CrisisModal
        isOpen={crisisOpen}
        onClose={() => setCrisisOpen(false)}
      />

      <GroupDetailModal
        group={selectedGroup}
        onClose={() => setSelectedGroup(null)}
      />

      <HowItWorksModal
        isOpen={howItWorksOpen}
        onClose={() => setHowItWorksOpen(false)}
        onOpenQuiz={() => handleStartQuizWithPersona('myself')}
      />

      <AboutModal
        isOpen={aboutOpen}
        onClose={() => setAboutOpen(false)}
      />

      <SensoryResetModal
        isOpen={sensoryResetOpen}
        onClose={() => setSensoryResetOpen(false)}
      />

    </div>
  );
}
