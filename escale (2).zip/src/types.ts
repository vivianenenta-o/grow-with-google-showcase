export interface PeerGroup {
  id: string;
  title: string;
  subtitle: string;
  category: 'burnout' | 'tech' | 'caregiver' | 'creative' | 'grief' | 'neurodivergent' | 'general';
  tags: string[];
  description: string;
  image: string;
  meetingSchedule: string;
  location: string; // 'Online' or City
  isVerified: boolean;
  verifiedDate: string;
  memberCount: number;
  maxCapacity: number;
  facilitator: {
    name: string;
    role: string;
    avatar: string;
    bio: string;
  };
  upcomingDates: string[];
  format: 'Virtual Circle' | 'In-person' | 'Hybrid';
}

export interface CategoryCard {
  id: string;
  title: string;
  description: string;
  image: string;
  tag: string;
  groupCount: number;
}

export interface QuizQuestion {
  id: number;
  question: string;
  subtitle: string;
  options: {
    label: string;
    description: string;
    tag: string;
  }[];
}

export interface PeerListener {
  id: string;
  name: string;
  specialty: string;
  avatar: string;
  availability: 'Available Now' | 'In 15 mins' | 'Schedule Later';
  languages: string[];
  bio: string;
  rating: number;
  reviewsCount: number;
}

export interface CrisisResource {
  id: string;
  name: string;
  contact: string;
  type: 'Call' | 'Text' | 'Online Chat';
  description: string;
  availableHours: string;
  country: string;
}
