import { PeerGroup, CategoryCard, QuizQuestion, PeerListener, CrisisResource } from '../types';

import heroImage from '../assets/images/hero_friends_burnout_1786277282260.jpg';
import forestTrail from '../assets/images/explore_forest_trail_1786277296549.jpg';
import cozyGroup from '../assets/images/explore_cozy_group_1786277310778.jpg';
import sunlitRoom from '../assets/images/explore_sunlit_room_1786277323284.jpg';

export { heroImage };

export const CATEGORY_CARDS: CategoryCard[] = [
  {
    id: 'burnout-recovery',
    title: 'Workplace & Tech Burnout',
    description: 'For engineers, designers, managers & founders feeling chronically drained by corporate hustle.',
    image: cozyGroup,
    tag: 'Carrying Heavy Workload',
    groupCount: 14,
  },
  {
    id: 'nature-healing',
    title: 'Outdoor & Walk Circles',
    description: 'Gentle outdoor gatherings combining light movement, fresh air, and candid peer connection.',
    image: forestTrail,
    tag: 'Seeking Open Space',
    groupCount: 9,
  },
  {
    id: 'quiet-reset',
    title: 'Mindful Quiet & Reset Spaces',
    description: 'Low-pressure, sensory-friendly drop-ins with guided silence and unhurried sharing.',
    image: sunlitRoom,
    tag: 'Needing Calm & Space',
    groupCount: 11,
  },
  {
    id: 'caregiver-support',
    title: 'Caregivers & Healthcare Workers',
    description: 'A sanctuary for nurses, family caretakers, and therapists holding space for others.',
    image: 'https://images.unsplash.com/photo-1576091160399-112ba8d25d1d?auto=format&fit=crop&q=80&w=800',
    tag: 'Holding Space for Others',
    groupCount: 8,
  },
  {
    id: 'creative-unblock',
    title: 'Creative & Freelancer Circles',
    description: 'Overcoming creative block, boundary burnout, and solo-worker isolation together.',
    image: 'https://images.unsplash.com/photo-1522202176988-66273c2fd55f?auto=format&fit=crop&q=80&w=800',
    tag: 'Navigating Solo Work',
    groupCount: 12,
  },
];

export const PEER_GROUPS: PeerGroup[] = [
  {
    id: 'tech-burnout-weekly',
    title: 'Software & Tech Burnout Support Circle',
    subtitle: 'Weekly honest conversations on screen fatigue, crunch pressure, and career detachment.',
    category: 'tech',
    tags: ['Tech Industry', 'Weekly', 'Virtual', 'Peer-Led'],
    description: 'A confidential, peer-facilitated group for individuals in high-pressure tech roles. We share coping frameworks, boundary-setting strategies, and mutual encouragement without career advice fluff.',
    image: cozyGroup,
    meetingSchedule: 'Tuesdays @ 6:00 PM EST',
    location: 'Online via Video',
    isVerified: true,
    verifiedDate: 'Aug 2026',
    memberCount: 8,
    maxCapacity: 12,
    facilitator: {
      name: 'Elena Rostova',
      role: 'Ex-Staff Engineer & Certified Peer Facilitator',
      avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&q=80&w=200',
      bio: 'Navigated severe burnout after 8 years in fast-growth tech. Passionate about sustainable work boundaries.',
    },
    upcomingDates: ['Aug 12, 2026', 'Aug 19, 2026', 'Aug 26, 2026'],
    format: 'Virtual Circle',
  },
  {
    id: 'weekend-nature-reset',
    title: 'Urban Park Walk & Unwind Group',
    subtitle: 'Saturday morning low-tempo nature walk and open reflection circle.',
    category: 'burnout',
    tags: ['In-Person', 'Outdoors', 'Fresh Air', 'San Francisco'],
    description: 'Leave the phone behind for a 45-minute stroll followed by warm tea and informal sharing. No pressure to talk—just be present with people who understand.',
    image: forestTrail,
    meetingSchedule: 'Saturdays @ 10:00 AM PST',
    location: 'Golden Gate Park, San Francisco & Online Sync',
    isVerified: true,
    verifiedDate: 'Aug 2026',
    memberCount: 10,
    maxCapacity: 15,
    facilitator: {
      name: 'Marcus Vance',
      role: 'Community Builder & Wilderness Guide',
      avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&q=80&w=200',
      bio: 'Believes nature and unhurried human connection are the ultimate remedies for modern overstimulation.',
    },
    upcomingDates: ['Aug 15, 2026', 'Aug 22, 2026', 'Aug 29, 2026'],
    format: 'Hybrid',
  },
  {
    id: 'healthcare-frontline-circle',
    title: 'Healthcare & Nursing Peer Sanctuary',
    subtitle: 'A safe space for nurses, physicians, and medical staff managing shift fatigue.',
    category: 'caregiver',
    tags: ['Healthcare', 'Compassion Fatigue', 'Confidential'],
    description: 'Decompress after intense shifts with fellow medical workers who understand the emotional weight of patient care and clinical burnout.',
    image: 'https://images.unsplash.com/photo-1576091160399-112ba8d25d1d?auto=format&fit=crop&q=80&w=800',
    meetingSchedule: 'Wednesdays @ 8:00 PM EST',
    location: 'Online via Video',
    isVerified: true,
    verifiedDate: 'Aug 2026',
    memberCount: 6,
    maxCapacity: 10,
    facilitator: {
      name: 'Dr. Sarah Lin',
      role: 'Emergency Nurse Practitioner',
      avatar: 'https://images.unsplash.com/photo-1559839734-2b71ea197ec2?auto=format&fit=crop&q=80&w=200',
      bio: '12 years in critical care. Dedicated to creating psychological safety for healthcare heroes.',
    },
    upcomingDates: ['Aug 13, 2026', 'Aug 20, 2026', 'Aug 27, 2026'],
    format: 'Virtual Circle',
  },
  {
    id: 'creative-block-recovery',
    title: 'Creative Overwhelm & Freelance Unblock',
    subtitle: 'Restoring joy and sustainable rhythms for artists, writers, and freelancers.',
    category: 'creative',
    tags: ['Creative', 'Freelance', 'Boundaries'],
    description: 'When your passion becomes your stress source. Join fellow creators to talk about client pressure, imposter thoughts, and recovering intrinsic inspiration.',
    image: sunlitRoom,
    meetingSchedule: 'Thursdays @ 5:00 PM PST',
    location: 'Online via Video',
    isVerified: true,
    verifiedDate: 'Aug 2026',
    memberCount: 9,
    maxCapacity: 12,
    facilitator: {
      name: 'Maya Ruiz',
      role: 'Independent Illustrator & Author',
      avatar: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?auto=format&fit=crop&q=80&w=200',
      bio: 'Navigated severe artist block and built a healthy studio practice focused on rest over hustle.',
    },
    upcomingDates: ['Aug 14, 2026', 'Aug 21, 2026', 'Aug 28, 2026'],
    format: 'Virtual Circle',
  },
  {
    id: 'neurodivergent-burnout',
    title: 'Neurodivergent Unmasking & Burnout Lab',
    subtitle: 'Low-sensory peer group for autistic and ADHD individuals navigating burnout.',
    category: 'neurodivergent',
    tags: ['ADHD', 'Autistic Space', 'Low-Sensory', 'Unmasking'],
    description: 'Unmask safely without social expectations. Camera-optional, chat-friendly, with explicit conversation norms designed for ND energy management.',
    image: 'https://images.unsplash.com/photo-1529156069898-49953e39b3ac?auto=format&fit=crop&q=80&w=800',
    meetingSchedule: 'Mondays @ 7:00 PM EST',
    location: 'Online via Discord / Video',
    isVerified: true,
    verifiedDate: 'Aug 2026',
    memberCount: 11,
    maxCapacity: 15,
    facilitator: {
      name: 'Sam Chen',
      role: 'Neurodiversity Advocate & Peer Mentor',
      avatar: 'https://images.unsplash.com/photo-1539571696357-5a69c17a67c6?auto=format&fit=crop&q=80&w=200',
      bio: 'Diagnosed late-in-life ADHD/Autistic. Facilitating gentle spaces where masking is never required.',
    },
    upcomingDates: ['Aug 11, 2026', 'Aug 18, 2026', 'Aug 25, 2026'],
    format: 'Virtual Circle',
  },
];

export const QUIZ_QUESTIONS: QuizQuestion[] = [
  {
    id: 1,
    question: "What best describes how burnout is showing up for you today?",
    subtitle: "Select the option that resonates most right now.",
    options: [
      {
        label: "Mental & Physical Exhaustion",
        description: "Even a full night's sleep doesn't restore your energy. Everything feels heavy.",
        tag: "exhaustion"
      },
      {
        label: "Cynicism & Career Detachment",
        description: "You used to care deeply, but now feel disconnected from your work or goals.",
        tag: "detachment"
      },
      {
        label: "Overwhelm & Boundary Breakdown",
        description: "Too many demands, difficulty saying no, constantly feeling behind schedule.",
        tag: "overwhelm"
      },
      {
        label: "Isolation & Feeling Unheard",
        description: "You're holding it all inside because friends or coworkers wouldn't understand.",
        tag: "isolation"
      }
    ]
  },
  {
    id: 2,
    question: "Which environment or domain is generating the most weight?",
    subtitle: "We'll tailor your peer matches to people facing similar realities.",
    options: [
      {
        label: "Tech, Corporate & High-Growth Work",
        description: "Deadlines, screen strain, performance metrics, and constant availability.",
        tag: "tech"
      },
      {
        label: "Caregiving, Medical & Human Services",
        description: "Nourishing others while your own well empty and unreplenished.",
        tag: "caregiver"
      },
      {
        label: "Freelance & Creative Industries",
        description: "Unpredictable income, self-worth tied to output, and solo isolation.",
        tag: "creative"
      },
      {
        label: "General Life & Transition Stresses",
        description: "Major shifts, personal responsibilities, or cumulative daily overload.",
        tag: "burnout"
      }
    ]
  },
  {
    id: 3,
    question: "What format of peer support feels safest and most comfortable?",
    subtitle: "No pressure—you control how and when you participate.",
    options: [
      {
        label: "Small Virtual Circles (6-12 people)",
        description: "Facilitated weekly zoom calls with structured, equal speaking turns.",
        tag: "Virtual Circle"
      },
      {
        label: "1-on-1 Confidential Peer Listener",
        description: "Direct chat or voice call with a trained listener who has lived experience.",
        tag: "1-on-1"
      },
      {
        label: "Low-Pressure Hybrid / Outdoor Strolls",
        description: "In-person walking groups with minimal eye contact pressure and fresh air.",
        tag: "Hybrid"
      },
      {
        label: "Self-Paced Digital Tools & Text Spaces",
        description: "Asynchronous community boards and self-guided reflection prompts.",
        tag: "Digital"
      }
    ]
  }
];

export const PEER_LISTENERS: PeerListener[] = [
  {
    id: 'l1',
    name: 'Chloe Bennett',
    specialty: 'Tech Burnout & Imposter Syndrome',
    avatar: 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?auto=format&fit=crop&q=80&w=200',
    availability: 'Available Now',
    languages: ['English', 'Spanish'],
    bio: 'Former product manager who rebuilt balance after severe burnout. Here to listen without judgment.',
    rating: 4.95,
    reviewsCount: 42,
  },
  {
    id: 'l2',
    name: 'David O\'Connor',
    specialty: 'Caregiver Fatigue & Grief Support',
    avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&q=80&w=200',
    availability: 'Available Now',
    languages: ['English'],
    bio: 'Experienced peer mentor supporting family caregivers and social impact workers.',
    rating: 5.0,
    reviewsCount: 38,
  },
  {
    id: 'l3',
    name: 'Amina Kante',
    specialty: 'Creative Block & Freelance Strain',
    avatar: 'https://images.unsplash.com/photo-1531746020798-e6953c6e8e04?auto=format&fit=crop&q=80&w=200',
    availability: 'In 15 mins',
    languages: ['English', 'French'],
    bio: 'Designer & coach specializing in boundary setting and unhooking identity from work output.',
    rating: 4.9,
    reviewsCount: 29,
  }
];

export const CRISIS_RESOURCES: CrisisResource[] = [
  {
    id: 'c1',
    name: '988 Suicide & Crisis Lifeline',
    contact: '988',
    type: 'Call',
    description: 'Free, confidential, 24/7 crisis support in the US and Canada.',
    availableHours: '24/7 Available',
    country: 'United States & Canada'
  },
  {
    id: 'c2',
    name: 'Crisis Text Line',
    contact: 'Text HOME to 741741',
    type: 'Text',
    description: 'Connect with a crisis counselor over confidential text messaging.',
    availableHours: '24/7 Available',
    country: 'US, UK, Canada'
  },
  {
    id: 'c3',
    name: 'Warmline Peer Support Network',
    contact: '1-800-985-5990',
    type: 'Call',
    description: 'Peer-run non-crisis emotional support for early distress and loneliness.',
    availableHours: '8:00 AM - Midnight PST',
    country: 'United States'
  },
  {
    id: 'c4',
    name: 'International Helpline Directory',
    contact: 'findahelpline.com',
    type: 'Online Chat',
    description: 'Free, confidential support services in over 130 countries.',
    availableHours: '24/7 Available',
    country: 'Global'
  }
];
