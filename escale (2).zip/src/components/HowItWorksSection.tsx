import React from 'react';
import { ArrowUpRight, Box, ShieldCheck, HeartHandshake, Compass } from 'lucide-react';
import forestTrail from '../assets/images/explore_forest_trail_1786277296549.jpg';
import cozyGroup from '../assets/images/explore_cozy_group_1786277310778.jpg';

interface HowItWorksSectionProps {
  onStartQuiz: () => void;
  onBrowseResources: () => void;
  onOpenHowItWorksModal: () => void;
}

export const HowItWorksSection: React.FC<HowItWorksSectionProps> = ({
  onStartQuiz,
  onBrowseResources,
  onOpenHowItWorksModal,
}) => {
  return (
    <section className="bg-[#b991b5] py-12 sm:py-16 md:py-20 px-4 sm:px-6 lg:px-10 text-[#1f1621]">
      <div className="max-w-7xl mx-auto space-y-10">
        
        {/* Section Header */}
        <div className="space-y-2">
          <span className="inline-block text-xs uppercase tracking-widest font-semibold text-[#6e4b6d] bg-[#ebdbe8] px-3 py-1 rounded-full">
            How
          </span>
          <h2 className="text-3xl sm:text-4xl md:text-5xl font-serif font-normal text-[#1f1621] tracking-tight">
            How escale works
          </h2>
          <p className="text-base sm:text-lg text-[#473446] font-normal">
            A clear path through the noise, built for real people
          </p>
        </div>

        {/* 3-Card Grid Layout (Matching Frame 5 / Page 4 in PDF) */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          
          {/* Card 1: Route (Large Left Card - 7 Columns) */}
          <div className="lg:col-span-7 relative rounded-[32px] overflow-hidden min-h-[380px] sm:min-h-[420px] p-8 sm:p-10 flex flex-col justify-between text-white shadow-lg group">
            
            {/* Background Image */}
            <img
              src={cozyGroup}
              alt="People gathered comfortably in living room circle"
              className="absolute inset-0 w-full h-full object-cover group-hover:scale-105 transition-transform duration-700"
              referrerPolicy="no-referrer"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black/85 via-black/60 to-black/30" />

            {/* Top Tag */}
            <div className="relative z-10">
              <span className="inline-flex items-center gap-1.5 text-xs font-semibold uppercase tracking-wider text-white bg-white/20 backdrop-blur-xs px-3.5 py-1 rounded-full">
                <Compass className="w-3.5 h-3.5" />
                Route
              </span>
            </div>

            {/* Content & Action Buttons */}
            <div className="relative z-10 space-y-4 max-w-xl pt-16">
              <h3 className="text-2xl sm:text-3xl md:text-4xl font-serif font-normal leading-tight text-white">
                We route you to support, we do not treat you
              </h3>

              <p className="text-sm sm:text-base text-zinc-200/95 leading-relaxed font-light">
                We are a signpost, not a clinic. The quiz maps your burnout, budget, and career stage to a handful of trustworthy options.
              </p>

              <div className="flex flex-wrap items-center gap-3 pt-2">
                <button
                  onClick={onBrowseResources}
                  className="px-6 py-2.5 rounded-full bg-white text-[#1f1621] text-sm font-semibold hover:bg-zinc-100 transition-all cursor-pointer shadow-sm"
                >
                  Find Resources
                </button>
                <button
                  onClick={onStartQuiz}
                  className="px-6 py-2.5 rounded-full border border-white/60 text-white text-sm font-medium hover:bg-white/15 backdrop-blur-xs transition-all cursor-pointer"
                >
                  Start Quiz
                </button>
              </div>
            </div>

          </div>

          {/* Right Side Column (Cards 2 & 3 - 5 Columns Stacked) */}
          <div className="lg:col-span-5 flex flex-col gap-6">
            
            {/* Card 2: Vetting */}
            <div 
              onClick={onOpenHowItWorksModal}
              className="bg-[#2d222e] text-white rounded-[28px] p-7 sm:p-8 flex flex-col justify-between min-h-[200px] shadow-md hover:bg-[#382b3a] transition-all cursor-pointer group border border-white/10"
            >
              <div className="flex items-start justify-between">
                <div className="w-10 h-10 rounded-xl bg-white/10 flex items-center justify-center text-zinc-100">
                  <Box className="w-5 h-5" />
                </div>
                <div className="flex items-center text-xs font-medium text-zinc-300 group-hover:text-white transition-colors">
                  <span>Vetting</span>
                  <ArrowUpRight className="w-4 h-4 ml-1 transform group-hover:translate-x-0.5 group-hover:-translate-y-0.5 transition-transform" />
                </div>
              </div>

              <div className="space-y-2 pt-4">
                <h4 className="text-lg sm:text-xl font-serif font-medium text-white">
                  Every resource is actively verified and dated
                </h4>
                <p className="text-xs sm:text-sm text-zinc-300 font-light leading-relaxed">
                  No dead links. Every listing shows a verified badge and last-checked date.
                </p>
              </div>
            </div>

            {/* Card 3: Caregivers */}
            <div 
              onClick={onOpenHowItWorksModal}
              className="relative rounded-[28px] overflow-hidden p-7 sm:p-8 flex flex-col justify-between min-h-[200px] text-white shadow-md group cursor-pointer border border-white/10"
            >
              {/* Background image */}
              <img
                src={forestTrail}
                alt="Sunlit dirt path winding through green forest"
                className="absolute inset-0 w-full h-full object-cover group-hover:scale-105 transition-transform duration-700"
                referrerPolicy="no-referrer"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/60 to-black/40" />

              <div className="relative z-10 flex items-start justify-between">
                <div className="w-10 h-10 rounded-xl bg-white/20 backdrop-blur-xs flex items-center justify-center text-white">
                  <HeartHandshake className="w-5 h-5" />
                </div>
                <div className="flex items-center text-xs font-medium text-zinc-200 group-hover:text-white transition-colors">
                  <span>Learn</span>
                  <ArrowUpRight className="w-4 h-4 ml-1 transform group-hover:translate-x-0.5 group-hover:-translate-y-0.5 transition-transform" />
                </div>
              </div>

              <div className="relative z-10 space-y-1.5 pt-4">
                <h4 className="text-lg sm:text-xl font-serif font-medium text-white">
                  A toggle for caregivers and navigators
                </h4>
                <p className="text-xs sm:text-sm text-zinc-200/90 font-light leading-relaxed">
                  Use the same quiz on behalf of someone you care about.
                </p>
              </div>
            </div>

          </div>

        </div>

      </div>
    </section>
  );
};

