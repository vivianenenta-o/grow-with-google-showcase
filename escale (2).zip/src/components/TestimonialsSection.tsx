import React from 'react';
import { Quote } from 'lucide-react';

export const TestimonialsSection: React.FC = () => {
  const testimonials = [
    {
      companyLogo: 'Webflow',
      quote: 'I thought I was just bad at my job. The quiz showed me I was burned out and connected me to a group of remote workers who actually understood the isolation.',
      name: 'Marcus Chen',
      role: 'Software developer, Austin',
      avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&q=80&w=200',
    },
    {
      companyLogo: 'Relume',
      quote: 'I used the toggle to find help for my partner. It was a relief to have a clear, private path without making things awkward or complicated.',
      name: 'Elena Rossi',
      role: 'Design lead, Chicago',
      avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&q=80&w=200',
    },
    {
      companyLogo: 'Webflow',
      quote: 'The verified badge mattered. I had been burned by outdated lists before. Knowing someone actually checked the group was still active let me trust it.',
      name: 'David Park',
      role: 'Recent grad, Denver',
      avatar: 'https://images.unsplash.com/photo-1539571696357-5a69c17a67c6?auto=format&fit=crop&q=80&w=200',
    },
  ];

  return (
    <section className="bg-[#b991b5] py-12 sm:py-16 md:py-20 px-4 sm:px-6 lg:px-10 text-[#1f1621]">
      <div className="max-w-7xl mx-auto space-y-10">
        
        {/* Header */}
        <div className="text-center space-y-3 max-w-2xl mx-auto">
          <h2 className="text-3xl sm:text-4xl md:text-5xl font-serif font-normal text-[#1f1621] tracking-tight">
            You are not alone.
          </h2>
          <p className="text-base sm:text-lg text-[#4a3649] font-light">
            And you don't have to be. Hear from our community.
          </p>
        </div>

        {/* 3 Testimonial Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {testimonials.map((t, idx) => (
            <div
              key={idx}
              className="bg-[#f9f5f8] rounded-3xl p-7 sm:p-8 flex flex-col justify-between space-y-6 shadow-md border border-white/40 hover:shadow-lg transition-all"
            >
              {/* Top Logo / Icon */}
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold uppercase tracking-widest text-[#855b85] font-mono">
                  {t.companyLogo}
                </span>
                <Quote className="w-6 h-6 text-[#855b85]/40" />
              </div>

              {/* Quote Body */}
              <p className="text-sm sm:text-base text-[#2b222a] leading-relaxed font-normal italic">
                "{t.quote}"
              </p>

              {/* Author Footer */}
              <div className="flex items-center gap-3 pt-2 border-t border-[#e3d7e2]">
                <img
                  src={t.avatar}
                  alt={t.name}
                  className="w-11 h-11 rounded-full object-cover border-2 border-[#855b85]/30"
                  referrerPolicy="no-referrer"
                />
                <div>
                  <div className="font-medium text-sm text-[#1f1621]">
                    {t.name}
                  </div>
                  <div className="text-xs text-[#755e74]">
                    {t.role}
                  </div>
                </div>
              </div>

            </div>
          ))}
        </div>

      </div>
    </section>
  );
};
