import React, { useState } from 'react';
import { ShieldCheck, HeartHandshake, CheckCircle2, ArrowRight, ArrowUpRight, Linkedin, Twitter, Mail } from 'lucide-react';
import laptopPlantsImage from '../../assets/images/exact_verify_man_laptop_1786494760483.jpg';

interface AboutPageProps {
  onStartQuiz: () => void;
  onBrowse: () => void;
  onStartChat: () => void;
}

export const AboutPage: React.FC<AboutPageProps> = ({
  onStartQuiz,
  onBrowse,
  onStartChat,
}) => {
  const [activeTab, setActiveTab] = useState<'promise' | 'vetting'>('promise');

  const teamMembers = [
    {
      name: 'Maya Chen',
      role: 'Founder',
      bio: 'A former management consultant who burned out hard and found a broken system waiting for her.',
      avatar: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?auto=format&fit=crop&q=80&w=300',
    },
    {
      name: 'David Okonkwo',
      role: 'Head of vetting',
      bio: 'A clinical social worker who believes a warm voice and a verified link can save a life.',
      avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&q=80&w=300',
    },
    {
      name: 'Priya Singh',
      role: 'Product lead',
      bio: 'She makes sure the quiz feels like a conversation, not a clinical intake form.',
      avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&q=80&w=300',
    },
    {
      name: 'Liam O\'Brien',
      role: 'Community manager',
      bio: 'He talks to peer groups every day, listening for the ones that truly show up.',
      avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&q=80&w=300',
    },
    {
      name: 'Aisha Williams',
      role: 'Navigator lead',
      bio: 'She trains real people to answer the chat with patience, not scripts.',
      avatar: 'https://images.unsplash.com/photo-1580489944761-15a19d654956?auto=format&fit=crop&q=80&w=300',
    },
    {
      name: 'Kenji Tanaka',
      role: 'Engineer',
      bio: 'He builds the quiet machinery that keeps your data anonymous and your path clear.',
      avatar: 'https://images.unsplash.com/photo-1539571696357-5a69c17a67c6?auto=format&fit=crop&q=80&w=300',
    },
  ];

  return (
    <div className="bg-[#b991b5] text-[#1f1621] min-h-screen">
      
      {/* 1. Hero Header */}
      <section className="py-12 sm:py-16 md:py-20 px-4 sm:px-6 lg:px-10 text-center max-w-4xl mx-auto space-y-4">
        <span className="inline-block text-xs uppercase tracking-widest font-semibold text-[#855b85] bg-[#ebdbe8] px-3.5 py-1 rounded-full">
          About
        </span>
        <h1 className="text-4xl sm:text-5xl md:text-6xl font-serif font-normal text-[#1f1621] tracking-tight">
          A clear path
        </h1>
        <p className="text-base sm:text-lg text-[#4a3649] font-light max-w-2xl mx-auto leading-relaxed">
          We built escale because finding real, trustworthy support shouldn't feel like another job when you're already running on empty.
        </p>
      </section>

      {/* 2. Story Card */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-10 pb-16">
        <div className="bg-[#1f1621] text-white rounded-[32px] sm:rounded-[40px] overflow-hidden grid grid-cols-1 md:grid-cols-12 shadow-2xl">
          
          {/* Left Text Block */}
          <div className="md:col-span-7 p-8 sm:p-12 md:p-16 flex flex-col justify-between space-y-8">
            <div className="space-y-4">
              <span className="inline-block text-xs uppercase tracking-widest font-semibold text-zinc-300 bg-white/10 px-3 py-1 rounded-full">
                Story
              </span>
              <h2 className="text-3xl sm:text-4xl md:text-5xl font-serif font-normal text-white leading-tight">
                The map was broken so we drew a new one.
              </h2>
              <p className="text-sm sm:text-base text-zinc-300 font-light leading-relaxed">
                You were handed a list of a thousand resources and told to find yourself. That is not support. That is another assignment when your tank is empty. escale was built for the moment after burnout hits, when the search for help should be a clear line, not a maze. We route, we do not treat. We use plain language because jargon is a locked door. Every peer group, every tool, every affordable therapist in our directory has been checked by a real person. We verify them, we date them, and we match them to your career stage, your budget, and what you are actually feeling. No endless scrolling. No dead links. Just a few good options, because that is all anyone can hold.
              </p>
            </div>

            {/* Switchable Promise / Vetting Tab */}
            <div className="pt-4 border-t border-white/10 space-y-4">
              <div className="flex gap-3">
                <button
                  onClick={() => setActiveTab('promise')}
                  className={`px-5 py-2 rounded-full text-xs font-semibold cursor-pointer transition-all ${
                    activeTab === 'promise'
                      ? 'bg-white text-[#1f1621]'
                      : 'bg-white/10 text-white hover:bg-white/20'
                  }`}
                >
                  Our Promise
                </button>
                <button
                  onClick={() => setActiveTab('vetting')}
                  className={`px-5 py-2 rounded-full text-xs font-semibold cursor-pointer transition-all ${
                    activeTab === 'vetting'
                      ? 'bg-white text-[#1f1621]'
                      : 'bg-white/10 text-white hover:bg-white/20'
                  }`}
                >
                  Vetting
                </button>
              </div>

              <div className="text-xs sm:text-sm text-zinc-300 leading-relaxed font-light">
                {activeTab === 'promise' ? (
                  <p>100% free for seekers. No data sharing with employers or third-party ad networks. Always anonymous and privacy-first.</p>
                ) : (
                  <p>Every resource gets verified quarterly. If wait times grow excessive or links break, the listing is temporarily paused until resolved.</p>
                )}
              </div>
            </div>

          </div>

          {/* Right Side Image */}
          <div className="md:col-span-5 relative min-h-[300px] md:min-h-full">
            <img
              src={laptopPlantsImage}
              alt="Person reflecting at desk with ambient indoor plants"
              className="absolute inset-0 w-full h-full object-cover"
              referrerPolicy="no-referrer"
            />
          </div>

        </div>
      </section>

      {/* 3. The Truth Section */}
      <section className="bg-[#f9f5f8] py-16 px-4 sm:px-6 lg:px-10 text-[#1f1621]">
        <div className="max-w-4xl mx-auto text-center space-y-6">
          <span className="inline-block text-xs uppercase tracking-widest font-semibold text-[#855b85] bg-[#ebdbe8] px-3.5 py-1 rounded-full">
            The truth
          </span>
          <h2 className="text-3xl sm:text-4xl md:text-5xl font-serif font-normal text-[#2b222a] tracking-tight">
            We test every door before we show you the handle.
          </h2>
          <p className="text-base sm:text-lg text-[#5e4b5d] font-light leading-relaxed">
            Most online directories are graveyards of disconnected numbers, expired links, and six-month waitlists. We do the messy background work so you don't have to. We strip away marketing fluff, verify exact pricing, and confirm active capacity. If a peer group, tool, or navigator isn't currently active, accessible, and human-checked, it doesn't make the cut.
          </p>
        </div>
      </section>

      {/* 4. Team Section */}
      <section className="py-16 px-4 sm:px-6 lg:px-10 max-w-7xl mx-auto space-y-12">
        <div className="text-center space-y-3">
          <span className="inline-block text-xs uppercase tracking-widest font-semibold text-[#6e4b6d] bg-[#ebdbe8] px-3.5 py-1 rounded-full">
            Team
          </span>
          <h2 className="text-3xl sm:text-4xl md:text-5xl font-serif font-normal text-[#1f1621] tracking-tight">
            Our team
          </h2>
          <p className="text-base sm:text-lg text-[#4a3649] font-light">
            Real people building a clear path out of the fog.
          </p>
        </div>

        {/* 6 Team Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8">
          {teamMembers.map((m, idx) => (
            <div
              key={idx}
              className="bg-[#f9f5f8] rounded-3xl p-6 sm:p-8 flex flex-col items-center text-center space-y-4 shadow-sm border border-white/50 hover:shadow-md transition-all"
            >
              <img
                src={m.avatar}
                alt={m.name}
                className="w-24 h-24 rounded-full object-cover border-2 border-[#855b85]/30 shadow-sm"
                referrerPolicy="no-referrer"
              />
              <div>
                <h3 className="text-xl font-serif font-medium text-[#2b222a]">{m.name}</h3>
                <p className="text-xs uppercase tracking-wider font-semibold text-[#855b85] pt-0.5">{m.role}</p>
              </div>
              <p className="text-xs sm:text-sm text-[#5e4b5d] leading-relaxed font-light">
                "{m.bio}"
              </p>
              <div className="flex items-center gap-3 pt-2 text-[#855b85]">
                <a href="#linkedin" className="p-1.5 hover:bg-[#ebdbe8] rounded-full transition-colors" aria-label="LinkedIn">
                  <Linkedin className="w-4 h-4" />
                </a>
                <a href="#twitter" className="p-1.5 hover:bg-[#ebdbe8] rounded-full transition-colors" aria-label="Twitter">
                  <Twitter className="w-4 h-4" />
                </a>
                <a href="#email" className="p-1.5 hover:bg-[#ebdbe8] rounded-full transition-colors" aria-label="Email">
                  <Mail className="w-4 h-4" />
                </a>
              </div>
            </div>
          ))}
        </div>

        {/* We're Hiring Callout */}
        <div className="bg-[#1f1621] text-white rounded-3xl p-8 text-center space-y-4 max-w-2xl mx-auto shadow-lg">
          <h3 className="text-2xl font-serif font-normal">We're hiring</h3>
          <p className="text-sm text-zinc-300 font-light">
            Want to help build a warmer way to find support?
          </p>
          <div>
            <button
              onClick={() => alert('Applications open! Please contact jobs@joinescale.com')}
              className="px-6 py-2.5 rounded-full bg-white text-[#1f1621] hover:bg-zinc-100 transition-all font-medium text-sm cursor-pointer"
            >
              Open positions
            </button>
          </div>
        </div>
      </section>

      {/* 5. Bottom Dual CTA */}
      <section className="bg-[#1f1621] text-white py-16 px-4 sm:px-6 lg:px-10 mt-12 border-t border-white/10">
        <div className="max-w-7xl mx-auto grid grid-cols-1 md:grid-cols-2 gap-8">
          
          <div className="bg-white/5 rounded-3xl p-8 sm:p-10 space-y-6 border border-white/10">
            <h3 className="text-2xl sm:text-3xl font-serif font-normal">Find your footing</h3>
            <p className="text-sm sm:text-base text-zinc-300 font-light leading-relaxed">
              A few honest questions lead to a small, curated set of resources matched to your life right now.
            </p>
            <div className="flex gap-4">
              <button
                onClick={onStartQuiz}
                className="px-6 py-2.5 rounded-full bg-white text-[#1f1621] font-semibold text-sm hover:bg-zinc-100 transition-all cursor-pointer"
              >
                Quiz
              </button>
              <button
                onClick={onBrowse}
                className="px-6 py-2.5 rounded-full border border-white/60 text-white font-medium text-sm hover:bg-white/10 transition-all cursor-pointer"
              >
                Directory
              </button>
            </div>
          </div>

          <div className="bg-white/5 rounded-3xl p-8 sm:p-10 space-y-6 border border-white/10">
            <h3 className="text-2xl sm:text-3xl font-serif font-normal">Talk to someone</h3>
            <p className="text-sm sm:text-base text-zinc-300 font-light leading-relaxed">
              You don't have to figure this out alone. A real navigator is ready to listen and help.
            </p>
            <div>
              <button
                onClick={onStartChat}
                className="px-8 py-2.5 rounded-full bg-white text-[#1f1621] font-semibold text-sm hover:bg-zinc-100 transition-all cursor-pointer"
              >
                Chat
              </button>
            </div>
          </div>

        </div>
      </section>

    </div>
  );
};
