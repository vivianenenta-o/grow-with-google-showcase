import React, { useState } from 'react';
import { Phone, MessageSquare, AlertCircle, Heart, ShieldAlert, Users, Sparkles } from 'lucide-react';

interface CrisisPageProps {
  onStartChat: () => void;
  onOpenHowItWorks: () => void;
}

export const CrisisPage: React.FC<CrisisPageProps> = ({ onStartChat, onOpenHowItWorks }) => {
  const [selectedFeeling, setSelectedFeeling] = useState('racing');

  const feelings = [
    {
      id: 'racing',
      label: 'Racing Mind',
      headline: 'Your mind feels like a radio that won\'t turn off',
      description: 'Thoughts race in tight circles. You replay conversations or imagine worst outcomes. The quiet feels loud and uncomfortable.',
    },
    {
      id: 'numb',
      label: 'Feeling Numb',
      headline: 'Everything feels muted, far away, or detached',
      description: 'You feel like you are moving through fog or watching your life from the outside. Standard emotions feel out of reach.',
    },
    {
      id: 'fatigue',
      label: 'Complete Depletion & Heavy Fatigue',
      headline: 'Your body refuses to move and your tank is at zero',
      description: 'Simple decisions feel impossible. Basic tasks like replying to a message or standing up take immense willpower.',
    },
    {
      id: 'panic',
      label: 'Panic & Trapped Sensation',
      headline: 'Your chest feels tight and breath feels short',
      description: 'An overwhelming sense of urgency or dread washes over you without warning. You just need a quiet place to ground.',
    },
    {
      id: 'breaking',
      label: 'The Breaking Point',
      headline: 'You cannot carry this load alone for another hour',
      description: 'You have pushed past your limits for too long. Reach out to a trained counselor right now—no judgment, just support.',
    },
  ];

  const current = feelings.find((f) => f.id === selectedFeeling) || feelings[0];

  return (
    <div className="bg-[#b991b5] text-[#1f1621] min-h-screen py-12 sm:py-16 px-4 sm:px-6 lg:px-10">
      <div className="max-w-4xl mx-auto space-y-12">
        
        {/* Top Banner (Page 11 in PDF) */}
        <div className="bg-[#1f1621] text-white rounded-[32px] sm:rounded-[40px] p-8 sm:p-14 text-center space-y-4 shadow-2xl relative overflow-hidden min-h-[220px] flex flex-col justify-center items-center">
          <img 
            src="/src/assets/images/crisis_holding_hands_1786491474206.jpg" 
            alt="Comforting hands"
            className="absolute inset-0 w-full h-full object-cover opacity-30 pointer-events-none"
            referrerPolicy="no-referrer"
          />
          <div className="relative z-10 space-y-3">
            <span className="inline-block text-xs uppercase tracking-widest font-semibold text-pink-300 bg-pink-950/60 border border-pink-700/50 px-3.5 py-1 rounded-full">
              Crisis
            </span>
            <h1 className="text-3xl sm:text-5xl font-serif font-normal text-white">
              You don't have to figure this out alone
            </h1>
            
            <div className="inline-flex items-center gap-2 bg-black/40 backdrop-blur-xs px-4 py-1.5 rounded-full text-xs text-zinc-200 border border-white/20">
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
              <span>escale team • Always here • Immediate help</span>
            </div>
          </div>
        </div>

        {/* Self-check Selector (Not sure if this is a crisis?) */}
        <div className="bg-[#f9f5f8] rounded-[32px] p-6 sm:p-10 shadow-md border border-white/60 space-y-6">
          <div className="space-y-2">
            <span className="text-xs uppercase tracking-widest font-semibold text-[#855b85]">Self-check</span>
            <h2 className="text-2xl sm:text-3xl font-serif font-normal text-[#2b222a]">
              Not sure if this is a crisis?
            </h2>
            <p className="text-xs sm:text-sm text-[#5e4b5d] font-light">
              There is no wrong reason to reach out. If something feels heavy, it matters. See if any of these sound familiar.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-12 gap-6 pt-2">
            {/* Buttons list (4 cols) */}
            <div className="md:col-span-5 space-y-2">
              {feelings.map((f) => (
                <button
                  key={f.id}
                  onClick={() => setSelectedFeeling(f.id)}
                  className={`w-full text-left px-4 py-3 rounded-2xl text-xs sm:text-sm font-medium transition-all cursor-pointer flex items-center justify-between ${
                    selectedFeeling === f.id
                      ? 'bg-[#855b85] text-white shadow-sm font-semibold'
                      : 'bg-white text-[#5e4b5d] hover:bg-[#ebdbe8]'
                  }`}
                >
                  <span>{f.label}</span>
                </button>
              ))}
            </div>

            {/* Active feeling detail card (7 cols) */}
            <div className="md:col-span-7 bg-white rounded-2xl p-6 border border-[#e8dce7] flex flex-col justify-between space-y-4">
              <div className="space-y-3">
                <h3 className="text-xl font-serif font-medium text-[#2b222a]">
                  {current.headline}
                </h3>
                <p className="text-xs sm:text-sm text-[#5e4b5d] leading-relaxed font-light">
                  {current.description}
                </p>
              </div>

              <div className="flex gap-3 pt-2">
                <button
                  onClick={onStartChat}
                  className="px-6 py-2.5 rounded-full bg-[#855b85] text-white font-semibold text-xs hover:bg-[#6e4b6d] transition-all cursor-pointer flex items-center gap-1.5"
                >
                  <MessageSquare className="w-3.5 h-3.5" />
                  <span>Chat</span>
                </button>

                <a
                  href="tel:988"
                  className="px-6 py-2.5 rounded-full border border-[#2b222a] text-[#2b222a] font-semibold text-xs hover:bg-[#2b222a] hover:text-white transition-all cursor-pointer flex items-center gap-1.5"
                >
                  <Phone className="w-3.5 h-3.5" />
                  <span>Call 988</span>
                </a>
              </div>
            </div>
          </div>
        </div>

        {/* 24/7 Lifelines Grid */}
        <div className="space-y-6">
          <div className="text-center space-y-1">
            <span className="text-xs uppercase tracking-widest font-semibold text-[#855b85]">Immediate</span>
            <h2 className="text-2xl sm:text-3xl font-serif font-normal text-[#1f1621]">Help right now</h2>
            <p className="text-xs text-[#4a3649]">Trained counselors ready to listen, any hour, any reason.</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            
            {/* Call 988 */}
            <div className="bg-[#1f1621] text-white rounded-3xl overflow-hidden shadow-lg border border-white/10 flex flex-col justify-between">
              <div className="h-32 overflow-hidden">
                <img 
                  src="https://images.unsplash.com/photo-1582213782179-e0d53f98f2ca?auto=format&fit=crop&w=600&q=80" 
                  alt="Holding hands support" 
                  className="w-full h-full object-cover opacity-80"
                />
              </div>
              <div className="p-6 space-y-4 flex-1 flex flex-col justify-between">
                <div className="space-y-2">
                  <span className="text-xs font-semibold text-pink-300 bg-pink-950/60 px-2.5 py-0.5 rounded-full inline-block">24/7</span>
                  <h3 className="text-xl font-serif font-medium text-white">
                    Call the suicide and crisis lifeline
                  </h3>
                  <p className="text-xs text-zinc-300 font-light leading-relaxed">
                    Free, confidential support for thoughts of suicide or deep distress.
                  </p>
                </div>

                <a
                  href="tel:988"
                  className="inline-flex items-center gap-2 text-xs font-bold text-white bg-white/20 hover:bg-white hover:text-[#1f1621] px-5 py-2.5 rounded-full transition-all text-center justify-center cursor-pointer"
                >
                  <Phone className="w-4 h-4" />
                  <span>Call 988</span>
                </a>
              </div>
            </div>

            {/* Crisis Text Line */}
            <div className="bg-[#1f1621] text-white rounded-3xl overflow-hidden shadow-lg border border-white/10 flex flex-col justify-between">
              <div className="h-32 overflow-hidden">
                <img 
                  src="https://images.unsplash.com/photo-1517841905240-472988babdf9?auto=format&fit=crop&w=600&q=80" 
                  alt="Texting counselor" 
                  className="w-full h-full object-cover opacity-80"
                />
              </div>
              <div className="p-6 space-y-4 flex-1 flex flex-col justify-between">
                <div className="space-y-2">
                  <span className="text-xs font-semibold text-pink-300 bg-pink-950/60 px-2.5 py-0.5 rounded-full inline-block">24/7</span>
                  <h3 className="text-xl font-serif font-medium text-white">
                    Crisis text line
                  </h3>
                  <p className="text-xs text-zinc-300 font-light leading-relaxed">
                    Text with a crisis counselor when speaking feels too hard.
                  </p>
                </div>

                <a
                  href="sms:741741?body=HOME"
                  className="inline-flex items-center gap-2 text-xs font-bold text-white bg-white/20 hover:bg-white hover:text-[#1f1621] px-5 py-2.5 rounded-full transition-all text-center justify-center cursor-pointer"
                >
                  <MessageSquare className="w-4 h-4" />
                  <span>Text HOME to 741741</span>
                </a>
              </div>
            </div>

            {/* Veterans Line */}
            <div className="bg-[#1f1621] text-white rounded-3xl overflow-hidden shadow-lg border border-white/10 flex flex-col justify-between">
              <div className="h-32 overflow-hidden">
                <img 
                  src="https://images.unsplash.com/photo-1529156069898-49953e39b3ac?auto=format&fit=crop&w=600&q=80" 
                  alt="Veterans support" 
                  className="w-full h-full object-cover opacity-80"
                />
              </div>
              <div className="p-6 space-y-4 flex-1 flex flex-col justify-between">
                <div className="space-y-2">
                  <span className="text-xs font-semibold text-pink-300 bg-pink-950/60 px-2.5 py-0.5 rounded-full inline-block">24/7</span>
                  <h3 className="text-xl font-serif font-medium text-white">
                    Veterans crisis line
                  </h3>
                  <p className="text-xs text-zinc-300 font-light leading-relaxed">
                    Specialized support for veterans and their families, always confidential.
                  </p>
                </div>

                <a
                  href="tel:988"
                  className="inline-flex items-center gap-2 text-xs font-bold text-white bg-white/20 hover:bg-white hover:text-[#1f1621] px-5 py-2.5 rounded-full transition-all text-center justify-center cursor-pointer"
                >
                  <Phone className="w-4 h-4" />
                  <span>Call 988 (Press 1)</span>
                </a>
              </div>
            </div>

          </div>
        </div>

        {/* Talk to someone & Need a guide bottom cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 pt-4">
          
          <div className="bg-[#f9f5f8] rounded-3xl p-8 space-y-4 shadow-md border border-white/60">
            <h3 className="text-2xl font-serif font-normal text-[#2b222a]">Talk to someone</h3>
            <p className="text-xs sm:text-sm text-[#5e4b5d] font-light leading-relaxed">
              You don't have to name what you feel. Just start talking. We'll listen and help you find the next step.
            </p>
            <div className="flex gap-3 pt-2">
              <button
                onClick={onStartChat}
                className="px-6 py-2.5 rounded-full bg-[#855b85] text-white text-xs font-semibold hover:bg-[#6e4b6d] transition-all cursor-pointer"
              >
                Chat
              </button>
              <a
                href="tel:18001234567"
                className="px-6 py-2.5 rounded-full border border-[#2b222a] text-[#2b222a] text-xs font-semibold hover:bg-[#2b222a] hover:text-white transition-all cursor-pointer"
              >
                Call
              </a>
            </div>
          </div>

          <div className="bg-[#f9f5f8] rounded-3xl p-8 space-y-4 shadow-md border border-white/60">
            <h3 className="text-2xl font-serif font-normal text-[#2b222a]">Need a guide</h3>
            <p className="text-xs sm:text-sm text-[#5e4b5d] font-light leading-relaxed">
              A navigator can walk you through options, make a call with you, or just sit in the quiet.
            </p>
            <div className="flex gap-3 pt-2">
              <button
                onClick={onStartChat}
                className="px-6 py-2.5 rounded-full bg-[#855b85] text-white text-xs font-semibold hover:bg-[#6e4b6d] transition-all cursor-pointer"
              >
                Connect
              </button>
              <button
                onClick={onOpenHowItWorks}
                className="px-6 py-2.5 rounded-full border border-[#2b222a] text-[#2b222a] text-xs font-semibold hover:bg-[#2b222a] hover:text-white transition-all cursor-pointer"
              >
                Learn
              </button>
            </div>
          </div>

        </div>

      </div>
    </div>
  );
};
