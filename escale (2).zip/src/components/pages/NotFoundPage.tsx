import React from 'react';
import { Compass, Search, Home, MessageSquare, HelpCircle } from 'lucide-react';

interface NotFoundPageProps {
  onGoHome: () => void;
  onBrowse: () => void;
  onStartChat: () => void;
}

export const NotFoundPage: React.FC<NotFoundPageProps> = ({
  onGoHome,
  onBrowse,
  onStartChat,
}) => {
  return (
    <div className="bg-[#b991b5] text-[#1f1621] min-h-screen py-16 px-4 sm:px-6 lg:px-10 flex items-center justify-center">
      <div className="max-w-3xl w-full space-y-12 text-center">
        
        {/* Main 404 Heading */}
        <div className="space-y-4">
          <span className="inline-block text-xs uppercase tracking-widest font-semibold text-[#855b85] bg-[#ebdbe8] px-3.5 py-1 rounded-full">
            Error 404
          </span>
          <h1 className="text-4xl sm:text-6xl font-serif font-normal text-[#1f1621] tracking-tight">
            You've wandered off
          </h1>
          <p className="text-base sm:text-lg text-[#4a3649] font-light max-w-md mx-auto leading-relaxed">
            Don't worry getting lost happens. Let's get you back to the right resources.
          </p>
        </div>

        {/* 2 Action Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          
          <div className="bg-[#f9f5f8] rounded-3xl p-8 space-y-4 shadow-md border border-white/60 flex flex-col justify-between text-left">
            <div className="space-y-3">
              <Compass className="w-8 h-8 text-[#855b85]" />
              <h3 className="text-2xl font-serif font-normal text-[#2b222a]">
                Find your way
              </h3>
              <p className="text-xs sm:text-sm text-[#5e4b5d] font-light leading-relaxed">
                The path back is simple. Start fresh or find the exact resource you need.
              </p>
            </div>

            <div className="flex gap-3 pt-4">
              <button
                onClick={onGoHome}
                className="px-6 py-2.5 rounded-full bg-[#1f1621] text-white font-medium text-xs hover:bg-[#382b3a] transition-all cursor-pointer flex items-center gap-1.5"
              >
                <Home className="w-3.5 h-3.5" />
                <span>Home</span>
              </button>

              <button
                onClick={onBrowse}
                className="px-6 py-2.5 rounded-full border border-[#1f1621] text-[#1f1621] font-medium text-xs hover:bg-[#1f1621] hover:text-white transition-all cursor-pointer flex items-center gap-1.5"
              >
                <Search className="w-3.5 h-3.5" />
                <span>Search</span>
              </button>
            </div>
          </div>

          <div className="bg-[#f9f5f8] rounded-3xl p-8 space-y-4 shadow-md border border-white/60 flex flex-col justify-between text-left">
            <div className="space-y-3">
              <MessageSquare className="w-8 h-8 text-[#855b85]" />
              <h3 className="text-2xl font-serif font-normal text-[#2b222a]">
                Need help now
              </h3>
              <p className="text-xs sm:text-sm text-[#5e4b5d] font-light leading-relaxed">
                If this moment feels too heavy, someone is ready to listen right now.
              </p>
            </div>

            <div className="pt-4">
              <button
                onClick={onStartChat}
                className="px-8 py-2.5 rounded-full bg-[#855b85] text-white font-semibold text-xs hover:bg-[#6e4b6d] transition-all cursor-pointer flex items-center gap-1.5 shadow-sm"
              >
                <MessageSquare className="w-3.5 h-3.5" />
                <span>Chat</span>
              </button>
            </div>
          </div>

        </div>

      </div>
    </div>
  );
};
