import React, { useState } from 'react';
import { CheckCircle2, ChevronDown, ChevronUp, Send, HelpCircle, ShieldCheck } from 'lucide-react';
import verifyImage from '../../assets/images/exact_verify_man_laptop_1786494760483.jpg';

interface RegisterResourcePageProps {
  onOpenContact: () => void;
  onOpenHowItWorks: () => void;
}

export const RegisterResourcePage: React.FC<RegisterResourcePageProps> = ({
  onOpenContact,
  onOpenHowItWorks,
}) => {
  const [formData, setFormData] = useState({
    organization: '',
    email: '',
    focus: '',
    agreeReverification: false,
  });

  const [submitted, setSubmitted] = useState(false);
  const [openFaqIndex, setOpenFaqIndex] = useState<number | null>(0);

  const faqs = [
    {
      q: 'What does verified mean?',
      a: 'It means we checked you out. We confirm your organization is real, your services are active, and your focus areas match what you claim. No aggregation, no scraping. A human reviews every submission.',
    },
    {
      q: 'How often do you recheck?',
      a: 'Every listing gets a fresh review on a set cadence. You will hear from us when it is time. If your capacity or wait times shift before then, you are expected to tell us.',
    },
    {
      q: 'Who can register a resource?',
      a: 'Peer support groups, licensed clinicians, digital tool builders, and affordable care providers. Your service must be active, accessible, and relevant to early-career burnout. We do not list unvetted forums or pure marketing pages.',
    },
    {
      q: 'How do I report changes?',
      a: 'Use the contact form on our community support page. Flag a broken link, a waitlist closure, or a shift in focus. We act on these reports fast because a stale resource helps no one.',
    },
    {
      q: 'Is my listing permanent?',
      a: 'No. If you fail re-verification or stop responding, we pull the listing. We keep the directory small and trustworthy. That means we have to say no sometimes.',
    },
  ];

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.agreeReverification) {
      alert('Please agree to periodic re-verification to submit your resource.');
      return;
    }
    setSubmitted(true);
  };

  return (
    <div className="bg-[#b991b5] text-[#1f1621] min-h-screen py-12 sm:py-16 px-4 sm:px-6 lg:px-10">
      <div className="max-w-4xl mx-auto space-y-12">
        
        {/* Verification Banner */}
        <div className="bg-[#705072] text-white rounded-[32px] sm:rounded-[40px] overflow-hidden grid grid-cols-1 md:grid-cols-12 shadow-xl border border-white/20">
          <div className="md:col-span-5 relative min-h-[220px] md:min-h-full">
            <img 
              src={verifyImage} 
              alt="Person working on laptop in cozy armchair with plants" 
              className="absolute inset-0 w-full h-full object-cover"
              referrerPolicy="no-referrer"
            />
          </div>
          <div className="md:col-span-7 p-8 sm:p-10 flex flex-col justify-center space-y-4">
            <div className="inline-flex items-center gap-2 self-start text-xs uppercase tracking-widest font-semibold text-zinc-100 bg-white/20 backdrop-blur-xs px-3.5 py-1 rounded-full">
              <ShieldCheck className="w-3.5 h-3.5" />
              Verify
            </div>
            <h1 className="text-3xl sm:text-4xl font-serif font-normal text-white leading-tight">
              Every resource is checked and dated, never just aggregated
            </h1>
            <p className="text-xs sm:text-sm text-zinc-100/90 leading-relaxed font-light">
              Help early-career professionals find your verified peer group, digital tool, or affordable care service.
            </p>
            <div className="pt-2 flex gap-3">
              <button
                onClick={() => {
                  const el = document.getElementById('registration-form');
                  if (el) el.scrollIntoView({ behavior: 'smooth' });
                }}
                className="px-6 py-2.5 rounded-full bg-white text-[#1f1621] font-semibold text-xs hover:bg-zinc-100 transition-all cursor-pointer shadow-sm"
              >
                Register a Resource
              </button>
              <button
                onClick={onOpenHowItWorks}
                className="px-6 py-2.5 rounded-full border border-white/60 text-white font-medium text-xs hover:bg-white/10 transition-all cursor-pointer"
              >
                Learn More
              </button>
            </div>
          </div>
        </div>

        {/* Registration Form Box */}
        <div id="registration-form" className="bg-[#f9f5f8] rounded-[32px] p-6 sm:p-10 shadow-lg border border-white/60 space-y-6">
          <div className="border-b border-[#e3d7e2] pb-4">
            <span className="text-xs uppercase tracking-widest font-semibold text-[#855b85]">List</span>
            <h2 className="text-2xl font-serif font-normal text-[#2b222a]">Your resource</h2>
            <p className="text-xs sm:text-sm text-[#5e4b5d] font-light">
              We verify everything. Here is how to get started.
            </p>
          </div>

          {submitted ? (
            <div className="p-8 text-center bg-white rounded-2xl space-y-4 border border-[#e8dce7]">
              <CheckCircle2 className="w-12 h-12 text-[#855b85] mx-auto" />
              <h3 className="text-2xl font-serif font-medium text-[#2b222a]">Submission received</h3>
              <p className="text-sm text-[#5e4b5d] max-w-md mx-auto">
                Thank you for submitting <strong>{formData.organization}</strong>. Our vetting team will review your details and reach out to <strong>{formData.email}</strong> within 3 business days.
              </p>
              <button
                onClick={() => setSubmitted(false)}
                className="px-6 py-2 rounded-full bg-[#2b222a] text-white text-xs font-semibold hover:bg-[#423341] cursor-pointer"
              >
                Submit another resource
              </button>
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="space-y-6">
              <div>
                <label className="block text-xs font-semibold text-[#5e4b5d] mb-1">Organization</label>
                <input
                  type="text"
                  required
                  value={formData.organization}
                  onChange={e => setFormData({ ...formData, organization: e.target.value })}
                  placeholder="Organization or Group name"
                  className="w-full px-4 py-2.5 rounded-xl bg-white border border-[#e3d7e2] text-sm focus:outline-none focus:ring-2 focus:ring-[#855b85]"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-[#5e4b5d] mb-1">Email</label>
                <input
                  type="email"
                  required
                  value={formData.email}
                  onChange={e => setFormData({ ...formData, email: e.target.value })}
                  placeholder="contact@organization.org"
                  className="w-full px-4 py-2.5 rounded-xl bg-white border border-[#e3d7e2] text-sm focus:outline-none focus:ring-2 focus:ring-[#855b85]"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-[#5e4b5d] mb-1">Focus</label>
                <textarea
                  required
                  rows={4}
                  value={formData.focus}
                  onChange={e => setFormData({ ...formData, focus: e.target.value })}
                  placeholder="Describe your service..."
                  className="w-full px-4 py-2.5 rounded-xl bg-white border border-[#e3d7e2] text-sm focus:outline-none focus:ring-2 focus:ring-[#855b85]"
                />
              </div>

              <div className="flex items-center gap-2">
                <input
                  type="checkbox"
                  id="agreeReverification"
                  checked={formData.agreeReverification}
                  onChange={e => setFormData({ ...formData, agreeReverification: e.target.checked })}
                  className="w-4 h-4 rounded text-[#855b85] focus:ring-[#855b85]"
                />
                <label htmlFor="agreeReverification" className="text-xs text-[#5e4b5d]">
                  I agree to periodic re-verification
                </label>
              </div>

              <div>
                <button
                  type="submit"
                  className="px-8 py-3 rounded-full bg-[#855b85] text-white hover:bg-[#6e4b6d] font-semibold text-sm transition-all cursor-pointer shadow-md flex items-center gap-2"
                >
                  <Send className="w-4 h-4" />
                  <span>Submit</span>
                </button>
              </div>
            </form>
          )}
        </div>

        {/* FAQs Accordion */}
        <div className="space-y-6">
          <div className="space-y-1">
            <h2 className="text-2xl sm:text-3xl font-serif font-normal text-[#1f1621]">FAQs</h2>
            <p className="text-xs sm:text-sm text-[#4a3649]">
              The straight story on how we vet, verify, and keep your listing fresh.
            </p>
          </div>

          <div className="space-y-3">
            {faqs.map((faq, idx) => (
              <div
                key={idx}
                className="bg-[#f9f5f8] rounded-2xl border border-white/60 overflow-hidden shadow-xs"
              >
                <button
                  onClick={() => setOpenFaqIndex(openFaqIndex === idx ? null : idx)}
                  className="w-full p-5 text-left flex items-center justify-between font-serif font-medium text-base text-[#2b222a] hover:bg-[#ebdbe8]/40 transition-colors cursor-pointer"
                >
                  <span>{faq.q}</span>
                  {openFaqIndex === idx ? (
                    <ChevronUp className="w-4 h-4 text-[#855b85]" />
                  ) : (
                    <ChevronDown className="w-4 h-4 text-[#855b85]" />
                  )}
                </button>

                {openFaqIndex === idx && (
                  <div className="p-5 pt-0 text-xs sm:text-sm text-[#5e4b5d] font-light leading-relaxed border-t border-[#e3d7e2]/50">
                    {faq.a}
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>

        {/* Bottom CTA */}
        <div className="bg-[#1f1621] text-white rounded-3xl p-8 text-center space-y-4 shadow-lg">
          <h3 className="text-2xl font-serif font-normal text-white">Still have questions?</h3>
          <p className="text-xs sm:text-sm text-zinc-300 font-light">
            Reach out directly. A real person reads every message.
          </p>
          <div>
            <button
              onClick={onOpenContact}
              className="px-7 py-2.5 rounded-full bg-white text-[#1f1621] hover:bg-zinc-100 font-semibold text-xs transition-all cursor-pointer shadow-sm"
            >
              Contact
            </button>
          </div>
        </div>

      </div>
    </div>
  );
};
