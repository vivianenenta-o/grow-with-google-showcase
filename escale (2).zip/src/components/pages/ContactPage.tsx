import React, { useState } from 'react';
import { Mail, MessageSquare, Phone, MapPin, CheckCircle2, Send, AlertCircle } from 'lucide-react';

interface ContactPageProps {
  onStartChat: () => void;
  onOpenTerms: () => void;
}

export const ContactPage: React.FC<ContactPageProps> = ({ onStartChat, onOpenTerms }) => {
  const [formData, setFormData] = useState({
    firstName: '',
    lastName: '',
    email: '',
    phone: '',
    topic: 'general',
    userRole: 'Seeker',
    message: '',
    acceptedTerms: false,
  });

  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.acceptedTerms) {
      alert('Please accept the terms to submit your message.');
      return;
    }
    setSubmitted(true);
  };

  return (
    <div className="bg-[#b991b5] text-[#1f1621] min-h-screen py-12 sm:py-16 px-4 sm:px-6 lg:px-10">
      <div className="max-w-4xl mx-auto space-y-12">
        
        {/* Top Header */}
        <div className="text-center space-y-4">
          <span className="inline-block text-xs uppercase tracking-widest font-semibold text-[#855b85] bg-[#ebdbe8] px-3.5 py-1 rounded-full">
            Contact
          </span>
          <h1 className="text-4xl sm:text-5xl font-serif font-normal text-[#1f1621] tracking-tight">
            We're here to listen
          </h1>
          <p className="text-base sm:text-lg text-[#4a3649] font-light max-w-xl mx-auto leading-relaxed">
            Your voice keeps escale safe, current, and truly helpful for everyone navigating burnout.
          </p>

          <div className="flex justify-center gap-3 pt-2">
            <button 
              onClick={() => {
                setFormData(prev => ({ ...prev, topic: 'feedback' }));
                window.scrollTo({ top: 350, behavior: 'smooth' });
              }}
              className="px-5 py-2 rounded-full bg-white text-[#1f1621] text-xs font-semibold hover:bg-zinc-100 transition-all cursor-pointer shadow-sm"
            >
              Share feedback
            </button>
            <button 
              onClick={() => {
                setFormData(prev => ({ ...prev, topic: 'report' }));
                window.scrollTo({ top: 350, behavior: 'smooth' });
              }}
              className="px-5 py-2 rounded-full border border-[#1f1621] text-[#1f1621] text-xs font-medium hover:bg-[#1f1621] hover:text-white transition-all cursor-pointer"
            >
              Report a listing
            </button>
          </div>
        </div>

        {/* Main Form Box */}
        <div className="bg-[#f9f5f8] rounded-[32px] p-6 sm:p-10 shadow-lg border border-white/60 space-y-6">
          <div className="border-b border-[#e3d7e2] pb-4">
            <h2 className="text-2xl font-serif font-normal text-[#2b222a]">Get in touch</h2>
            <p className="text-xs sm:text-sm text-[#5e4b5d] font-light">
              Your voice keeps escale safe, current, and truly helpful.
            </p>
          </div>

          {submitted ? (
            <div className="p-8 text-center bg-white rounded-2xl space-y-4 border border-[#e8dce7]">
              <CheckCircle2 className="w-12 h-12 text-[#855b85] mx-auto" />
              <h3 className="text-2xl font-serif font-medium text-[#2b222a]">Message received</h3>
              <p className="text-sm text-[#5e4b5d] max-w-md mx-auto">
                Thank you for reaching out. A human navigator from our Sydney team will reply to <strong>{formData.email}</strong> within one business day.
              </p>
              <button
                onClick={() => setSubmitted(false)}
                className="px-6 py-2 rounded-full bg-[#2b222a] text-white text-xs font-semibold hover:bg-[#423341] cursor-pointer"
              >
                Send another message
              </button>
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="space-y-6">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-[#5e4b5d] mb-1">First name</label>
                  <input
                    type="text"
                    required
                    value={formData.firstName}
                    onChange={e => setFormData({ ...formData, firstName: e.target.value })}
                    placeholder="Enter first name"
                    className="w-full px-4 py-2.5 rounded-xl bg-white border border-[#e3d7e2] text-sm focus:outline-none focus:ring-2 focus:ring-[#855b85]"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-[#5e4b5d] mb-1">Last name</label>
                  <input
                    type="text"
                    required
                    value={formData.lastName}
                    onChange={e => setFormData({ ...formData, lastName: e.target.value })}
                    placeholder="Enter last name"
                    className="w-full px-4 py-2.5 rounded-xl bg-white border border-[#e3d7e2] text-sm focus:outline-none focus:ring-2 focus:ring-[#855b85]"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-[#5e4b5d] mb-1">Email</label>
                  <input
                    type="email"
                    required
                    value={formData.email}
                    onChange={e => setFormData({ ...formData, email: e.target.value })}
                    placeholder="yourname@example.com"
                    className="w-full px-4 py-2.5 rounded-xl bg-white border border-[#e3d7e2] text-sm focus:outline-none focus:ring-2 focus:ring-[#855b85]"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-[#5e4b5d] mb-1">Phone number</label>
                  <input
                    type="tel"
                    value={formData.phone}
                    onChange={e => setFormData({ ...formData, phone: e.target.value })}
                    placeholder="+1 (555) 000-0000"
                    className="w-full px-4 py-2.5 rounded-xl bg-white border border-[#e3d7e2] text-sm focus:outline-none focus:ring-2 focus:ring-[#855b85]"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-[#5e4b5d] mb-1">Choose a topic</label>
                <select
                  value={formData.topic}
                  onChange={e => setFormData({ ...formData, topic: e.target.value })}
                  className="w-full px-4 py-2.5 rounded-xl bg-white border border-[#e3d7e2] text-sm focus:outline-none focus:ring-2 focus:ring-[#855b85]"
                >
                  <option value="general">Select one...</option>
                  <option value="feedback">General Feedback & Suggestion</option>
                  <option value="report">Report a Stale or Broken Listing</option>
                  <option value="partnership">Peer Group Partnership</option>
                  <option value="press">Press & Research Inquiry</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-semibold text-[#5e4b5d] mb-2">Which best describes you?</label>
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                  {['Seeker', 'Caregiver / Ally', 'Clinician', 'Employer / HR', 'Other'].map((role) => (
                    <label
                      key={role}
                      className={`flex items-center gap-2 p-2.5 rounded-xl border text-xs font-medium cursor-pointer transition-colors ${
                        formData.userRole === role
                          ? 'bg-[#855b85] text-white border-[#855b85]'
                          : 'bg-white text-[#5e4b5d] border-[#e3d7e2] hover:bg-zinc-50'
                      }`}
                    >
                      <input
                        type="radio"
                        name="userRole"
                        value={role}
                        checked={formData.userRole === role}
                        onChange={() => setFormData({ ...formData, userRole: role })}
                        className="sr-only"
                      />
                      <span>{role}</span>
                    </label>
                  ))}
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-[#5e4b5d] mb-1">Message</label>
                <textarea
                  required
                  rows={4}
                  value={formData.message}
                  onChange={e => setFormData({ ...formData, message: e.target.value })}
                  placeholder="Type your message..."
                  className="w-full px-4 py-2.5 rounded-xl bg-white border border-[#e3d7e2] text-sm focus:outline-none focus:ring-2 focus:ring-[#855b85]"
                />
              </div>

              <div className="flex items-center gap-2">
                <input
                  type="checkbox"
                  id="acceptedTerms"
                  checked={formData.acceptedTerms}
                  onChange={e => setFormData({ ...formData, acceptedTerms: e.target.checked })}
                  className="w-4 h-4 rounded text-[#855b85] focus:ring-[#855b85]"
                />
                <label htmlFor="acceptedTerms" className="text-xs text-[#5e4b5d]">
                  I accept the <button type="button" onClick={onOpenTerms} className="underline text-[#855b85]">Terms and Conditions</button>
                </label>
              </div>

              <div>
                <button
                  type="submit"
                  className="px-8 py-3 rounded-full bg-[#855b85] text-white hover:bg-[#6e4b6d] font-semibold text-sm transition-all cursor-pointer shadow-md flex items-center gap-2"
                >
                  <Send className="w-4 h-4" />
                  <span>Submit</span>
                </button>
              </div>
            </form>
          )}
        </div>

        {/* Crisis Contact Channels Grid */}
        <div className="space-y-6">
          <div className="text-center space-y-1">
            <span className="text-xs uppercase tracking-widest font-semibold text-[#855b85]">Crisis</span>
            <h3 className="text-2xl font-serif font-normal text-[#1f1621]">Need help now?</h3>
            <p className="text-xs text-[#4a3649]">Do not wait for a reply. Reach a human immediately.</p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            
            {/* Email */}
            <div className="bg-[#1f1621] text-white p-6 rounded-2xl space-y-3 shadow-md flex flex-col justify-between">
              <div>
                <Mail className="w-6 h-6 text-purple-300 mb-2" />
                <h4 className="font-serif font-medium text-lg">Email</h4>
                <p className="text-xs text-zinc-300 font-light mt-1">
                  Send us a note and we will reply within one business day.
                </p>
              </div>
              <p className="text-xs text-purple-200 font-mono pt-2">hello@escale.com</p>
            </div>

            {/* Live Chat */}
            <div className="bg-[#1f1621] text-white p-6 rounded-2xl space-y-3 shadow-md flex flex-col justify-between">
              <div>
                <MessageSquare className="w-6 h-6 text-purple-300 mb-2" />
                <h4 className="font-serif font-medium text-lg">Live chat</h4>
                <p className="text-xs text-zinc-300 font-light mt-1">
                  Talk to a real person right now. No queue, no forms.
                </p>
              </div>
              <button
                onClick={onStartChat}
                className="text-xs text-white font-semibold underline text-left hover:text-purple-200 cursor-pointer pt-2"
              >
                Start new chat
              </button>
            </div>

            {/* Phone */}
            <div className="bg-[#1f1621] text-white p-6 rounded-2xl space-y-3 shadow-md flex flex-col justify-between">
              <div>
                <Phone className="w-6 h-6 text-purple-300 mb-2" />
                <h4 className="font-serif font-medium text-lg">Phone</h4>
                <p className="text-xs text-zinc-300 font-light mt-1">
                  Prefer to hear a voice? We answer with no hold time.
                </p>
              </div>
              <p className="text-xs text-purple-200 font-mono pt-2">+1 (555) 000-0000</p>
            </div>

            {/* Office */}
            <div className="bg-[#1f1621] text-white p-6 rounded-2xl space-y-3 shadow-md flex flex-col justify-between">
              <div>
                <MapPin className="w-6 h-6 text-purple-300 mb-2" />
                <h4 className="font-serif font-medium text-lg">Office</h4>
                <p className="text-xs text-zinc-300 font-light mt-1">
                  Our door is open if you need to sit and talk.
                </p>
              </div>
              <p className="text-xs text-purple-200 font-mono pt-2">123 Sample St, Sydney NSW 2000 AU</p>
            </div>

          </div>
        </div>

      </div>
    </div>
  );
};
