import React from 'react';
import { ShieldCheck, Lock, EyeOff, UserX, ArrowRight, ArrowLeft } from 'lucide-react';

interface PrivacyPageProps {
  onStartQuiz: () => void;
  onOpenHowItWorks: () => void;
  onGoBack?: () => void;
}

export const PrivacyPage: React.FC<PrivacyPageProps> = ({
  onStartQuiz,
  onOpenHowItWorks,
  onGoBack,
}) => {
  return (
    <div className="bg-[#b991b5] text-[#1f1621] min-h-screen py-12 sm:py-16 px-4 sm:px-6 lg:px-10">
      <div className="max-w-4xl mx-auto space-y-12">
        
        {/* Top Banner */}
        <div className="text-center space-y-4">
          <span className="inline-block text-xs uppercase tracking-widest font-semibold text-[#855b85] bg-[#ebdbe8] px-3.5 py-1 rounded-full">
            Privacy
          </span>
          <h1 className="text-4xl sm:text-5xl font-serif font-normal text-[#1f1621] tracking-tight">
            Your story stays yours
          </h1>
          <p className="text-base sm:text-lg text-[#4a3649] font-light max-w-2xl mx-auto leading-relaxed">
            We built escale so you could speak freely. Nothing you share is ever tied back to your name or workplace. Confidentiality is the foundation of our mission.
          </p>
        </div>

        {/* 3 Privacy Pillars Grid with Image Side-by-Side (Matching Page 9 in PDF) */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-stretch">
          
          <div className="lg:col-span-7 space-y-4">
            <div className="bg-[#f9f5f8] rounded-3xl p-6 sm:p-8 space-y-2 shadow-md border border-white/60">
              <UserX className="w-6 h-6 text-[#855b85]" />
              <h3 className="text-lg font-serif font-medium text-[#2b222a]">
                We never track or store identifying information
              </h3>
              <p className="text-xs sm:text-sm text-[#5e4b5d] leading-relaxed font-light">
                The quiz asks what you are feeling, not who you are. There are no accounts to create and no personal details required.
              </p>
            </div>

            <div className="bg-[#f9f5f8] rounded-3xl p-6 sm:p-8 space-y-2 shadow-md border border-white/60">
              <EyeOff className="w-6 h-6 text-[#855b85]" />
              <h3 className="text-lg font-serif font-medium text-[#2b222a]">
                Your employer cannot see anything you share
              </h3>
              <p className="text-xs sm:text-sm text-[#5e4b5d] leading-relaxed font-light">
                This is a space separate from your job. No data is ever reported, sold, or fed back to any company.
              </p>
            </div>

            <div className="bg-[#f9f5f8] rounded-3xl p-6 sm:p-8 space-y-2 shadow-md border border-white/60">
              <Lock className="w-6 h-6 text-[#855b85]" />
              <h3 className="text-lg font-serif font-medium text-[#2b222a]">
                You decide what happens with every answer
              </h3>
              <p className="text-xs sm:text-sm text-[#5e4b5d] leading-relaxed font-light">
                There is no permanent record. You can leave at any time and nothing you typed remains.
              </p>
            </div>
          </div>

          <div className="lg:col-span-5 rounded-3xl overflow-hidden shadow-lg border border-white/60 min-h-[320px]">
            <img 
              src="/src/assets/images/privacy_woman_headband_1786491362314.jpg" 
              alt="Woman smiling outdoors with headband" 
              className="w-full h-full object-cover" 
              referrerPolicy="no-referrer"
            />
          </div>

        </div>

        {/* Detailed Plain Language Policy Card (Matching Page 13) */}
        <div className="bg-[#1f1621] text-white rounded-[32px] sm:rounded-[40px] p-8 sm:p-12 space-y-6 shadow-2xl border border-white/10">
          <h2 className="text-3xl font-serif font-normal text-white">
            Your privacy, plainly stated
          </h2>

          <div className="space-y-4 text-xs sm:text-sm text-zinc-300 font-light leading-relaxed">
            <p>
              We built escale because getting help should feel safe, not exposed. Your privacy is the foundation of that promise. We collect only what we need to route you to the right support. Your quiz answers are anonymous. They are never tied to your name, your email, or anything that could identify you. We do not share your data with employers. Not now, not ever. There is no backdoor, no dashboard for HR, no report that leaves this house.
            </p>

            <p>
              We use your answers to match you with verified resources. That is it. We do not sell your information. We do not trade it. We do not let advertisers anywhere near it. The quiz is a compass, not a surveillance tool. You can take it without creating an account. You can leave at any time. Nothing lingers.
            </p>

            <p>
              If you choose to contact a navigator or use the "talk to someone" feature, that conversation stays between you and the person helping. We do not record it. We do not store transcripts. We do not analyze it for patterns. It is a human moment, and it deserves to stay that way.
            </p>

            <p>
              We use a few essential cookies to keep the site running smoothly. They remember things like your place in the quiz so you do not lose progress. They do not track you across the web. They do not build a profile. You can block them in your browser, but some parts of the site may not work as intended.
            </p>

            <p>
              We protect your data with encryption and regular security reviews. If something changes, we will tell you here, in plain language, before it takes effect. You deserve to know. If you have questions, reach out through our contact page. We will answer like a real person, because we are.
            </p>
          </div>

          <div className="pt-4 flex items-center justify-between">
            {onGoBack && (
              <button
                onClick={onGoBack}
                className="px-6 py-2.5 rounded-full bg-white/10 hover:bg-white/20 text-white font-medium text-xs flex items-center gap-2 transition-all cursor-pointer"
              >
                <ArrowLeft className="w-4 h-4" />
                <span>Back</span>
              </button>
            )}

            <button
              onClick={onStartQuiz}
              className="px-8 py-3 rounded-full bg-white text-[#1f1621] hover:bg-zinc-100 font-semibold text-xs flex items-center gap-2 transition-all cursor-pointer shadow-md"
            >
              <span>Take the quiz</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        </div>

      </div>
    </div>
  );
};
