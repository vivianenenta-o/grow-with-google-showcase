import React, { useState } from 'react';
import { AlertTriangle, ShieldCheck, FileText, ArrowRight } from 'lucide-react';

interface TermsPageProps {
  onOpenCrisis: () => void;
}

export const TermsPage: React.FC<TermsPageProps> = ({ onOpenCrisis }) => {
  const [activeSection, setActiveSection] = useState('agreement');

  const scrollToSection = (id: string) => {
    setActiveSection(id);
    const element = document.getElementById(id);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
  };

  return (
    <div className="bg-[#b991b5] text-[#1f1621] min-h-screen py-12 sm:py-16 px-4 sm:px-6 lg:px-10">
      <div className="max-w-7xl mx-auto grid grid-cols-1 lg:grid-cols-12 gap-8">
        
        {/* Sticky Sidebar Menu (3 cols) */}
        <div className="lg:col-span-4">
          <div className="bg-[#f9f5f8] rounded-3xl p-6 shadow-md border border-white/60 sticky top-28 space-y-4">
            <h3 className="text-xs uppercase tracking-widest font-semibold text-[#855b85]">
              On this page
            </h3>

            <nav className="space-y-1 text-sm">
              {[
                { id: 'agreement', label: 'Our agreement' },
                { id: 'what-we-do', label: 'What we do' },
                { id: 'what-we-dont', label: 'What we don\'t' },
                { id: 'responsibility', label: 'Your responsibility' },
                { id: 'promise', label: 'Our promise' },
              ].map((item) => (
                <button
                  key={item.id}
                  onClick={() => scrollToSection(item.id)}
                  className={`w-full text-left px-4 py-2.5 rounded-xl font-medium transition-colors cursor-pointer ${
                    activeSection === item.id
                      ? 'bg-[#855b85] text-white font-semibold'
                      : 'text-[#5e4b5d] hover:bg-[#ebdbe8]'
                  }`}
                >
                  {item.label}
                </button>
              ))}
            </nav>

            <div className="pt-4 border-t border-[#e3d7e2] space-y-2">
              <p className="text-xs text-[#786377]">In an emergency?</p>
              <button
                onClick={onOpenCrisis}
                className="w-full py-2 rounded-full bg-red-600 text-white text-xs font-semibold hover:bg-red-700 transition-colors cursor-pointer flex items-center justify-center gap-1.5"
              >
                <AlertTriangle className="w-3.5 h-3.5" />
                <span>Get Immediate Crisis Help</span>
              </button>
            </div>
          </div>
        </div>

        {/* Main Terms Document Body (8 cols) */}
        <div className="lg:col-span-8 space-y-10">
          
          {/* Header Card */}
          <div id="agreement" className="bg-[#f9f5f8] rounded-[32px] p-8 sm:p-10 shadow-md border border-white/60 space-y-4">
            <span className="inline-block text-xs uppercase tracking-widest font-semibold text-[#855b85] bg-[#ebdbe8] px-3.5 py-1 rounded-full">
              Legal
            </span>
            <h1 className="text-3xl sm:text-4xl font-serif font-normal text-[#2b222a]">
              Terms of Service & Non-Clinical Disclaimer
            </h1>
            <p className="text-sm sm:text-base text-[#5e4b5d] leading-relaxed font-light">
              Escale is a navigation, directory, and routing platform. We do not provide medical advice, psychotherapy, clinical diagnosis, or emergency healthcare services. By accessing or using Escale, you acknowledge and agree that all content, signposting recommendations, and self-guided tools provided on this site are for informational and educational purposes only, and do not establish a doctor-patient, therapist-client, or licensed healthcare relationship.
            </p>
            <p className="text-sm sm:text-base text-[#5e4b5d] leading-relaxed font-light">
              Escale was built to simplify the overwhelming search for burnout recovery and mental health support. While we thoroughly research, hand-vet, and date-stamp every resource in our directory, we do not manage, monitor, or deliver the third-party services listed.
            </p>
          </div>

          {/* Emergency Section */}
          <div id="what-we-do" className="bg-[#1f1621] text-white rounded-[32px] p-8 sm:p-10 shadow-xl border border-white/10 space-y-4">
            <h2 className="text-2xl font-serif font-normal text-white flex items-center gap-2">
              <AlertTriangle className="w-5 h-5 text-red-400" />
              Emergency & Crisis Safety
            </h2>
            <p className="text-sm text-zinc-300 leading-relaxed font-light">
              If you are experiencing a mental health crisis, having thoughts of self-harm, or feel unsafe being alone right now, please do not wait for a response from Escale or rely on our directory. Immediately call or text <strong>988</strong> to reach the Suicide & Crisis Lifeline (US & Canada), text <strong>HOME</strong> to <strong>741741</strong> to connect with the Crisis Text Line, or call <strong>911</strong> / visit your nearest emergency room.
            </p>
            <p className="text-sm text-zinc-300 leading-relaxed font-light">
              Escale does not offer real-time crisis monitoring, clinical triage, or emergency dispatch. Our platform is designed strictly for non-emergency routing, low-sensory navigation, and resource discovery during stable, low-acuity moments.
            </p>
          </div>

          {/* Directory Vetting Section */}
          <div id="what-we-dont" className="bg-[#f9f5f8] rounded-[32px] p-8 sm:p-10 shadow-md border border-white/60 space-y-4">
            <h2 className="text-2xl font-serif font-normal text-[#2b222a]">
              Directory Vetting & Third-Party Services
            </h2>
            <p className="text-sm text-[#5e4b5d] leading-relaxed font-light">
              While our team personally audits and date-stamps the resources across our platform to eliminate dead links and outdated information, Escale cannot guarantee the ongoing capacity, financial pricing, or clinical quality of external providers.
            </p>
            <div className="rounded-2xl overflow-hidden shadow-sm my-4 border border-[#e3d7e2]">
              <img 
                src="/src/assets/images/terms_planner_hands_1786491398915.jpg" 
                alt="Businessperson in suit holding organized planner with tabs" 
                className="w-full h-48 sm:h-64 object-cover" 
                referrerPolicy="no-referrer"
              />
            </div>
          </div>

          {/* User Choice Section */}
          <div id="responsibility" className="bg-[#f9f5f8] rounded-[32px] p-8 sm:p-10 shadow-md border border-white/60 space-y-4">
            <h2 className="text-2xl font-serif font-normal text-[#2b222a]">
              User Choice & Platform Boundaries
            </h2>
            <p className="text-sm text-[#5e4b5d] leading-relaxed font-light">
              You remain in full control of your healthcare choices, boundary management, and support decisions. Escale provides curated options to reduce cognitive load and decision fatigue, but selecting, contacting, and engaging with any listed service remains entirely your personal responsibility.
            </p>
            <blockquote className="border-l-4 border-[#855b85] pl-4 py-2 italic text-sm text-[#3b2d3a] bg-[#ebdbe8]/50 rounded-r-xl">
              "We route, we do not treat. Escale exists to clear the path and lower the noise, leaving clinical care, diagnoses, and ultimate health decisions in the hands of you and qualified professionals."
            </blockquote>
          </div>

          {/* Updates Section */}
          <div id="promise" className="bg-[#f9f5f8] rounded-[32px] p-8 sm:p-10 shadow-md border border-white/60 space-y-4">
            <h2 className="text-2xl font-serif font-normal text-[#2b222a]">
              Updates to these Terms
            </h2>
            <p className="text-sm text-[#5e4b5d] leading-relaxed font-light">
              We periodically update this agreement to reflect new platform features, directory standards, or regulatory guidelines. Continued use of Escale following any posted updates signifies your acceptance of the revised terms. For questions regarding our vetting criteria or platform terms, please contact us at <strong>legal@escale.app</strong>.
            </p>
          </div>

        </div>

      </div>
    </div>
  );
};
