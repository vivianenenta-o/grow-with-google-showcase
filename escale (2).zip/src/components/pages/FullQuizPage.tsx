import React, { useState } from 'react';
import { ArrowRight, ArrowLeft, CheckCircle2, ShieldCheck, MapPin, Mail, Sparkles, RefreshCw, Bookmark, Share2 } from 'lucide-react';
import { PeerGroup } from '../../types';
import { PEER_GROUPS } from '../../data/mockData';

interface FullQuizPageProps {
  onSelectGroup: (group: PeerGroup) => void;
  onTalkToSomeone: () => void;
  onGoHome: () => void;
}

export const FullQuizPage: React.FC<FullQuizPageProps> = ({
  onSelectGroup,
  onTalkToSomeone,
  onGoHome,
}) => {
  const [currentStep, setCurrentStep] = useState(1);
  const [showResults, setShowResults] = useState(false);
  const [activeCategoryFilter, setActiveCategoryFilter] = useState('all');

  // Answers State
  const [answers, setAnswers] = useState({
    whoFor: 'Myself',
    feeling: 'Exhausted',
    context: 'Corporate',
    spaceType: 'Peer Connection',
    coverage: 'Sliding Scale Options',
    locationPref: 'Telehealth / Virtual',
    concerns: ['Burnout Recovery & Stress Management'],
    zipOrCity: '',
    email: '',
  });

  const stepsData = [
    {
      stepNum: '01',
      tag: 'Who first',
      title: 'Who are you here for today?',
      subtitle: 'Choose if this is for yourself, someone you care about, or someone you support professionally. The words change but the path stays the same.',
      type: 'single',
      options: ['Myself', 'Someone else', 'Someone I support'],
      field: 'whoFor',
      image: 'https://images.unsplash.com/photo-1522071820081-009f0129c71c?auto=format&fit=crop&w=800&q=80',
    },
    {
      stepNum: '02',
      tag: 'Pulse check',
      title: 'What does the weight feel like right now?',
      subtitle: 'Pick the word that sits closest to your chest. If you are at a breaking point, we will get you immediate help first.',
      type: 'single',
      options: ['Exhausted', 'Detached / Cynical', 'Overwhelmed', 'Anxious', 'Breaking point'],
      field: 'feeling',
      image: 'https://images.unsplash.com/photo-1517841905240-472988babdf9?auto=format&fit=crop&w=800&q=80',
    },
    {
      stepNum: '03',
      tag: 'Your world',
      title: 'Where does this happen?',
      subtitle: 'Tell us a bit about your environment. Knowing your day to day rhythm helps us ground your options in reality.',
      type: 'single',
      options: ['Corporate', 'Creative / Startup', 'Healthcare / Education', 'Recent Grad'],
      field: 'context',
      image: 'https://images.unsplash.com/photo-1507679799987-c73779587ccf?auto=format&fit=crop&w=800&q=80',
    },
    {
      stepNum: '04',
      tag: 'Support Goals',
      title: 'What kind of space do you need right now?',
      subtitle: 'There is no single right way to heal or reach out. Choose whatever feels least heavy to step into today.',
      type: 'single',
      options: ['Peer Connection', 'Professional Guidance', 'Self-Guided Tools', 'A mix of everything'],
      field: 'spaceType',
      image: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=800&q=80',
    },
    {
      stepNum: '05',
      tag: 'Finding Your Match',
      title: 'Support tailored to you',
      subtitle: 'Your budget, local options, mental health priorities, and progress. All in one place.',
      type: 'overview',
      points: [
        { label: 'Your budget', desc: 'Good support should not be a luxury. Pick the level that works for you right now.' },
        { label: 'Your location', desc: 'Resources and groups vary by state. We will only show what is available near you.' },
        { label: 'Specific concerns', desc: 'Select anything that resonates. This helps us move beyond generic labels to real understanding.' },
        { label: 'Almost there', desc: 'You have done the hard part. The next screen will show a few handpicked, verified matches.' },
      ],
    },
    {
      stepNum: '06',
      tag: 'Coverage',
      title: 'Let\'s navigate the financial side.',
      subtitle: 'Finding help shouldn\'t add to your stress. Tell us what you have or what you need, and we\'ll work within your means.',
      type: 'single',
      options: ['Private Insurance', 'Public / Medicaid', 'Out-of-Pocket', 'Sliding Scale Options'],
      field: 'coverage',
      image: 'https://images.unsplash.com/photo-1450133064473-71024230f91b?auto=format&fit=crop&w=800&q=80',
    },
    {
      stepNum: '07',
      tag: 'Location Preference',
      title: 'Where would you feel most safe meeting?',
      subtitle: 'Whether you need a physical room nearby or a quiet space behind your own screen, we will meet you where you are.',
      type: 'single',
      options: ['In-Person', 'Telehealth / Virtual', 'Hybrid'],
      field: 'locationPref',
      image: 'https://images.unsplash.com/photo-1582213782179-e0d53f98f2ca?auto=format&fit=crop&w=800&q=80',
    },
    {
      stepNum: '08',
      tag: 'Other Areas of Concern',
      title: 'What is taking up the most room in your mind?',
      subtitle: 'Select any specific experiences or concerns you want us to keep front and center as we gather your resources.',
      type: 'multi',
      options: [
        'Burnout Recovery & Stress Management',
        'Work Life Balance',
        'Identity & Inclusivity',
        'Crisis Navigation & Support',
      ],
      field: 'concerns',
      image: 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?auto=format&fit=crop&w=800&q=80',
    },
    {
      stepNum: '09',
      tag: 'Support Goals',
      title: 'Where should we look for care?',
      subtitle: 'Share your location so we can find options near you, along with an email where we can safely send your matched resources so you don\'t lose your place.',
      type: 'location_email',
      image: 'https://images.unsplash.com/photo-1529156069898-49953e39b3ac?auto=format&fit=crop&w=800&q=80',
    },
  ];

  const currentStepData = stepsData[currentStep - 1];

  const handleSingleSelect = (val: string) => {
    setAnswers(prev => ({ ...prev, [currentStepData.field as keyof typeof answers]: val }));
  };

  const handleMultiToggle = (val: string) => {
    setAnswers(prev => {
      const current = prev.concerns;
      const exists = current.includes(val);
      const nextArr = exists ? current.filter(x => x !== val) : [...current, val];
      return { ...prev, concerns: nextArr };
    });
  };

  const filteredMatches = PEER_GROUPS.filter(g => {
    if (activeCategoryFilter === 'all') return true;
    if (activeCategoryFilter === 'peer') return g.category === 'burnout' || g.category === 'tech';
    if (activeCategoryFilter === 'tools') return g.category === 'creative';
    if (activeCategoryFilter === 'professional') return g.category === 'caregiver';
    return true;
  });

  return (
    <div className="bg-[#b991b5] text-[#1f1621] min-h-screen py-10 px-4 sm:px-6 lg:px-10">
      <div className="max-w-4xl mx-auto space-y-8">
        
        {/* Quiz Flow Header */}
        <div className="bg-[#1f1621] text-white rounded-[28px] p-6 sm:p-8 flex items-center justify-between shadow-xl">
          <div className="space-y-1">
            <span className="text-xs uppercase tracking-widest text-purple-300 font-semibold bg-white/10 px-3 py-0.5 rounded-full">
              Confidential
            </span>
            <h1 className="text-2xl sm:text-3xl font-serif font-normal text-white">
              Find your footing
            </h1>
            <p className="text-xs sm:text-sm text-zinc-300 font-light">
              We will narrow thousands of options to a few that fit, for you or someone you care about.
            </p>
          </div>

          <button
            onClick={onGoHome}
            className="px-5 py-2 rounded-full border border-white/40 text-white text-xs font-semibold hover:bg-white/10 transition-colors cursor-pointer shrink-0"
          >
            Exit
          </button>
        </div>

        {/* SECTION A: Step Questionnaire (Pages 2 in PDF) */}
        {!showResults ? (
          <div className="bg-[#f9f5f8] rounded-[32px] p-6 sm:p-10 shadow-lg border border-white/60 space-y-8 animate-in fade-in duration-300">
            
            {/* Step Progress Bar */}
            <div className="flex items-center justify-between text-xs text-[#855b85] font-semibold pb-2 border-b border-[#e3d7e2]">
              <div className="flex items-center gap-2">
                <span className="font-mono text-sm">{currentStepData.stepNum}</span>
                <span className="uppercase tracking-widest">{currentStepData.tag}</span>
              </div>
              <span>Step {currentStep} of 9</span>
            </div>

            {/* Step Body (2-Column Split matching Page 2 in PDF) */}
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
              
              {/* Left Column: Form & Inputs */}
              <div className={`${currentStepData.image ? 'lg:col-span-7' : 'lg:col-span-12'} space-y-6`}>
                <div className="space-y-3">
                  <h2 className="text-2xl sm:text-3xl font-serif font-normal text-[#2b222a]">
                    {currentStepData.title}
                  </h2>
                  <p className="text-sm text-[#5e4b5d] font-light leading-relaxed">
                    {currentStepData.subtitle}
                  </p>
                </div>

                {/* Step 05 Overview View */}
                {currentStepData.type === 'overview' && (
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    {currentStepData.points?.map((pt, idx) => (
                      <div key={idx} className="bg-white rounded-2xl p-5 border border-[#e8dce7] space-y-1.5 shadow-xs">
                        <h3 className="font-serif font-medium text-base text-[#2b222a]">{pt.label}</h3>
                        <p className="text-xs text-[#5e4b5d] leading-relaxed font-light">{pt.desc}</p>
                      </div>
                    ))}
                  </div>
                )}

                {/* Single Select Options */}
                {currentStepData.type === 'single' && (
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    {currentStepData.options?.map((opt) => {
                      const isSelected = answers[currentStepData.field as keyof typeof answers] === opt;
                      return (
                        <button
                          key={opt}
                          onClick={() => handleSingleSelect(opt)}
                          className={`p-4 rounded-2xl border text-left text-xs sm:text-sm font-medium transition-all cursor-pointer flex items-center justify-between ${
                            isSelected
                              ? 'bg-[#855b85] text-white border-[#855b85] shadow-sm'
                              : 'bg-white text-[#2b222a] border-[#e3d7e2] hover:bg-[#ebdbe8]/50'
                          }`}
                        >
                          <span>{opt}</span>
                          {isSelected && <CheckCircle2 className="w-4 h-4 text-white" />}
                        </button>
                      );
                    })}
                  </div>
                )}

                {/* Multi Select Options */}
                {currentStepData.type === 'multi' && (
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    {currentStepData.options?.map((opt) => {
                      const isSelected = answers.concerns.includes(opt);
                      return (
                        <button
                          key={opt}
                          onClick={() => handleMultiToggle(opt)}
                          className={`p-4 rounded-2xl border text-left text-xs sm:text-sm font-medium transition-all cursor-pointer flex items-center justify-between ${
                            isSelected
                              ? 'bg-[#855b85] text-white border-[#855b85] shadow-sm'
                              : 'bg-white text-[#2b222a] border-[#e3d7e2] hover:bg-[#ebdbe8]/50'
                          }`}
                        >
                          <span>{opt}</span>
                          {isSelected && <CheckCircle2 className="w-4 h-4 text-white" />}
                        </button>
                      );
                    })}
                  </div>
                )}

                {/* Location & Email Step 09 */}
                {currentStepData.type === 'location_email' && (
                  <div className="space-y-6">
                    <div className="space-y-2">
                      <label className="block text-xs font-semibold text-[#5e4b5d]">Zip code, city, or state</label>
                      <div className="flex gap-2">
                        <input
                          type="text"
                          value={answers.zipOrCity}
                          onChange={e => setAnswers(prev => ({ ...prev, zipOrCity: e.target.value }))}
                          placeholder="e.g. Sydney, 2000 or Austin, TX"
                          className="w-full px-4 py-2.5 rounded-xl bg-white border border-[#e3d7e2] text-sm focus:outline-none focus:ring-2 focus:ring-[#855b85]"
                        />
                        <button
                          type="button"
                          onClick={() => setAnswers(prev => ({ ...prev, zipOrCity: 'Current Location (Sydney)' }))}
                          className="px-4 py-2.5 rounded-xl bg-[#ebdbe8] text-[#855b85] font-medium text-xs whitespace-nowrap hover:bg-[#855b85] hover:text-white transition-colors cursor-pointer flex items-center gap-1.5"
                        >
                          <MapPin className="w-3.5 h-3.5" />
                          <span>Use Current location</span>
                        </button>
                      </div>
                    </div>

                    <div className="bg-white p-6 rounded-2xl border border-[#e8dce7] space-y-3">
                      <div className="flex items-center gap-2">
                        <Sparkles className="w-4 h-4 text-[#855b85]" />
                        <h3 className="font-serif font-medium text-base text-[#2b222a]">Your results are ready</h3>
                      </div>
                      <p className="text-xs text-[#5e4b5d] font-light">
                        100% anonymous and we won't send you emails (except this one). We never track your data or share anything with your employer.
                      </p>
                      <div className="flex gap-2">
                        <input
                          type="email"
                          value={answers.email}
                          onChange={e => setAnswers(prev => ({ ...prev, email: e.target.value }))}
                          placeholder="Enter your email"
                          className="w-full px-4 py-2.5 rounded-xl bg-[#f9f5f8] border border-[#e3d7e2] text-sm focus:outline-none focus:ring-2 focus:ring-[#855b85]"
                        />
                      </div>
                    </div>
                  </div>
                )}
              </div>

              {/* Right Column: Image Card (Page 2 in PDF) */}
              {currentStepData.image && (
                <div className="lg:col-span-5 rounded-3xl overflow-hidden shadow-lg border border-white/60 h-64 lg:h-80">
                  <img 
                    src={currentStepData.image} 
                    alt={currentStepData.title}
                    className="w-full h-full object-cover" 
                  />
                </div>
              )}

            </div>

            {/* Navigation Bar */}
            <div className="flex items-center justify-between pt-4 border-t border-[#e3d7e2]">
              {currentStep > 1 ? (
                <button
                  onClick={() => setCurrentStep(prev => prev - 1)}
                  className="px-6 py-2.5 rounded-full border border-[#2b222a] text-[#2b222a] text-xs font-semibold hover:bg-[#2b222a] hover:text-white transition-all cursor-pointer flex items-center gap-1.5"
                >
                  <ArrowLeft className="w-3.5 h-3.5" />
                  <span>Back</span>
                </button>
              ) : <div />}

              {currentStep < 9 ? (
                <button
                  onClick={() => setCurrentStep(prev => prev + 1)}
                  className="px-8 py-2.5 rounded-full bg-[#855b85] text-white text-xs font-semibold hover:bg-[#6e4b6d] transition-all cursor-pointer shadow-md flex items-center gap-1.5"
                >
                  <span>Next</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
              ) : (
                <button
                  onClick={() => setShowResults(true)}
                  className="px-8 py-3 rounded-full bg-[#2b222a] text-white font-semibold text-sm hover:bg-[#423341] transition-all cursor-pointer shadow-lg flex items-center gap-2"
                >
                  <span>See my matches</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
              )}
            </div>

          </div>
        ) : (
          
          /* SECTION B: Handpicked Results View (Page 10 in PDF) */
          <div className="space-y-8 animate-in fade-in duration-300">
            
            {/* Top Results Hero (Page 10 in PDF) */}
            <div className="relative overflow-hidden bg-[#1f1621] text-white rounded-[32px] p-8 sm:p-12 text-center space-y-4 shadow-2xl">
              <img 
                src="https://images.unsplash.com/photo-1529156069898-49953e39b3ac?auto=format&fit=crop&w=1200&q=80" 
                alt="Friends on couch"
                className="absolute inset-0 w-full h-full object-cover opacity-25 pointer-events-none"
              />
              <div className="relative z-10 space-y-4">
                <span className="text-xs uppercase tracking-widest font-semibold text-purple-300 bg-white/10 px-3.5 py-1 rounded-full inline-block">
                  Matches
                </span>
                <h2 className="text-3xl sm:text-5xl font-serif font-normal text-white">
                  Good. You did the hard part.
                </h2>
                <p className="text-sm sm:text-base text-zinc-300 font-light max-w-xl mx-auto leading-relaxed">
                  Here are a few handpicked resources that feel like a good fit. This is just between us, always anonymous and never shared.
                </p>
              </div>
            </div>

            {/* Filter Tabs (Matching Page 10) */}
            <div className="bg-[#f9f5f8] p-3 rounded-2xl flex gap-2 overflow-x-auto shadow-xs border border-white/60">
              {[
                { id: 'all', label: 'All Matches' },
                { id: 'peer', label: 'Peer support circles' },
                { id: 'tools', label: 'Self-guided tools' },
                { id: 'professional', label: 'Affordable guidance' },
              ].map((tab) => (
                <button
                  key={tab.id}
                  onClick={() => setActiveCategoryFilter(tab.id)}
                  className={`px-4 py-2 rounded-xl text-xs font-medium whitespace-nowrap transition-all cursor-pointer ${
                    activeCategoryFilter === tab.id
                      ? 'bg-[#855b85] text-white shadow-xs font-semibold'
                      : 'text-[#5e4b5d] hover:bg-[#ebdbe8]'
                  }`}
                >
                  {tab.label}
                </button>
              ))}
            </div>

            {/* Matched Group Cards */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {filteredMatches.slice(0, 4).map((group) => (
                <div
                  key={group.id}
                  className="bg-white rounded-3xl p-6 sm:p-8 space-y-4 border border-[#e8dce7] shadow-sm hover:shadow-md transition-all flex flex-col justify-between"
                >
                  <div className="space-y-3">
                    <div className="flex items-center justify-between">
                      <span className="text-xs font-semibold px-3 py-1 rounded-full bg-[#f4ebf3] text-[#855b85]">
                        {group.format} • {group.location}
                      </span>
                      <span className="text-xs text-emerald-700 font-medium flex items-center gap-1">
                        <CheckCircle2 className="w-3.5 h-3.5" />
                        Verified Aug 2026
                      </span>
                    </div>

                    <h3 className="text-xl font-serif font-medium text-[#2b222a]">
                      {group.title}
                    </h3>
                    <p className="text-xs text-[#855b85] font-semibold">{group.subtitle}</p>
                    <p className="text-xs sm:text-sm text-[#5e4b5d] leading-relaxed font-light">
                      {group.description}
                    </p>

                    <div className="flex flex-wrap gap-1.5 pt-1">
                      {group.tags.map((t, idx) => (
                        <span key={idx} className="text-[11px] bg-zinc-100 text-zinc-600 px-2.5 py-0.5 rounded-full">
                          #{t}
                        </span>
                      ))}
                    </div>
                  </div>

                  <div className="pt-4 border-t border-[#e3d7e2] flex items-center justify-between gap-3">
                    <button
                      onClick={() => onSelectGroup(group)}
                      className="px-6 py-2 rounded-full bg-[#855b85] text-white text-xs font-semibold hover:bg-[#6e4b6d] transition-all cursor-pointer"
                    >
                      View details
                    </button>

                    <div className="flex items-center gap-2">
                      <button 
                        onClick={() => alert(`Saved "${group.title}" to your offline bookmarks!`)}
                        className="p-2 rounded-full hover:bg-zinc-100 text-[#5e4b5d] transition-colors cursor-pointer"
                        title="Save result"
                      >
                        <Bookmark className="w-4 h-4" />
                      </button>
                      <button 
                        onClick={() => alert(`Direct link copied for "${group.title}"!`)}
                        className="p-2 rounded-full hover:bg-zinc-100 text-[#5e4b5d] transition-colors cursor-pointer"
                        title="Share result"
                      >
                        <Share2 className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>

            {/* Bottom Actions Banner */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-6 pt-4">
              <div className="bg-[#1f1621] text-white p-8 rounded-3xl space-y-3 shadow-lg">
                <h3 className="text-2xl font-serif font-normal">Talk to someone</h3>
                <p className="text-xs sm:text-sm text-zinc-300 font-light">
                  A real navigator can help you sort through these results, no pressure and no judgment.
                </p>
                <button
                  onClick={onTalkToSomeone}
                  className="px-6 py-2 rounded-full bg-white text-[#1f1621] text-xs font-semibold hover:bg-zinc-100 cursor-pointer"
                >
                  Connect
                </button>
              </div>

              <div className="bg-[#1f1621] text-white p-8 rounded-3xl space-y-3 shadow-lg">
                <h3 className="text-2xl font-serif font-normal">Not quite right</h3>
                <p className="text-xs sm:text-sm text-zinc-300 font-light">
                  Adjust your preferences or retake the quiz to find a better fit for where you are.
                </p>
                <button
                  onClick={() => {
                    setShowResults(false);
                    setCurrentStep(1);
                  }}
                  className="px-6 py-2 rounded-full border border-white text-white text-xs font-semibold hover:bg-white/10 cursor-pointer flex items-center gap-1.5"
                >
                  <RefreshCw className="w-3.5 h-3.5" />
                  <span>Retake</span>
                </button>
              </div>
            </div>

          </div>
        )}

      </div>
    </div>
  );
};
