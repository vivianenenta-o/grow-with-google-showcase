import React, { useState } from 'react';
import { X, Eye, Hand, Ear, Wind, Sparkles, CheckCircle2 } from 'lucide-react';

interface SensoryResetModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const SensoryResetModal: React.FC<SensoryResetModalProps> = ({ isOpen, onClose }) => {
  const [currentStep, setCurrentStep] = useState(5);
  const [inputs, setInputs] = useState<Record<number, string[]>>({
    5: ['', '', '', '', ''],
    4: ['', '', '', ''],
    3: ['', '', ''],
    2: ['', ''],
    1: [''],
  });

  if (!isOpen) return null;

  const stepsData: Record<number, { title: string; subtitle: string; icon: React.ReactNode; color: string }> = {
    5: {
      title: '5 Things You Can See',
      subtitle: 'Look around you right now. Notice 5 distinct shapes, colors, or textures in your room.',
      icon: <Eye className="w-6 h-6 text-[#855b85]" />,
      color: 'bg-[#ebdbe8]',
    },
    4: {
      title: '4 Things You Can Touch',
      subtitle: 'Notice physical sensations: your feet on the floor, the texture of your shirt, or cool desk surface.',
      icon: <Hand className="w-6 h-6 text-[#855b85]" />,
      color: 'bg-[#ebdbe8]',
    },
    3: {
      title: '3 Things You Can Hear',
      subtitle: 'Listen closely. Background hums, traffic outside, wind, or your own slow breathing.',
      icon: <Ear className="w-6 h-6 text-[#855b85]" />,
      color: 'bg-[#ebdbe8]',
    },
    2: {
      title: '2 Things You Can Smell',
      subtitle: 'Notice subtle scents around you: fresh coffee, crisp air, or clean laundry.',
      icon: <Wind className="w-6 h-6 text-[#855b85]" />,
      color: 'bg-[#ebdbe8]',
    },
    1: {
      title: '1 Thing You Can Taste',
      subtitle: 'Focus on a single taste in your mouth, or take a slow sip of water.',
      icon: <Sparkles className="w-6 h-6 text-[#855b85]" />,
      color: 'bg-[#ebdbe8]',
    },
  };

  const stepInfo = stepsData[currentStep];

  const handleInputChange = (idx: number, value: string) => {
    setInputs(prev => {
      const copy = { ...prev };
      const arr = [...copy[currentStep]];
      arr[idx] = value;
      copy[currentStep] = arr;
      return copy;
    });
  };

  const isCompleted = currentStep === 1;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="bg-[#f9f5f8] w-full max-w-2xl rounded-[32px] shadow-2xl overflow-hidden border border-white/60 flex flex-col max-h-[90vh]">
        
        {/* Header (Matching Pages 4 & 5) */}
        <div className="bg-[#1f1621] text-white px-8 py-6 flex items-center justify-between">
          <div className="space-y-1">
            <div className="flex items-center gap-2">
              <span className="text-xs font-semibold uppercase tracking-widest text-purple-300 bg-white/10 px-3 py-0.5 rounded-full">
                5 min read
              </span>
              <span className="text-xs text-zinc-400 font-mono">Grounding exercise</span>
            </div>
            <h2 className="text-2xl sm:text-3xl font-serif font-normal text-white">
              The 5-4-3-2-1 Sensory Reset
            </h2>
          </div>

          <button
            onClick={onClose}
            className="p-2 rounded-full hover:bg-white/20 text-white transition-colors cursor-pointer"
            aria-label="Close modal"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-6 sm:p-8 overflow-y-auto space-y-6">
          
          <p className="text-xs sm:text-sm text-[#5e4b5d] font-light leading-relaxed">
            A quick grounding technique to cut through brain fog and bring your focus back to the present moment.
          </p>

          {/* Progress dots */}
          <div className="flex items-center justify-center gap-3 py-2">
            {[5, 4, 3, 2, 1].map((s) => (
              <button
                key={s}
                onClick={() => setCurrentStep(s)}
                className={`w-10 h-10 rounded-full font-mono text-sm font-bold transition-all cursor-pointer flex items-center justify-center ${
                  currentStep === s
                    ? 'bg-[#855b85] text-white scale-110 shadow-md'
                    : inputs[s].some(x => x.trim().length > 0)
                    ? 'bg-[#ebdbe8] text-[#855b85] border border-[#855b85]/40'
                    : 'bg-white text-zinc-400 border border-zinc-200'
                }`}
              >
                {s}
              </button>
            ))}
          </div>

          {/* Current Step Card */}
          <div className="bg-white rounded-2xl p-6 border border-[#e8dce7] space-y-4">
            <div className="flex items-center gap-3">
              <div className="p-2.5 rounded-xl bg-[#ebdbe8]">
                {stepInfo.icon}
              </div>
              <div>
                <h3 className="text-xl font-serif font-medium text-[#2b222a]">
                  {stepInfo.title}
                </h3>
                <p className="text-xs text-[#5e4b5d] font-light">
                  {stepInfo.subtitle}
                </p>
              </div>
            </div>

            {/* Input fields */}
            <div className="space-y-2 pt-2">
              {inputs[currentStep].map((val, idx) => (
                <div key={idx} className="flex items-center gap-2">
                  <span className="text-xs font-mono font-bold text-[#855b85] w-4">{idx + 1}.</span>
                  <input
                    type="text"
                    value={val}
                    onChange={(e) => handleInputChange(idx, e.target.value)}
                    placeholder={`Name item #${idx + 1}...`}
                    className="w-full px-4 py-2 rounded-xl bg-[#f9f5f8] border border-[#e3d7e2] text-xs sm:text-sm focus:outline-none focus:ring-2 focus:ring-[#855b85]"
                  />
                </div>
              ))}
            </div>
          </div>

          {/* Navigation Controls */}
          <div className="flex items-center justify-between pt-2">
            {currentStep < 5 ? (
              <button
                onClick={() => setCurrentStep(prev => prev + 1)}
                className="px-6 py-2.5 rounded-full border border-[#2b222a] text-[#2b222a] text-xs font-medium hover:bg-[#2b222a] hover:text-white transition-all cursor-pointer"
              >
                Previous Step
              </button>
            ) : <div />}

            {currentStep > 1 ? (
              <button
                onClick={() => setCurrentStep(prev => prev - 1)}
                className="px-8 py-2.5 rounded-full bg-[#855b85] text-white text-xs font-semibold hover:bg-[#6e4b6d] transition-all cursor-pointer shadow-md"
              >
                Next Step
              </button>
            ) : (
              <button
                onClick={onClose}
                className="px-8 py-2.5 rounded-full bg-emerald-700 text-white text-xs font-semibold hover:bg-emerald-800 transition-all cursor-pointer shadow-md flex items-center gap-1.5"
              >
                <CheckCircle2 className="w-4 h-4" />
                <span>Complete Grounding</span>
              </button>
            )}
          </div>

        </div>

      </div>
    </div>
  );
};
