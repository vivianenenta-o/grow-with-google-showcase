import React from 'react';
import { Search, SlidersHorizontal, CheckCircle2 } from 'lucide-react';

interface BrowseSectionProps {
  searchTerm: string;
  onSearchChange: (value: string) => void;
  selectedCategory: string;
  onCategorySelect: (category: string) => void;
  onSearchSubmit: (e: React.FormEvent) => void;
}

export const BrowseSection: React.FC<BrowseSectionProps> = ({
  searchTerm,
  onSearchChange,
  selectedCategory,
  onCategorySelect,
  onSearchSubmit,
}) => {
  const categories = [
    { id: 'all', label: 'All Listings' },
    { id: 'tech', label: 'Tech & Workplace' },
    { id: 'caregiver', label: 'Caregivers & Healthcare' },
    { id: 'creative', label: 'Creative & Solo' },
    { id: 'neurodivergent', label: 'Neurodivergent Spaces' },
    { id: 'burnout', label: 'General Burnout' },
  ];

  return (
    <section id="browse-section" className="bg-[#b991b5] py-16 sm:py-20 md:py-24 px-4 sm:px-6 lg:px-10 text-white text-center transition-colors">
      <div className="max-w-4xl mx-auto">
        
        {/* Small Eyebrow Label */}
        <span className="text-xs sm:text-sm font-semibold tracking-widest uppercase text-white/80 block mb-3">
          Browse
        </span>

        {/* Large Display Title */}
        <h2 className="text-4xl sm:text-6xl md:text-7xl font-normal tracking-tight text-white mb-5">
          Find your people
        </h2>

        {/* Subtitle */}
        <p className="text-base sm:text-lg md:text-xl font-light text-white/95 max-w-2xl mx-auto leading-relaxed mb-10">
          A space to browse verified peer groups, digital tools, and professional resources. Every listing is actively verified and dated.
        </p>

        {/* Search Bar Form */}
        <form 
          onSubmit={onSearchSubmit}
          className="flex flex-col sm:flex-row items-center justify-center gap-3 max-w-2xl mx-auto mb-10"
        >
          <div className="relative w-full sm:flex-1">
            <div className="absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none text-white/80">
              <Search className="w-5 h-5" />
            </div>
            <input
              type="text"
              value={searchTerm}
              onChange={(e) => onSearchChange(e.target.value)}
              placeholder="Enter search"
              className="w-full pl-11 pr-4 py-3.5 rounded-full bg-white/20 hover:bg-white/25 focus:bg-white/30 text-white placeholder-white/70 border border-white/30 focus:border-white focus:outline-none transition text-base backdrop-blur-xs"
            />
          </div>

          <button
            type="submit"
            className="w-full sm:w-auto px-8 py-3.5 rounded-full bg-white text-[#201521] font-semibold text-base shadow-md hover:bg-zinc-100 transition cursor-pointer shrink-0"
          >
            Search
          </button>
        </form>

        {/* Category Pills */}
        <div className="flex flex-wrap items-center justify-center gap-2.5 max-w-3xl mx-auto">
          {categories.map((cat) => {
            const isActive = selectedCategory === cat.id;
            return (
              <button
                key={cat.id}
                onClick={() => onCategorySelect(cat.id)}
                className={`px-4 py-2 rounded-full text-sm font-medium transition-all cursor-pointer ${
                  isActive
                    ? 'bg-white text-[#855b85] shadow-md font-semibold'
                    : 'bg-white/15 text-white hover:bg-white/25 border border-white/20'
                }`}
              >
                {cat.label}
              </button>
            );
          })}
        </div>

        {/* Verification guarantee pill */}
        <div className="mt-8 inline-flex items-center gap-2 text-xs text-white/90 bg-white/10 px-4 py-1.5 rounded-full border border-white/15 backdrop-blur-xs">
          <CheckCircle2 className="w-3.5 h-3.5 text-emerald-300" />
          <span>All 48 peer groups verified for safe community guidelines & active facilitators (Updated Aug 2026)</span>
        </div>

      </div>
    </section>
  );
};
