import React from 'react';
import { X, ShieldCheck, HeartHandshake, Users, Sparkles, Lock, CheckCircle2 } from 'lucide-react';

interface HowItWorksModalProps {
  isOpen: boolean;
  onClose: () => void;
  onOpenQuiz: () => void;
}

export const HowItWorksModal: React.FC<HowItWorksModalProps> = ({
  isOpen,
  onClose,
  onOpenQuiz,
}) => {
  if (!isOpen) return null;

  const steps = [
    {
      number: "01",
      title: "Honest Reflection & Matching Quiz",
      description: "Answer a 3-minute confidential questionnaire about what you're carrying right now—whether it's tech burnout, caregiver strain, or creative exhaustion.",
      icon: Sparkles,
    },
    {
      number: "02",
      title: "Active Facilitator & Group Verification",
      description: "Every group listed on Escale undergoes monthly verification. Facilitators complete peer safety training, ensuring small circles (6–12 people) remain grounded and empathetic.",
      icon: ShieldCheck,
    },
    {
      number: "03",
      title: "Join Low-Pressure Virtual or Local Circles",
      description: "Participate at your own pace. There is never pressure to perform or overshare. Listen, share when ready, or simply connect with people who truly get it.",
      icon: Users,
    },
  ];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="bg-white w-full max-w-2xl rounded-[32px] shadow-2xl overflow-hidden border border-purple-100 flex flex-col max-h-[90vh]">
        
        {/* Header */}
        <div className="bg-[#855b85] text-white px-6 py-5 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <HeartHandshake className="w-5 h-5 text-purple-200" />
            <span className="font-semibold text-base tracking-wide">How Escale Works</span>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 rounded-full hover:bg-white/20 text-white transition-colors cursor-pointer"
            aria-label="Close modal"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 sm:p-8 overflow-y-auto space-y-8">
          
          <div className="text-center max-w-md mx-auto">
            <h3 className="text-2xl sm:text-3xl font-normal text-zinc-900 mb-2">
              Human connection without corporate fluff
            </h3>
            <p className="text-xs text-zinc-500 font-light leading-relaxed">
              Escale was designed as an antidote to clinical isolation and performative social networks.
            </p>
          </div>

          {/* Steps */}
          <div className="space-y-6">
            {steps.map((step, idx) => {
              const Icon = step.icon;
              return (
                <div key={idx} className="flex items-start gap-4 p-5 rounded-2xl bg-purple-50/50 border border-purple-100/80">
                  <div className="w-10 h-10 rounded-2xl bg-[#855b85] text-white flex items-center justify-center shrink-0 font-bold text-sm shadow-xs">
                    {step.number}
                  </div>
                  <div>
                    <h4 className="font-semibold text-zinc-900 text-base mb-1 flex items-center gap-2">
                      {step.title}
                    </h4>
                    <p className="text-xs text-zinc-600 font-light leading-relaxed">
                      {step.description}
                    </p>
                  </div>
                </div>
              );
            })}
          </div>

          {/* Guarantees */}
          <div className="p-4 bg-zinc-50 rounded-2xl border border-zinc-200 space-y-2 text-xs text-zinc-600">
            <div className="font-semibold text-zinc-900 flex items-center gap-1.5">
              <Lock className="w-4 h-4 text-[#855b85]" /> Privacy & Confidentiality Guarantee
            </div>
            <p className="font-light leading-relaxed">
              We never sell data, serve advertisements, or require personal social profiles. You are free to use an alias in all peer circles.
            </p>
          </div>

          <div className="flex flex-col sm:flex-row items-center justify-between gap-3 pt-4 border-t border-zinc-100">
            <button
              onClick={() => {
                onClose();
                onOpenQuiz();
              }}
              className="w-full sm:w-auto px-7 py-3 rounded-full bg-[#855b85] text-white font-semibold text-xs hover:bg-[#734a73] transition cursor-pointer shadow-md"
            >
              Take Matching Quiz Now
            </button>

            <button
              onClick={onClose}
              className="w-full sm:w-auto px-6 py-3 rounded-full bg-zinc-100 hover:bg-zinc-200 text-zinc-700 text-xs font-semibold cursor-pointer"
            >
              Close
            </button>
          </div>

        </div>

      </div>
    </div>
  );
};
