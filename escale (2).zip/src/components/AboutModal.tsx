import React from 'react';
import { X, Heart, ShieldCheck, Users, Sparkles } from 'lucide-react';

interface AboutModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const AboutModal: React.FC<AboutModalProps> = ({ isOpen, onClose }) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="bg-white w-full max-w-2xl rounded-[32px] shadow-2xl overflow-hidden border border-purple-100 flex flex-col max-h-[90vh]">
        
        {/* Header */}
        <div className="bg-[#855b85] text-white px-6 py-5 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <span className="font-logo text-3xl text-white">escale</span>
            <span className="text-xs text-purple-200 font-medium pl-2 border-l border-white/20">About Us</span>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 rounded-full hover:bg-white/20 text-white transition-colors cursor-pointer"
            aria-label="Close modal"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 sm:p-8 overflow-y-auto space-y-6">
          
          <div>
            <span className="text-xs font-bold uppercase tracking-wider text-[#855b85] block mb-1">
              Our Ethos
            </span>
            <h3 className="text-2xl sm:text-3xl font-normal text-zinc-900 mb-3">
              Reclaiming quiet spaces for human healing
            </h3>
            <p className="text-sm text-zinc-600 font-light leading-relaxed mb-4">
              "Escale" is named after the French word for a breather, a port of call, or a gentle pause during a long journey. We built Escale because modern productivity culture often treats burnout as a personal flaw rather than a systemic phenomenon.
            </p>
            <p className="text-sm text-zinc-600 font-light leading-relaxed">
              We believe that genuine recovery happens not in isolation, but in warm, verified peer spaces where experiences can be held without judgment or clinical pressure.
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="p-4 bg-purple-50/60 rounded-2xl border border-purple-100">
              <ShieldCheck className="w-6 h-6 text-[#855b85] mb-2" />
              <h4 className="font-semibold text-zinc-900 text-sm mb-1">100% Verified Listings</h4>
              <p className="text-xs text-zinc-500 font-light">
                Every peer circle, facilitator, and resource is vetted monthly for safety and warmth.
              </p>
            </div>

            <div className="p-4 bg-purple-50/60 rounded-2xl border border-purple-100">
              <Users className="w-6 h-6 text-[#855b85] mb-2" />
              <h4 className="font-semibold text-zinc-900 text-sm mb-1">Peer-to-Peer Safety</h4>
              <p className="text-xs text-zinc-500 font-light">
                Small group sizes (6–12) foster intimate, meaningful relationships without performative noise.
              </p>
            </div>
          </div>

          <div className="pt-4 border-t border-zinc-100 flex justify-end">
            <button
              onClick={onClose}
              className="px-6 py-2.5 rounded-full bg-zinc-900 text-white text-xs font-semibold hover:bg-zinc-800 cursor-pointer"
            >
              Close
            </button>
          </div>

        </div>

      </div>
    </div>
  );
};
