import React from 'react';
import { CRISIS_RESOURCES } from '../data/mockData';
import { X, Phone, MessageSquare, Globe, ShieldAlert, Heart, ExternalLink } from 'lucide-react';

interface CrisisModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const CrisisModal: React.FC<CrisisModalProps> = ({ isOpen, onClose }) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="bg-white w-full max-w-2xl rounded-[32px] shadow-2xl overflow-hidden border border-pink-200 flex flex-col max-h-[90vh]">
        
        {/* Header */}
        <div className="bg-rose-900 text-white px-6 py-5 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <ShieldAlert className="w-5 h-5 text-rose-300" />
            <span className="font-semibold text-base tracking-wide">Immediate Crisis & Distress Support</span>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 rounded-full hover:bg-white/20 text-white transition-colors cursor-pointer"
            aria-label="Close modal"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 sm:p-8 overflow-y-auto space-y-6">
          
          <div className="bg-rose-50 border border-rose-200 p-4 rounded-2xl flex items-start gap-3 text-xs text-rose-900">
            <Heart className="w-5 h-5 text-rose-600 shrink-0 mt-0.5" />
            <p className="leading-relaxed">
              If you or someone you know is in immediate danger or experiencing severe emotional distress, please reach out to one of these free, 24/7 confidential services right now. You are not alone.
            </p>
          </div>

          <div className="space-y-3">
            {CRISIS_RESOURCES.map((resource) => (
              <div
                key={resource.id}
                className="p-4 sm:p-5 rounded-2xl border border-zinc-200 bg-white hover:border-rose-300 transition flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4"
              >
                <div>
                  <div className="flex items-center gap-2 mb-1">
                    <span className="text-[10px] font-bold uppercase bg-rose-100 text-rose-800 px-2 py-0.5 rounded-full">
                      {resource.type}
                    </span>
                    <span className="text-xs text-zinc-500">{resource.country}</span>
                  </div>

                  <h4 className="font-semibold text-zinc-900 text-base">{resource.name}</h4>
                  <p className="text-xs text-zinc-600 font-light mb-2">{resource.description}</p>
                  <span className="text-[11px] text-emerald-700 font-medium">{resource.availableHours}</span>
                </div>

                <a
                  href={resource.type === 'Call' ? `tel:${resource.contact}` : '#'}
                  target="_blank"
                  rel="noreferrer"
                  className="w-full sm:w-auto px-5 py-2.5 rounded-full bg-rose-800 hover:bg-rose-900 text-white font-bold text-sm text-center transition flex items-center justify-center gap-2 shrink-0 cursor-pointer"
                >
                  {resource.type === 'Call' && <Phone className="w-4 h-4" />}
                  {resource.type === 'Text' && <MessageSquare className="w-4 h-4" />}
                  {resource.type === 'Online Chat' && <Globe className="w-4 h-4" />}
                  <span>{resource.contact}</span>
                </a>
              </div>
            ))}
          </div>

          <div className="text-center pt-4 border-t border-zinc-100">
            <button
              onClick={onClose}
              className="px-6 py-2.5 rounded-full bg-zinc-100 hover:bg-zinc-200 text-zinc-700 text-xs font-semibold cursor-pointer"
            >
              Return to Escale
            </button>
          </div>

        </div>

      </div>
    </div>
  );
};
