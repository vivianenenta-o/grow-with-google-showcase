import React from 'react';
import { heroImage } from '../data/mockData';

interface HeroSectionProps {
  onTakeQuiz: () => void;
  onTalkToSomeone: () => void;
}

export const HeroSection: React.FC<HeroSectionProps> = ({
  onTakeQuiz,
  onTalkToSomeone,
}) => {
  return (
    <section className="bg-[#b991b5] py-8 sm:py-12 md:py-16 px-4 sm:px-6 lg:px-10 transition-colors duration-300">
      <div className="max-w-7xl mx-auto">
        
        {/* Main Banner Container Card with Large Rounded Corners */}
        <div className="relative rounded-[32px] sm:rounded-[40px] md:rounded-[48px] overflow-hidden min-h-[480px] sm:min-h-[540px] md:min-h-[600px] flex items-center justify-center text-center shadow-xl">
          
          {/* Background Image */}
          <img
            src={heroImage}
            alt="Three close friends embracing outdoors with warm fairy lights"
            className="absolute inset-0 w-full h-full object-cover object-center"
            referrerPolicy="no-referrer"
          />

          {/* Dark Overlay Gradient for Optimal Legibility */}
          <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-black/50 to-black/40" />

          {/* Centered Content */}
          <div className="relative z-10 px-6 sm:px-10 py-12 sm:py-16 max-w-4xl mx-auto text-white flex flex-col items-center">
            
            {/* Main Headline */}
            <h1 className="text-3xl sm:text-5xl md:text-6xl font-normal tracking-tight leading-[1.15] mb-6 text-white text-balance max-w-3xl">
              Find your way back from the burnout
            </h1>

            {/* Subtitle */}
            <p className="text-base sm:text-lg md:text-xl font-light text-zinc-100/95 max-w-2xl leading-relaxed mb-8 sm:mb-10 text-balance">
              The light at the end of the tunnel is here. The path forward starts with a few honest answers. We will match you with real peer groups and verified resources that actually fit your life.
            </p>

            {/* Call To Action Buttons */}
            <div className="flex flex-col sm:flex-row items-center justify-center gap-4 w-full sm:w-auto">
              <button
                onClick={onTakeQuiz}
                className="w-full sm:w-auto px-8 py-3.5 rounded-full bg-white text-[#1f1621] font-semibold text-base shadow-lg hover:bg-zinc-100 transform hover:scale-[1.02] active:scale-[0.98] transition-all cursor-pointer"
              >
                Take the quiz
              </button>

              <button
                onClick={onTalkToSomeone}
                className="w-full sm:w-auto px-8 py-3.5 rounded-full border border-white/60 text-white font-medium text-base hover:bg-white/15 backdrop-blur-xs transition-all cursor-pointer"
              >
                Talk to someone
              </button>
            </div>

          </div>
        </div>

      </div>
    </section>
  );
};
