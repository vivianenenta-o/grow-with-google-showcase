import React, { useState } from 'react';
import { ChevronLeft, ChevronRight, CheckCircle2, ArrowRight } from 'lucide-react';
import { PeerGroup } from '../types';

interface ResourceItem {
  id: string;
  title: string;
  subtitle: string;
  type: string;
  priceTag: 'Free' | 'Low-cost' | 'Sliding Scale';
  verifiedDate: string;
  image: string;
  description: string;
  groupMatch?: PeerGroup;
}

interface ResourcesSectionProps {
  onSelectGroup: (group: PeerGroup) => void;
  onViewAll: () => void;
  groups: PeerGroup[];
}

export const ResourcesSection: React.FC<ResourcesSectionProps> = ({
  onSelectGroup,
  onViewAll,
  groups,
}) => {
  const [currentIndex, setCurrentIndex] = useState(0);

  const curatedResources: ResourceItem[] = [
    {
      id: 'r1',
      title: 'The weary creatives',
      subtitle: 'Peer group for designers & artists',
      type: 'Peer group',
      priceTag: 'Free',
      verifiedDate: 'Checked Aug 2026',
      image: '/src/assets/images/weary_creatives_artistic_1786492162398.jpg',
      description: 'Weekly creative burnout circle exploring boundaries, client stress, and artistic renewal.',
      groupMatch: groups.find(g => g.id === 'creative-block-recovery') || groups[0],
    },
    {
      id: 'r2',
      title: 'Headspace for startups',
      subtitle: 'Digital tool & founder toolkit',
      type: 'Digital tool',
      priceTag: 'Low-cost',
      verifiedDate: 'Checked Aug 2026',
      image: '/src/assets/images/startup_team_table_1786492201559.jpg',
      description: 'Guided micro-breaks, async check-ins, and workload boundaries designed for early startups.',
      groupMatch: groups[0],
    },
    {
      id: 'r3',
      title: 'Nurses off the clock',
      subtitle: 'Peer group for medical shift fatigue',
      type: 'Peer group',
      priceTag: 'Free',
      verifiedDate: 'Checked Aug 2026',
      image: '/src/assets/images/nurse_coffee_scrubs_1786492240785.jpg',
      description: 'Decompress after intense hospital shifts with fellow medical workers who get it.',
      groupMatch: groups.find(g => g.id === 'healthcare-frontline-circle') || groups[0],
    },
    {
      id: 'r4',
      title: 'The remote deep end',
      subtitle: 'Virtual support for isolation & burnout',
      type: 'Peer group',
      priceTag: 'Free',
      verifiedDate: 'Checked Aug 2026',
      image: '/src/assets/images/explore_cozy_group_1786277310778.jpg',
      description: 'Confidential peer-led group discussing screen strain, remote isolation, and career burnout.',
      groupMatch: groups.find(g => g.id === 'tech-burnout-weekly') || groups[0],
    },
    {
      id: 'r5',
      title: 'Sliding scale therapy',
      subtitle: 'Affordable professional guidance',
      type: 'Professional',
      priceTag: 'Low-cost',
      verifiedDate: 'Checked Aug 2026',
      image: '/src/assets/images/quiz_two_people_talk_1786491437069.jpg',
      description: 'Hand-vetted clinicians offering sliding scale care for early career workers.',
      groupMatch: groups[0],
    },
    {
      id: 'r6',
      title: 'Imposter syndrome workshop',
      subtitle: 'Self-guided toolkit & reflection prompts',
      type: 'Self-guided',
      priceTag: 'Low-cost',
      verifiedDate: 'Checked Aug 2026',
      image: '/src/assets/images/exact_verify_man_laptop_1786494760483.jpg',
      description: 'Practical exercises to unhook self-worth from work metrics and overcome imposter feelings.',
      groupMatch: groups[0],
    },
  ];

  const handlePrev = () => {
    setCurrentIndex((prev) => (prev === 0 ? curatedResources.length - 1 : prev - 1));
  };

  const handleNext = () => {
    setCurrentIndex((prev) => (prev === curatedResources.length - 1 ? 0 : prev + 1));
  };

  return (
    <section className="bg-[#f9f5f8] py-12 sm:py-16 md:py-20 px-4 sm:px-6 lg:px-10 text-[#2b222a]">
      <div className="max-w-7xl mx-auto space-y-8">
        
        {/* Header Row */}
        <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4">
          <div className="space-y-2">
            <span className="inline-block text-xs uppercase tracking-widest font-semibold text-[#855b85] bg-[#ebdbe8] px-3 py-1 rounded-full">
              Resources
            </span>
            <h2 className="text-3xl sm:text-4xl md:text-5xl font-serif font-normal text-[#2b222a] tracking-tight">
              The good stuff
            </h2>
            <p className="text-base sm:text-lg text-[#5e4b5d] font-light">
              Every listing is checked and dated. No dead ends here.
            </p>
          </div>

          <button
            onClick={onViewAll}
            className="self-start sm:self-auto px-6 py-2.5 rounded-full border border-[#2b222a] text-[#2b222a] hover:bg-[#2b222a] hover:text-white transition-all text-sm font-medium cursor-pointer"
          >
            View all
          </button>
        </div>

        {/* Resource Cards Carousel */}
        <div className="relative">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {curatedResources.map((item, idx) => (
              <div
                key={item.id}
                className="bg-white rounded-3xl overflow-hidden border border-[#e8dce7] shadow-xs hover:shadow-md transition-all flex flex-col justify-between group"
              >
                <div>
                  {/* Card Image */}
                  <div className="relative h-48 overflow-hidden">
                    <img
                      src={item.image}
                      alt={item.title}
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                      referrerPolicy="no-referrer"
                    />
                    
                    {/* Top Badges */}
                    <div className="absolute top-3 left-3 right-3 flex items-center justify-between">
                      <span className="text-xs font-semibold px-3 py-1 rounded-full bg-white/90 backdrop-blur-xs text-[#2b222a]">
                        {item.type}
                      </span>
                      <span className="text-xs font-semibold px-3 py-1 rounded-full bg-[#1f1621] text-white">
                        {item.priceTag}
                      </span>
                    </div>
                  </div>

                  {/* Card Info */}
                  <div className="p-6 space-y-3">
                    <div className="flex items-center gap-1.5 text-xs text-[#855b85] font-medium">
                      <CheckCircle2 className="w-3.5 h-3.5" />
                      <span>{item.verifiedDate}</span>
                    </div>

                    <h3 className="text-xl font-serif font-medium text-[#2b222a] group-hover:text-[#855b85] transition-colors">
                      {item.title}
                    </h3>

                    <p className="text-xs text-[#735d72]">
                      {item.subtitle}
                    </p>

                    <p className="text-sm text-[#5e4b5d] line-clamp-2 leading-relaxed pt-1">
                      {item.description}
                    </p>
                  </div>
                </div>

                {/* Card Action */}
                <div className="px-6 pb-6 pt-2">
                  <button
                    onClick={() => item.groupMatch && onSelectGroup(item.groupMatch)}
                    className="w-full py-2.5 rounded-full border border-[#855b85] text-[#855b85] group-hover:bg-[#855b85] group-hover:text-white font-medium text-sm transition-all flex items-center justify-center gap-2 cursor-pointer"
                  >
                    <span>View details</span>
                    <ArrowRight className="w-4 h-4" />
                  </button>
                </div>

              </div>
            ))}
          </div>
        </div>

      </div>
    </section>
  );
};
