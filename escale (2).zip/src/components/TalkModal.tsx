import React, { useState } from 'react';
import { PEER_LISTENERS } from '../data/mockData';
import { PeerListener } from '../types';
import { X, MessageSquare, PhoneCall, Calendar, CheckCircle2, Star, ShieldCheck, Heart } from 'lucide-react';

interface TalkModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const TalkModal: React.FC<TalkModalProps> = ({ isOpen, onClose }) => {
  const [selectedListener, setSelectedListener] = useState<PeerListener>(PEER_LISTENERS[0]);
  const [mode, setMode] = useState<'chat' | 'call'>('chat');
  const [userNote, setUserNote] = useState('');
  const [isSubmitted, setIsSubmitted] = useState(false);

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitted(true);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="bg-white w-full max-w-2xl rounded-[32px] shadow-2xl overflow-hidden border border-purple-100 flex flex-col max-h-[90vh]">
        
        {/* Header */}
        <div className="bg-[#855b85] text-white px-6 py-5 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Heart className="w-5 h-5 text-pink-200 fill-pink-200" />
            <span className="font-semibold text-base tracking-wide">1-on-1 Peer Talk</span>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 rounded-full hover:bg-white/20 text-white transition-colors cursor-pointer"
            aria-label="Close modal"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 sm:p-8 overflow-y-auto">
          {!isSubmitted ? (
            <form onSubmit={handleSubmit} className="space-y-6">
              
              <div>
                <h3 className="text-2xl font-normal text-zinc-900 mb-1">
                  Connect with a Peer Listener
                </h3>
                <p className="text-xs text-zinc-500 font-light">
                  Free, confidential, and empathetic support from trained peer listeners with lived experience.
                </p>
              </div>

              {/* Select Listener */}
              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-zinc-500 mb-2">
                  Select a Peer Listener
                </label>

                <div className="space-y-3">
                  {PEER_LISTENERS.map((listener) => {
                    const isSelected = selectedListener.id === listener.id;
                    return (
                      <div
                        key={listener.id}
                        onClick={() => setSelectedListener(listener)}
                        className={`p-4 rounded-2xl border transition-all cursor-pointer flex items-center justify-between gap-4 ${
                          isSelected
                            ? 'border-[#855b85] bg-purple-50/70 shadow-xs'
                            : 'border-zinc-200 hover:border-purple-200 hover:bg-zinc-50'
                        }`}
                      >
                        <div className="flex items-center gap-3.5">
                          <img
                            src={listener.avatar}
                            alt={listener.name}
                            className="w-12 h-12 rounded-full object-cover border border-purple-200"
                            referrerPolicy="no-referrer"
                          />
                          <div>
                            <div className="flex items-center gap-2">
                              <h4 className="font-semibold text-zinc-900 text-sm">{listener.name}</h4>
                              <span className="text-[10px] bg-emerald-100 text-emerald-800 font-medium px-2 py-0.5 rounded-full">
                                {listener.availability}
                              </span>
                            </div>
                            <p className="text-xs text-[#855b85] font-medium">{listener.specialty}</p>
                            <p className="text-[11px] text-zinc-500 line-clamp-1">{listener.bio}</p>
                          </div>
                        </div>

                        <div className="text-right shrink-0">
                          <div className="flex items-center text-amber-500 text-xs font-bold justify-end">
                            <Star className="w-3.5 h-3.5 fill-amber-400 mr-1" />
                            {listener.rating}
                          </div>
                          <span className="text-[10px] text-zinc-400">({listener.reviewsCount} talks)</span>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* Mode Toggle */}
              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-zinc-500 mb-2">
                  Preferred Format
                </label>
                <div className="grid grid-cols-2 gap-3">
                  <button
                    type="button"
                    onClick={() => setMode('chat')}
                    className={`py-3 px-4 rounded-xl border flex items-center justify-center gap-2 text-xs font-semibold cursor-pointer transition ${
                      mode === 'chat'
                        ? 'border-[#855b85] bg-[#855b85] text-white shadow-xs'
                        : 'border-zinc-200 text-zinc-700 hover:bg-zinc-50'
                    }`}
                  >
                    <MessageSquare className="w-4 h-4" /> Confidential Text Chat
                  </button>

                  <button
                    type="button"
                    onClick={() => setMode('call')}
                    className={`py-3 px-4 rounded-xl border flex items-center justify-center gap-2 text-xs font-semibold cursor-pointer transition ${
                      mode === 'call'
                        ? 'border-[#855b85] bg-[#855b85] text-white shadow-xs'
                        : 'border-zinc-200 text-zinc-700 hover:bg-zinc-50'
                    }`}
                  >
                    <PhoneCall className="w-4 h-4" /> Anonymous Voice Call
                  </button>
                </div>
              </div>

              {/* Optional note */}
              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-zinc-500 mb-1">
                  What's on your mind today? (Optional)
                </label>
                <textarea
                  value={userNote}
                  onChange={(e) => setUserNote(e.target.value)}
                  placeholder="e.g. Feeling overwhelmed by work deadlines and looking for someone to listen..."
                  rows={3}
                  className="w-full p-3.5 rounded-xl border border-zinc-200 focus:border-[#855b85] focus:ring-1 focus:ring-[#855b85] text-xs text-zinc-800 placeholder-zinc-400 resize-none"
                />
              </div>

              {/* Submit CTA */}
              <button
                type="submit"
                className="w-full py-3.5 rounded-full bg-[#855b85] text-white font-semibold text-sm hover:bg-[#734a73] transition cursor-pointer shadow-md"
              >
                Request Talk Session with {selectedListener.name}
              </button>

              <div className="flex items-center justify-center gap-1.5 text-[11px] text-zinc-500">
                <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
                <span>100% Anonymous & Protected by Escale Community Guidelines</span>
              </div>

            </form>
          ) : (
            /* Success confirmation */
            <div className="text-center py-8 space-y-4">
              <div className="w-16 h-16 rounded-full bg-emerald-100 text-emerald-700 mx-auto flex items-center justify-center">
                <CheckCircle2 className="w-10 h-10" />
              </div>

              <h3 className="text-2xl font-medium text-zinc-900">
                Connection Request Sent!
              </h3>

              <p className="text-sm text-zinc-600 max-w-md mx-auto font-light leading-relaxed">
                <strong>{selectedListener.name}</strong> has received your request for a {mode === 'chat' ? 'text chat' : 'voice call'}. You will receive a secure notification link in under 3 minutes.
              </p>

              <div className="p-4 bg-purple-50 rounded-2xl max-w-md mx-auto text-xs text-[#855b85] font-medium border border-purple-100">
                Status: Listener is preparing secure room...
              </div>

              <button
                onClick={() => {
                  setIsSubmitted(false);
                  onClose();
                }}
                className="px-8 py-3 rounded-full bg-zinc-900 text-white text-xs font-semibold hover:bg-zinc-800 cursor-pointer"
              >
                Return to Escale Portal
              </button>
            </div>
          )}
        </div>

      </div>
    </div>
  );
};
