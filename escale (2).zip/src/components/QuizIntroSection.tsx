import React, { useState } from 'react';
import { ArrowRight, CheckCircle2, ShieldCheck, Sparkles, Users, Briefcase, Heart } from 'lucide-react';
import laptopPlantsImage from '../assets/images/exact_verify_man_laptop_1786494760483.jpg';

interface QuizIntroSectionProps {
  onStartQuiz: (persona?: 'myself' | 'someone' | 'work') => void;
  onOpenHowItWorks: () => void;
}

export const QuizIntroSection: React.FC<QuizIntroSectionProps> = ({
  onStartQuiz,
  onOpenHowItWorks,
}) => {
  const [selectedPersona, setSelectedPersona] = useState<'myself' | 'someone' | 'work'>('myself');

  const personaDetails = {
    myself: {
      tagline: 'Personalized Burnout & Career Route',
      description: 'Find real peer groups and low-cost tools tailored to your individual job stress, budget, and bandwidth.',
      questionsPreview: ['Current energy levels & screen fatigue', 'Role type (Tech, Corporate, Freelance, Caregiver)', 'Preferred support style (Virtual, In-person, 1-on-1)'],
      badge: 'Takes under 2 mins • 100% Anonymous',
    },
    someone: {
      tagline: 'Caregiver & Ally Navigator Mode',
      description: 'Looking out for a partner, friend, or teammate? Route them to gentle, non-judgmental resources without making it awkward.',
      questionsPreview: ['Relationship to person needing help', 'Primary stressor observed (Exhaustion, Isolation, Stress)', 'Resource preference (Peer group, Hotline, Digital tool)'],
      badge: 'Designed for allies & caregivers',
    },
    work: {
      tagline: 'Team & Work Environment Assessment',
      description: 'Map crunch pressure and boundary fatigue across tech squads, creative agencies, and frontline healthcare teams.',
      questionsPreview: ['Team size & work setting (Remote/Hybrid/Onsite)', 'Pace & overtime frequency', 'Focus area (Preventing exodus, quiet support)'],
      badge: 'For team leaders & workplace peers',
    },
  };

  const current = personaDetails[selectedPersona];

  return (
    <section className="bg-[#b991b5] py-12 sm:py-16 md:py-20 px-4 sm:px-6 lg:px-10 text-[#1f1621]">
      <div className="max-w-7xl mx-auto space-y-12">
        
        {/* Main Quiz Intro Frame: "A quiz that understands" */}
        <div className="bg-[#f9f5f8] rounded-[32px] sm:rounded-[40px] p-6 sm:p-10 md:p-12 shadow-md">
          
          {/* Eyebrow & Main Title */}
          <div className="max-w-3xl space-y-3 mb-8">
            <span className="inline-block text-xs uppercase tracking-widest font-semibold text-[#855b85] bg-[#ebdbe8] px-3 py-1 rounded-full">
              Match
            </span>
            <h2 className="text-3xl sm:text-4xl md:text-5xl font-serif font-normal text-[#2b222a] tracking-tight">
              A quiz that understands
            </h2>
            <p className="text-base sm:text-lg text-[#524152] leading-relaxed pt-2">
              We built escale to route you, not to treat you. Answer a few honest questions about your career, your budget, and how you actually feel. We will narrow thousands of options to a small, curated set of peer groups and verified tools that fit.
            </p>
          </div>

          {/* Persona Switcher Tabs: "For myself" | "For someone" | "For work" */}
          <div className="border-b border-[#e3d7e2] mb-8">
            <div className="flex gap-6 sm:gap-10 overflow-x-auto pb-px">
              <button
                onClick={() => setSelectedPersona('myself')}
                className={`flex items-center gap-2 pb-3 text-base sm:text-lg font-medium transition-all whitespace-nowrap border-b-2 cursor-pointer ${
                  selectedPersona === 'myself'
                    ? 'border-[#855b85] text-[#1f1621]'
                    : 'border-transparent text-[#7a6479] hover:text-[#2b222a]'
                }`}
              >
                <Heart className="w-4 h-4" />
                For myself
              </button>

              <button
                onClick={() => setSelectedPersona('someone')}
                className={`flex items-center gap-2 pb-3 text-base sm:text-lg font-medium transition-all whitespace-nowrap border-b-2 cursor-pointer ${
                  selectedPersona === 'someone'
                    ? 'border-[#855b85] text-[#1f1621]'
                    : 'border-transparent text-[#7a6479] hover:text-[#2b222a]'
                }`}
              >
                <Users className="w-4 h-4" />
                For someone
              </button>

              <button
                onClick={() => setSelectedPersona('work')}
                className={`flex items-center gap-2 pb-3 text-base sm:text-lg font-medium transition-all whitespace-nowrap border-b-2 cursor-pointer ${
                  selectedPersona === 'work'
                    ? 'border-[#855b85] text-[#1f1621]'
                    : 'border-transparent text-[#7a6479] hover:text-[#2b222a]'
                }`}
              >
                <Briefcase className="w-4 h-4" />
                For work
              </button>
            </div>
          </div>

          {/* Interactive Persona Card Preview & Action */}
          <div className="bg-white rounded-2xl p-6 sm:p-8 border border-[#e8dce7] flex flex-col md:flex-row items-start md:items-center justify-between gap-6 shadow-xs">
            <div className="space-y-3 max-w-2xl">
              <div className="inline-flex items-center gap-2 text-xs font-semibold text-[#855b85] bg-[#f4ebf3] px-3 py-1 rounded-full">
                <Sparkles className="w-3.5 h-3.5" />
                {current.badge}
              </div>
              <h3 className="text-xl sm:text-2xl font-serif font-medium text-[#2b222a]">
                {current.tagline}
              </h3>
              <p className="text-sm sm:text-base text-[#5e4b5d]">
                {current.description}
              </p>

              <div className="pt-2 grid grid-cols-1 sm:grid-cols-3 gap-2">
                {current.questionsPreview.map((item, idx) => (
                  <div key={idx} className="flex items-center gap-2 text-xs text-[#6e586c]">
                    <CheckCircle2 className="w-3.5 h-3.5 text-[#855b85] shrink-0" />
                    <span>{item}</span>
                  </div>
                ))}
              </div>
            </div>

            <div className="w-full md:w-auto shrink-0 pt-2 md:pt-0">
              <button
                onClick={() => onStartQuiz(selectedPersona)}
                className="w-full md:w-auto px-8 py-4 rounded-full bg-[#2b222a] text-white hover:bg-[#423341] font-medium text-base transition-all flex items-center justify-center gap-2 shadow-md cursor-pointer transform hover:scale-[1.02] active:scale-[0.98]"
              >
                <span>Start Quiz</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          </div>

        </div>

        {/* Verification Feature Banner Card (Image from Design PDF) */}
        <div className="bg-[#b382aa] text-white rounded-[32px] sm:rounded-[40px] overflow-hidden grid grid-cols-1 md:grid-cols-2 shadow-lg border border-white/15">
          
          {/* Left Side Photo: Man on chair with laptop & lush green indoor plants */}
          <div className="relative min-h-[300px] sm:min-h-[360px] md:min-h-full">
            <img
              src={laptopPlantsImage}
              alt="Man working on laptop comfortably on chair surrounded by green plants"
              className="absolute inset-0 w-full h-full object-cover"
              referrerPolicy="no-referrer"
            />
          </div>

          {/* Right Side Content */}
          <div className="p-8 sm:p-10 md:p-14 flex flex-col justify-center space-y-5 bg-[#b382aa]">
            <span className="text-sm font-medium text-white/90 tracking-wide">
              Verify
            </span>

            <h3 className="text-3xl sm:text-4xl md:text-5xl font-serif font-normal leading-[1.15] text-white">
              Every resource is checked and dated, never just aggregated
            </h3>

            <p className="text-sm sm:text-base text-white/90 leading-relaxed font-light">
              The internet is full of dead links and outdated advice. We actively verify every listing and display the last-checked date so you know it is real and available right now.
            </p>

            <div className="pt-2">
              <button
                onClick={onOpenHowItWorks}
                className="px-7 py-2.5 rounded-full border border-white/60 text-white font-normal text-sm sm:text-base hover:bg-white/10 transition-all cursor-pointer shadow-xs"
              >
                Learn More
              </button>
            </div>
          </div>

        </div>

      </div>
    </section>
  );
};
