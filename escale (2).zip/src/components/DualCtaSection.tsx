import React from 'react';
import { Box, ArrowRight } from 'lucide-react';

interface DualCtaSectionProps {
  onBrowse: () => void;
  onConnect: () => void;
}

export const DualCtaSection: React.FC<DualCtaSectionProps> = ({
  onBrowse,
  onConnect,
}) => {
  return (
    <section className="bg-[#b991b5] py-8 sm:py-12 px-4 sm:px-6 lg:px-10">
      <div className="max-w-7xl mx-auto grid grid-cols-1 md:grid-cols-2 gap-6">
        
        {/* Left Block: Browse the directory */}
        <div className="bg-[#1f1621] text-white rounded-[28px] sm:rounded-[32px] p-8 sm:p-10 flex flex-col justify-between space-y-6 shadow-xl border border-white/10">
          <div className="space-y-4">
            <div className="w-10 h-10 rounded-xl bg-white/10 flex items-center justify-center text-white">
              <Box className="w-5 h-5" />
            </div>

            <h3 className="text-2xl sm:text-3xl font-serif font-normal text-white">
              Browse the directory
            </h3>

            <p className="text-sm sm:text-base text-zinc-300 font-light leading-relaxed">
              Prefer to look around yourself? Explore peer groups, digital tools, and affordable care filtered by region and topic.
            </p>
          </div>

          <div>
            <button
              onClick={onBrowse}
              className="px-8 py-3 rounded-full border border-white text-white hover:bg-white hover:text-[#1f1621] font-medium text-sm transition-all flex items-center gap-2 cursor-pointer shadow-sm"
            >
              <span>Browse</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Right Block: Talk to someone */}
        <div className="bg-[#1f1621] text-white rounded-[28px] sm:rounded-[32px] p-8 sm:p-10 flex flex-col justify-between space-y-6 shadow-xl border border-white/10">
          <div className="space-y-4">
            <div className="w-10 h-10 rounded-xl bg-white/10 flex items-center justify-center text-white">
              <Box className="w-5 h-5" />
            </div>

            <h3 className="text-2xl sm:text-3xl font-serif font-normal text-white">
              Talk to someone
            </h3>

            <p className="text-sm sm:text-base text-zinc-300 font-light leading-relaxed">
              Sometimes you just need a real person. Connect with a live navigator who can help you find the right support, right now.
            </p>
          </div>

          <div>
            <button
              onClick={onConnect}
              className="px-8 py-3 rounded-full border border-white text-white hover:bg-white hover:text-[#1f1621] font-medium text-sm transition-all flex items-center gap-2 cursor-pointer shadow-sm"
            >
              <span>Connect</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        </div>

      </div>
    </section>
  );
};
