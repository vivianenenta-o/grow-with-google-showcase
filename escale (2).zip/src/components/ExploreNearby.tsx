import React, { useRef } from 'react';
import { CATEGORY_CARDS } from '../data/mockData';
import { CategoryCard } from '../types';
import { ChevronLeft, ChevronRight, Users, ArrowUpRight } from 'lucide-react';

interface ExploreNearbyProps {
  onSelectCategory: (categoryId: string) => void;
}

export const ExploreNearby: React.FC<ExploreNearbyProps> = ({ onSelectCategory }) => {
  const scrollRef = useRef<HTMLDivElement>(null);

  const scroll = (direction: 'left' | 'right') => {
    if (scrollRef.current) {
      const scrollAmount = direction === 'left' ? -380 : 380;
      scrollRef.current.scrollBy({ left: scrollAmount, behavior: 'smooth' });
    }
  };

  return (
    <section className="bg-[#f9f5f8] py-16 sm:py-20 md:py-24 px-4 sm:px-6 lg:px-10 border-t border-purple-100/50">
      <div className="max-w-7xl mx-auto">
        
        {/* Section Heading */}
        <div className="text-center max-w-2xl mx-auto mb-12">
          <h2 className="text-4xl sm:text-5xl md:text-6xl font-normal tracking-tight text-[#2b1f2b] mb-4">
            Explore nearby
          </h2>
          <p className="text-base sm:text-lg text-zinc-600 font-light leading-relaxed">
            Browse by what you are carrying or where you are standing
          </p>
        </div>

        {/* Carousel Controls */}
        <div className="flex justify-end mb-4 pr-2 space-x-2">
          <button
            onClick={() => scroll('left')}
            className="p-3 rounded-full bg-white border border-zinc-200 text-zinc-700 hover:bg-zinc-100 hover:text-zinc-900 transition shadow-xs cursor-pointer"
            aria-label="Scroll left"
          >
            <ChevronLeft className="w-5 h-5" />
          </button>
          <button
            onClick={() => scroll('right')}
            className="p-3 rounded-full bg-white border border-zinc-200 text-zinc-700 hover:bg-zinc-100 hover:text-zinc-900 transition shadow-xs cursor-pointer"
            aria-label="Scroll right"
          >
            <ChevronRight className="w-5 h-5" />
          </button>
        </div>

        {/* Horizontal Cards Scrollable Container */}
        <div 
          ref={scrollRef}
          className="flex gap-6 overflow-x-auto no-scrollbar pb-6 pt-2 snap-x snap-mandatory"
        >
          {CATEGORY_CARDS.map((card) => (
            <div
              key={card.id}
              onClick={() => onSelectCategory(card.id)}
              className="snap-start shrink-0 w-[300px] sm:w-[360px] bg-white rounded-[32px] overflow-hidden border border-purple-100/80 shadow-md hover:shadow-xl transition-all duration-300 transform hover:-translate-y-1.5 cursor-pointer flex flex-col group"
            >
              {/* Card Image */}
              <div className="relative h-52 sm:h-60 overflow-hidden bg-zinc-100">
                <img
                  src={card.image}
                  alt={card.title}
                  className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
                  referrerPolicy="no-referrer"
                />
                
                {/* Tag Overlay */}
                <div className="absolute top-4 left-4 bg-white/90 backdrop-blur-md text-[#613e61] text-xs font-semibold px-3.5 py-1.5 rounded-full shadow-xs">
                  {card.tag}
                </div>

                <div className="absolute top-4 right-4 w-9 h-9 rounded-full bg-white/90 backdrop-blur-md flex items-center justify-center text-zinc-800 opacity-0 group-hover:opacity-100 transition-opacity shadow-sm">
                  <ArrowUpRight className="w-4 h-4 text-[#855b85]" />
                </div>
              </div>

              {/* Card Details */}
              <div className="p-6 flex-1 flex flex-col justify-between">
                <div>
                  <h3 className="text-xl font-medium text-[#221722] mb-2 group-hover:text-[#855b85] transition-colors">
                    {card.title}
                  </h3>
                  <p className="text-sm text-zinc-600 font-light leading-relaxed mb-4 line-clamp-2">
                    {card.description}
                  </p>
                </div>

                <div className="pt-4 border-t border-zinc-100 flex items-center justify-between text-xs text-zinc-500 font-medium">
                  <span className="flex items-center gap-1.5 text-[#855b85]">
                    <Users className="w-3.5 h-3.5" />
                    {card.groupCount} Active Peer Groups
                  </span>
                  <span className="text-[#855b85] font-semibold group-hover:underline">
                    Explore &rarr;
                  </span>
                </div>
              </div>
            </div>
          ))}
        </div>

      </div>
    </section>
  );
};
