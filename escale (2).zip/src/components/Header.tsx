import React, { useState } from 'react';
import { ChevronDown, Menu, X, HeartHandshake, HelpCircle, ShieldAlert, Sparkles, MessageCircleHeart } from 'lucide-react';

interface HeaderProps {
  onGoHome: () => void;
  onOpenQuiz: () => void;
  onOpenTalk: () => void;
  onOpenCrisis: () => void;
  onOpenHowItWorks: () => void;
  onOpenAbout: () => void;
  onOpenContact?: () => void;
  onOpenTerms?: () => void;
  onOpenPrivacy?: () => void;
  onOpenRegister?: () => void;
  onScrollToBrowse: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  onGoHome,
  onOpenQuiz,
  onOpenTalk,
  onOpenCrisis,
  onOpenHowItWorks,
  onOpenAbout,
  onOpenContact,
  onOpenTerms,
  onOpenPrivacy,
  onOpenRegister,
  onScrollToBrowse,
}) => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [aboutDropdownOpen, setAboutDropdownOpen] = useState(false);

  return (
    <header className="bg-[#855b85] text-white sticky top-0 z-40 shadow-sm border-b border-white/10">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-10 h-20 flex items-center justify-between">
        
        {/* Brand Logo */}
        <div 
          onClick={onGoHome}
          className="flex items-center gap-2 cursor-pointer group select-none"
        >
          <span className="font-logo text-4xl text-white tracking-wide transition-transform group-hover:scale-105 inline-block">
            escale
          </span>
        </div>

        {/* Desktop Navigation */}
        <nav className="hidden md:flex items-center space-x-6 lg:space-x-8 text-[15px] font-medium">
          <button 
            onClick={onScrollToBrowse}
            className="hover:text-white/80 transition-colors cursor-pointer py-2"
          >
            Find support
          </button>

          <button 
            onClick={onOpenHowItWorks}
            className="hover:text-white/80 transition-colors cursor-pointer py-2"
          >
            How it works
          </button>

          <button 
            onClick={onOpenCrisis}
            className="hover:text-white/80 transition-colors cursor-pointer py-2 text-white flex items-center gap-1.5"
          >
            <ShieldAlert className="w-4 h-4 text-white/90" />
            Crisis help
          </button>

          {/* About Dropdown */}
          <div className="relative">
            <button 
              onClick={() => setAboutDropdownOpen(!aboutDropdownOpen)}
              onBlur={() => setTimeout(() => setAboutDropdownOpen(false), 200)}
              className="flex items-center gap-1 hover:text-white/80 transition-colors cursor-pointer py-2"
            >
              About
              <ChevronDown className={`w-4 h-4 transition-transform duration-200 ${aboutDropdownOpen ? 'rotate-180' : ''}`} />
            </button>

            {aboutDropdownOpen && (
              <div className="absolute top-full right-0 mt-2 w-60 bg-white text-zinc-800 rounded-2xl shadow-xl py-2 border border-zinc-100 z-50 animate-in fade-in slide-in-from-top-2 duration-200">
                <button
                  onClick={() => { setAboutDropdownOpen(false); onOpenAbout(); }}
                  className="w-full text-left px-4 py-2 hover:bg-zinc-50 flex items-center gap-2.5 text-sm font-medium text-zinc-700 cursor-pointer"
                >
                  <HeartHandshake className="w-4 h-4 text-[#855b85]" />
                  Our Mission & Ethos
                </button>
                <button
                  onClick={() => { setAboutDropdownOpen(false); onOpenHowItWorks(); }}
                  className="w-full text-left px-4 py-2 hover:bg-zinc-50 flex items-center gap-2.5 text-sm font-medium text-zinc-700 cursor-pointer"
                >
                  <HelpCircle className="w-4 h-4 text-[#855b85]" />
                  Verification & Safety
                </button>
                {onOpenContact && (
                  <button
                    onClick={() => { setAboutDropdownOpen(false); onOpenContact(); }}
                    className="w-full text-left px-4 py-2 hover:bg-zinc-50 flex items-center gap-2.5 text-sm font-medium text-zinc-700 cursor-pointer"
                  >
                    <MessageCircleHeart className="w-4 h-4 text-[#855b85]" />
                    Get in Touch
                  </button>
                )}
                {onOpenRegister && (
                  <button
                    onClick={() => { setAboutDropdownOpen(false); onOpenRegister(); }}
                    className="w-full text-left px-4 py-2 hover:bg-zinc-50 flex items-center gap-2.5 text-sm font-medium text-zinc-700 cursor-pointer"
                  >
                    <Sparkles className="w-4 h-4 text-[#855b85]" />
                    Register a Resource
                  </button>
                )}
              </div>
            )}
          </div>

          {/* Action Buttons */}
          <div className="flex items-center gap-3 pl-2">
            <button
              onClick={onOpenTalk}
              className="px-5 py-2 rounded-full border border-white/40 hover:border-white text-white font-medium hover:bg-white/10 transition-all cursor-pointer text-sm"
            >
              Talk
            </button>

            <button
              onClick={onOpenQuiz}
              className="px-6 py-2 rounded-full bg-white text-[#2d1b2d] font-semibold hover:bg-white/90 transition-all transform hover:scale-[1.02] active:scale-[0.98] shadow-sm cursor-pointer text-sm"
            >
              Quiz
            </button>
          </div>
        </nav>

        {/* Mobile Hamburger Button */}
        <div className="flex items-center md:hidden gap-3">
          <button
            onClick={onOpenQuiz}
            className="px-4 py-1.5 rounded-full bg-white text-[#2d1b2d] font-semibold text-xs"
          >
            Quiz
          </button>
          <button
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="p-2 text-white hover:bg-white/10 rounded-lg transition-colors"
            aria-label="Toggle navigation"
          >
            {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>
      </div>

      {/* Mobile Drawer */}
      {mobileMenuOpen && (
        <div className="md:hidden bg-[#784d78] border-t border-white/10 px-6 py-6 space-y-4 animate-in slide-in-from-top-4">
          <button
            onClick={() => { setMobileMenuOpen(false); onScrollToBrowse(); }}
            className="block w-full text-left py-2.5 text-base font-medium text-white/90 hover:text-white"
          >
            Find support
          </button>
          <button
            onClick={() => { setMobileMenuOpen(false); onOpenHowItWorks(); }}
            className="block w-full text-left py-2.5 text-base font-medium text-white/90 hover:text-white"
          >
            How it works
          </button>
          <button
            onClick={() => { setMobileMenuOpen(false); onOpenCrisis(); }}
            className="block w-full text-left py-2.5 text-base font-medium text-white/90 hover:text-white flex items-center gap-2"
          >
            <ShieldAlert className="w-4 h-4 text-white/90" />
            Crisis help
          </button>
          <button
            onClick={() => { setMobileMenuOpen(false); onOpenAbout(); }}
            className="block w-full text-left py-2.5 text-base font-medium text-white/90 hover:text-white"
          >
            About Escale
          </button>

          <div className="pt-4 border-t border-white/10 flex flex-col gap-3">
            <button
              onClick={() => { setMobileMenuOpen(false); onOpenTalk(); }}
              className="w-full py-3 rounded-full border border-white/40 text-center text-white font-medium hover:bg-white/10"
            >
              Talk to someone
            </button>
            <button
              onClick={() => { setMobileMenuOpen(false); onOpenQuiz(); }}
              className="w-full py-3 rounded-full bg-white text-[#2d1b2d] font-semibold text-center shadow-md"
            >
              Take the matching quiz
            </button>
          </div>
        </div>
      )}
    </header>
  );
};
