import React from 'react';
import { Facebook, Instagram, Linkedin, Twitter, Youtube, ShieldCheck } from 'lucide-react';

interface FooterProps {
  onGoHome?: () => void;
  onOpenQuiz: () => void;
  onOpenTalk: () => void;
  onOpenCrisis: () => void;
  onOpenHowItWorks: () => void;
  onOpenAbout: () => void;
  onOpenContact?: () => void;
  onOpenTerms?: () => void;
  onOpenPrivacy?: () => void;
  onOpenRegister?: () => void;
}

export const Footer: React.FC<FooterProps> = ({
  onGoHome,
  onOpenQuiz,
  onOpenTalk,
  onOpenCrisis,
  onOpenHowItWorks,
  onOpenAbout,
  onOpenContact,
  onOpenTerms,
  onOpenPrivacy,
  onOpenRegister,
}) => {
  return (
    <footer className="bg-[#1c181d] text-[#e0d6dd] rounded-t-[32px] pt-14 pb-10 px-6 sm:px-10 lg:px-16 mt-6">
      <div className="max-w-7xl mx-auto space-y-12">
        
        {/* Top Grid Section */}
        <div className="grid grid-cols-1 md:grid-cols-12 gap-10 pb-12 border-b border-white/10">
          
          {/* Brand & Address Column (5 Columns) */}
          <div className="md:col-span-5 space-y-4">
            <span 
              onClick={onGoHome}
              className="font-logo text-4xl text-white tracking-wide block cursor-pointer hover:opacity-90 transition-opacity"
            >
              escale
            </span>
            <p className="text-xs sm:text-sm text-[#b8aeb7] font-light leading-relaxed max-w-sm">
              Level 1, 12 Sample St, Sydney NSW 2000
            </p>
            <div className="text-xs sm:text-sm text-[#b8aeb7] space-y-1 pt-1 font-light">
              <p>1800 123 4567</p>
              <p>hello@joinescale.com</p>
            </div>

            {/* Social Icons */}
            <div className="flex items-center gap-4 pt-2 text-[#e0d6dd]">
              <a href="#facebook" className="p-2 rounded-full hover:bg-white/10 transition-colors" aria-label="Facebook">
                <Facebook className="w-4 h-4" />
              </a>
              <a href="#instagram" className="p-2 rounded-full hover:bg-white/10 transition-colors" aria-label="Instagram">
                <Instagram className="w-4 h-4" />
              </a>
              <a href="#twitter" className="p-2 rounded-full hover:bg-white/10 transition-colors" aria-label="Twitter">
                <Twitter className="w-4 h-4" />
              </a>
              <a href="#linkedin" className="p-2 rounded-full hover:bg-white/10 transition-colors" aria-label="LinkedIn">
                <Linkedin className="w-4 h-4" />
              </a>
              <a href="#youtube" className="p-2 rounded-full hover:bg-white/10 transition-colors" aria-label="YouTube">
                <Youtube className="w-4 h-4" />
              </a>
            </div>
          </div>

          {/* Navigation Links Columns (7 Columns) */}
          <div className="md:col-span-7 grid grid-cols-1 sm:grid-cols-2 gap-8 text-xs sm:text-sm">
            
            {/* Col 1 */}
            <div className="space-y-3">
              <ul className="space-y-2.5 text-[#d4c8d3]">
                <li>
                  <button onClick={onGoHome} className="hover:text-white transition-colors cursor-pointer text-left">Home</button>
                </li>
                <li>
                  <button onClick={onOpenQuiz} className="hover:text-white transition-colors cursor-pointer text-left">
                    Start quiz
                  </button>
                </li>
                <li>
                  <button onClick={onOpenTalk} className="hover:text-white transition-colors cursor-pointer text-left">
                    Peer support
                  </button>
                </li>
                <li>
                  <button onClick={onOpenCrisis} className="hover:text-white transition-colors cursor-pointer text-left">
                    Crisis help
                  </button>
                </li>
                <li>
                  <button onClick={onOpenAbout} className="hover:text-white transition-colors cursor-pointer text-left">
                    About us
                  </button>
                </li>
              </ul>
            </div>

            {/* Col 2 */}
            <div className="space-y-3">
              <ul className="space-y-2.5 text-[#d4c8d3]">
                <li>
                  <button onClick={onOpenRegister || onOpenHowItWorks} className="hover:text-white transition-colors cursor-pointer text-left">
                    Register resource
                  </button>
                </li>
                <li>
                  <button onClick={onOpenContact || onOpenTalk} className="hover:text-white transition-colors cursor-pointer text-left">
                    Contact
                  </button>
                </li>
                <li>
                  <button onClick={onOpenPrivacy || onOpenAbout} className="hover:text-white transition-colors cursor-pointer text-left">
                    Privacy policy
                  </button>
                </li>
                <li>
                  <button onClick={onOpenTerms || onOpenHowItWorks} className="hover:text-white transition-colors cursor-pointer text-left">
                    Terms of service
                  </button>
                </li>
              </ul>
            </div>

          </div>

        </div>

        {/* Bottom copyright row */}
        <div className="flex flex-col sm:flex-row items-center justify-between text-xs text-[#9c909b] gap-4 font-light">
          <p>© 2026 escale. All rights reserved.</p>
          <div className="flex items-center gap-6">
            <button onClick={onOpenPrivacy || onOpenAbout} className="hover:text-white transition-colors cursor-pointer">Privacy policy</button>
            <button onClick={onOpenTerms || onOpenHowItWorks} className="hover:text-white transition-colors cursor-pointer">Terms of service</button>
          </div>
        </div>

      </div>
    </footer>
  );
};
