import React from 'react';
import { PeerGroup } from '../types';
import { Calendar, MapPin, Users, CheckCircle2, ShieldCheck, ArrowRight } from 'lucide-react';

interface PeerGroupGridProps {
  groups: PeerGroup[];
  onSelectGroup: (group: PeerGroup) => void;
  selectedCategoryName?: string;
  onResetFilters: () => void;
}

export const PeerGroupGrid: React.FC<PeerGroupGridProps> = ({
  groups,
  onSelectGroup,
  selectedCategoryName,
  onResetFilters,
}) => {
  return (
    <section className="bg-white py-16 px-4 sm:px-6 lg:px-10 border-t border-purple-100">
      <div className="max-w-7xl mx-auto">
        
        {/* Section Title */}
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-10 pb-4 border-b border-zinc-100 gap-4">
          <div>
            <div className="flex items-center gap-2 mb-2">
              <span className="text-xs uppercase font-bold tracking-wider text-[#855b85] bg-purple-50 px-3 py-1 rounded-full">
                Active Circles & Resources
              </span>
              {selectedCategoryName && (
                <span className="text-xs text-zinc-500 font-medium">
                  &bull; Filtered by: <strong className="text-zinc-800">{selectedCategoryName}</strong>
                </span>
              )}
            </div>
            <h2 className="text-3xl sm:text-4xl font-normal text-[#271b27]">
              Verified Peer Communities
            </h2>
          </div>

          <div className="text-sm text-zinc-500 flex items-center gap-3">
            <span>Showing {groups.length} active listings</span>
            {selectedCategoryName && (
              <button
                onClick={onResetFilters}
                className="text-xs text-[#855b85] hover:underline font-semibold cursor-pointer"
              >
                Clear Filters
              </button>
            )}
          </div>
        </div>

        {groups.length === 0 ? (
          /* Empty state */
          <div className="bg-purple-50/50 rounded-3xl p-12 text-center max-w-xl mx-auto my-8 border border-purple-100">
            <ShieldCheck className="w-12 h-12 text-[#855b85] mx-auto mb-4" />
            <h3 className="text-xl font-medium text-zinc-800 mb-2">No exact match found</h3>
            <p className="text-sm text-zinc-600 mb-6 font-light">
              Try adjusting your search terms or exploring all peer support categories.
            </p>
            <button
              onClick={onResetFilters}
              className="px-6 py-2.5 rounded-full bg-[#855b85] text-white font-medium hover:bg-[#734a73] transition cursor-pointer text-sm shadow-sm"
            >
              Show All Peer Groups
            </button>
          </div>
        ) : (
          /* Grid of Peer Groups */
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {groups.map((group) => (
              <div
                key={group.id}
                onClick={() => onSelectGroup(group)}
                className="bg-zinc-50/80 rounded-[28px] overflow-hidden border border-zinc-200/80 hover:border-purple-300 shadow-xs hover:shadow-lg transition-all duration-300 flex flex-col justify-between group cursor-pointer"
              >
                <div>
                  {/* Top Image Banner */}
                  <div className="relative h-48 bg-zinc-200 overflow-hidden">
                    <img
                      src={group.image}
                      alt={group.title}
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                      referrerPolicy="no-referrer"
                    />

                    <div className="absolute top-3 left-3 bg-emerald-950/80 backdrop-blur-md text-emerald-300 text-xs font-semibold px-3 py-1 rounded-full flex items-center gap-1.5 border border-emerald-500/30">
                      <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                      <span>Verified {group.verifiedDate}</span>
                    </div>

                    <div className="absolute top-3 right-3 bg-black/60 backdrop-blur-md text-white text-xs px-3 py-1 rounded-full">
                      {group.format}
                    </div>
                  </div>

                  {/* Body Content */}
                  <div className="p-6">
                    {/* Tags */}
                    <div className="flex flex-wrap gap-1.5 mb-3">
                      {group.tags.slice(0, 3).map((tag, idx) => (
                        <span
                          key={idx}
                          className="bg-purple-100/70 text-[#6a3f6a] text-[11px] font-medium px-2.5 py-0.5 rounded-full"
                        >
                          {tag}
                        </span>
                      ))}
                    </div>

                    <h3 className="text-xl font-medium text-[#251825] mb-2 group-hover:text-[#855b85] transition-colors leading-snug">
                      {group.title}
                    </h3>

                    <p className="text-xs text-zinc-600 font-light mb-4 line-clamp-2 leading-relaxed">
                      {group.subtitle}
                    </p>

                    {/* Schedule & Location */}
                    <div className="space-y-2 text-xs text-zinc-600 mb-6 bg-white p-3.5 rounded-2xl border border-zinc-100">
                      <div className="flex items-center gap-2">
                        <Calendar className="w-4 h-4 text-[#855b85] shrink-0" />
                        <span>{group.meetingSchedule}</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <MapPin className="w-4 h-4 text-[#855b85] shrink-0" />
                        <span className="truncate">{group.location}</span>
                      </div>
                    </div>

                    {/* Facilitator Info */}
                    <div className="flex items-center gap-3 pt-2">
                      <img
                        src={group.facilitator.avatar}
                        alt={group.facilitator.name}
                        className="w-9 h-9 rounded-full object-cover border border-purple-200"
                        referrerPolicy="no-referrer"
                      />
                      <div className="text-xs truncate">
                        <p className="font-semibold text-zinc-800">{group.facilitator.name}</p>
                        <p className="text-zinc-500 truncate">{group.facilitator.role}</p>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Footer Capacity & CTA */}
                <div className="px-6 py-4 bg-white border-t border-zinc-100 flex items-center justify-between">
                  <div className="flex items-center gap-1.5 text-xs text-zinc-500 font-medium">
                    <Users className="w-3.5 h-3.5 text-zinc-400" />
                    <span>{group.memberCount}/{group.maxCapacity} members</span>
                  </div>

                  <span className="text-xs font-semibold text-[#855b85] group-hover:translate-x-1 transition-transform flex items-center gap-1">
                    View Details
                    <ArrowRight className="w-3.5 h-3.5" />
                  </span>
                </div>
              </div>
            ))}
          </div>
        )}

      </div>
    </section>
  );
};
