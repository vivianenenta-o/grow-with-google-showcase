import React, { useState } from 'react';
import { QUIZ_QUESTIONS, PEER_GROUPS } from '../data/mockData';
import { PeerGroup } from '../types';
import { X, CheckCircle2, ArrowRight, RotateCcw, Sparkles, HeartHandshake, ShieldCheck } from 'lucide-react';

interface QuizModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSelectGroupMatch: (group: PeerGroup) => void;
  initialPersona?: 'myself' | 'someone' | 'work';
}

export const QuizModal: React.FC<QuizModalProps> = ({
  isOpen,
  onClose,
  onSelectGroupMatch,
  initialPersona = 'myself',
}) => {
  const [currentStep, setCurrentStep] = useState(0);
  const [selectedAnswers, setSelectedAnswers] = useState<Record<number, string>>({});
  const [isCompleted, setIsCompleted] = useState(false);

  if (!isOpen) return null;

  const currentQuestion = QUIZ_QUESTIONS[currentStep];

  const handleSelectOption = (questionId: number, tag: string) => {
    const updated = { ...selectedAnswers, [questionId]: tag };
    setSelectedAnswers(updated);

    if (currentStep < QUIZ_QUESTIONS.length - 1) {
      setCurrentStep(currentStep + 1);
    } else {
      setIsCompleted(true);
    }
  };

  const resetQuiz = () => {
    setCurrentStep(0);
    setSelectedAnswers({});
    setIsCompleted(false);
  };

  // Find matched groups based on selected tags
  const matchedGroups = PEER_GROUPS.filter(group => {
    const chosenDomainTag = selectedAnswers[2]; // domain tag
    const chosenFormatTag = selectedAnswers[3]; // format tag

    if (chosenDomainTag && group.category === chosenDomainTag) return true;
    if (chosenFormatTag && group.format.includes(chosenFormatTag)) return true;
    return true; // default fallback match
  }).slice(0, 3);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="bg-white w-full max-w-2xl rounded-[32px] shadow-2xl overflow-hidden border border-purple-100 flex flex-col max-h-[90vh]">
        
        {/* Header */}
        <div className="bg-[#855b85] text-white px-6 py-5 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Sparkles className="w-5 h-5 text-purple-200" />
            <span className="font-semibold text-base tracking-wide">Escale Peer Matcher</span>
            <span className="text-xs bg-white/20 text-white px-2.5 py-0.5 rounded-full capitalize font-medium ml-1">
              For {initialPersona}
            </span>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 rounded-full hover:bg-white/20 text-white transition-colors cursor-pointer"
            aria-label="Close modal"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Progress Bar */}
        {!isCompleted && (
          <div className="w-full bg-purple-100 h-1.5">
            <div 
              className="bg-[#855b85] h-1.5 transition-all duration-300"
              style={{ width: `${((currentStep + 1) / QUIZ_QUESTIONS.length) * 100}%` }}
            />
          </div>
        )}

        {/* Content Body */}
        <div className="p-6 sm:p-8 overflow-y-auto">
          {!isCompleted ? (
            <div>
              <div className="mb-6">
                <span className="text-xs font-bold uppercase text-[#855b85] tracking-wider block mb-1">
                  Question {currentStep + 1} of {QUIZ_QUESTIONS.length}
                </span>
                <h3 className="text-2xl font-normal text-zinc-900 mb-2">
                  {currentQuestion.question}
                </h3>
                <p className="text-sm text-zinc-500 font-light">
                  {currentQuestion.subtitle}
                </p>
              </div>

              {/* Options List */}
              <div className="space-y-3 mb-8">
                {currentQuestion.options.map((option, idx) => {
                  const isSelected = selectedAnswers[currentQuestion.id] === option.tag;
                  return (
                    <button
                      key={idx}
                      onClick={() => handleSelectOption(currentQuestion.id, option.tag)}
                      className={`w-full text-left p-4 sm:p-5 rounded-2xl border transition-all cursor-pointer flex items-start gap-4 ${
                        isSelected
                          ? 'border-[#855b85] bg-purple-50/70 shadow-xs'
                          : 'border-zinc-200 hover:border-purple-300 hover:bg-zinc-50'
                      }`}
                    >
                      <div className={`w-5 h-5 rounded-full border flex items-center justify-center shrink-0 mt-0.5 ${
                        isSelected ? 'border-[#855b85] bg-[#855b85] text-white' : 'border-zinc-300'
                      }`}>
                        {isSelected && <CheckCircle2 className="w-3.5 h-3.5" />}
                      </div>

                      <div>
                        <h4 className="font-medium text-zinc-900 text-base mb-1">
                          {option.label}
                        </h4>
                        <p className="text-xs text-zinc-600 font-light leading-relaxed">
                          {option.description}
                        </p>
                      </div>
                    </button>
                  );
                })}
              </div>

              {/* Back Button */}
              {currentStep > 0 && (
                <button
                  onClick={() => setCurrentStep(currentStep - 1)}
                  className="text-xs text-zinc-500 hover:text-zinc-800 font-medium cursor-pointer"
                >
                  &larr; Previous Question
                </button>
              )}
            </div>
          ) : (
            /* Results Screen */
            <div>
              <div className="text-center max-w-md mx-auto mb-8">
                <div className="w-14 h-14 rounded-full bg-emerald-100 text-emerald-700 mx-auto flex items-center justify-center mb-4">
                  <ShieldCheck className="w-8 h-8" />
                </div>
                <h3 className="text-2xl font-medium text-zinc-900 mb-2">
                  Your Custom Support Matches
                </h3>
                <p className="text-sm text-zinc-600 font-light leading-relaxed">
                  Based on your responses, we've identified 3 verified peer circles with kindred facilitators and active openings.
                </p>
              </div>

              {/* Matched Cards */}
              <div className="space-y-4 mb-8">
                {matchedGroups.map((group) => (
                  <div
                    key={group.id}
                    onClick={() => {
                      onClose();
                      onSelectGroupMatch(group);
                    }}
                    className="p-5 rounded-2xl border border-purple-100 bg-purple-50/40 hover:bg-purple-100/50 hover:border-purple-300 transition cursor-pointer flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 group"
                  >
                    <div className="flex items-center gap-4">
                      <img
                        src={group.image}
                        alt={group.title}
                        className="w-16 h-16 rounded-xl object-cover shrink-0"
                        referrerPolicy="no-referrer"
                      />
                      <div>
                        <div className="flex items-center gap-2 mb-1">
                          <span className="text-[10px] uppercase font-bold text-[#855b85] bg-white px-2 py-0.5 rounded-full border border-purple-200">
                            {group.format}
                          </span>
                          <span className="text-xs text-emerald-700 font-medium flex items-center gap-1">
                            <CheckCircle2 className="w-3 h-3" /> 98% Match
                          </span>
                        </div>
                        <h4 className="font-semibold text-zinc-900 text-base group-hover:text-[#855b85]">
                          {group.title}
                        </h4>
                        <p className="text-xs text-zinc-500 font-light">
                          {group.meetingSchedule} &bull; Facilitated by {group.facilitator.name}
                        </p>
                      </div>
                    </div>

                    <button className="px-4 py-2 rounded-full bg-[#855b85] text-white text-xs font-medium hover:bg-[#734a73] shrink-0 flex items-center gap-1 group-hover:translate-x-1 transition-transform">
                      View Group <ArrowRight className="w-3 h-3" />
                    </button>
                  </div>
                ))}
              </div>

              <div className="flex items-center justify-between pt-4 border-t border-zinc-100">
                <button
                  onClick={resetQuiz}
                  className="text-xs text-zinc-500 hover:text-zinc-800 flex items-center gap-1.5 font-medium cursor-pointer"
                >
                  <RotateCcw className="w-3.5 h-3.5" /> Retake Assessment
                </button>

                <button
                  onClick={onClose}
                  className="px-6 py-2.5 rounded-full bg-zinc-900 text-white text-xs font-semibold hover:bg-zinc-800 cursor-pointer"
                >
                  Close & Explore All Listings
                </button>
              </div>
            </div>
          )}
        </div>

      </div>
    </div>
  );
};
