import React, { useState } from 'react';
import { PeerGroup } from '../types';
import { X, Calendar, MapPin, Users, CheckCircle2, ShieldCheck, Clock, UserCheck, Heart, Sparkles } from 'lucide-react';

interface GroupDetailModalProps {
  group: PeerGroup | null;
  onClose: () => void;
}

export const GroupDetailModal: React.FC<GroupDetailModalProps> = ({ group, onClose }) => {
  const [joined, setJoined] = useState(false);
  const [userEmail, setUserEmail] = useState('');
  const [userName, setUserName] = useState('');
  const [selectedDate, setSelectedDate] = useState<string>('');

  if (!group) return null;

  const handleRSVP = (e: React.FormEvent) => {
    e.preventDefault();
    if (!userName || !userEmail) return;
    setJoined(true);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="bg-white w-full max-w-3xl rounded-[36px] shadow-2xl overflow-hidden border border-purple-100 flex flex-col max-h-[92vh]">
        
        {/* Banner with image */}
        <div className="relative h-56 sm:h-64 bg-zinc-900 shrink-0">
          <img
            src={group.image}
            alt={group.title}
            className="w-full h-full object-cover opacity-85"
            referrerPolicy="no-referrer"
          />

          <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/30 to-transparent" />

          {/* Close Button */}
          <button
            onClick={onClose}
            className="absolute top-4 right-4 p-2 rounded-full bg-black/50 hover:bg-black/70 text-white backdrop-blur-md transition cursor-pointer"
            aria-label="Close details"
          >
            <X className="w-5 h-5" />
          </button>

          {/* Header Badges */}
          <div className="absolute bottom-6 left-6 right-6 text-white">
            <div className="flex flex-wrap items-center gap-2 mb-2">
              <span className="bg-emerald-500/90 text-white text-xs font-semibold px-3 py-1 rounded-full flex items-center gap-1.5 backdrop-blur-md">
                <CheckCircle2 className="w-3.5 h-3.5" /> Verified {group.verifiedDate}
              </span>
              <span className="bg-white/20 text-white text-xs font-medium px-3 py-1 rounded-full backdrop-blur-md">
                {group.format}
              </span>
            </div>

            <h2 className="text-2xl sm:text-3xl font-normal tracking-tight text-white">
              {group.title}
            </h2>
          </div>
        </div>

        {/* Modal Body */}
        <div className="p-6 sm:p-8 overflow-y-auto space-y-6">
          
          {/* Subtitle & Description */}
          <div>
            <p className="text-base text-zinc-700 font-medium mb-3">
              {group.subtitle}
            </p>
            <p className="text-sm text-zinc-600 font-light leading-relaxed">
              {group.description}
            </p>
          </div>

          {/* Quick Details Grid */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 bg-purple-50/60 p-4 rounded-2xl border border-purple-100">
            <div className="flex items-center gap-3">
              <Calendar className="w-5 h-5 text-[#855b85] shrink-0" />
              <div>
                <p className="text-[10px] font-bold uppercase text-zinc-400">Schedule</p>
                <p className="text-xs font-semibold text-zinc-800">{group.meetingSchedule}</p>
              </div>
            </div>

            <div className="flex items-center gap-3">
              <MapPin className="w-5 h-5 text-[#855b85] shrink-0" />
              <div>
                <p className="text-[10px] font-bold uppercase text-zinc-400">Location</p>
                <p className="text-xs font-semibold text-zinc-800 truncate">{group.location}</p>
              </div>
            </div>

            <div className="flex items-center gap-3">
              <Users className="w-5 h-5 text-[#855b85] shrink-0" />
              <div>
                <p className="text-[10px] font-bold uppercase text-zinc-400">Circle Size</p>
                <p className="text-xs font-semibold text-zinc-800">{group.memberCount} of {group.maxCapacity} seats filled</p>
              </div>
            </div>
          </div>

          {/* Facilitator Card */}
          <div className="border border-zinc-200 rounded-2xl p-5 bg-white space-y-3">
            <div className="flex items-center gap-2 text-xs font-bold uppercase text-[#855b85] tracking-wider">
              <UserCheck className="w-4 h-4" /> Circle Facilitator
            </div>

            <div className="flex items-start gap-4">
              <img
                src={group.facilitator.avatar}
                alt={group.facilitator.name}
                className="w-14 h-14 rounded-full object-cover border-2 border-purple-200 shrink-0"
                referrerPolicy="no-referrer"
              />
              <div>
                <h4 className="font-semibold text-zinc-900 text-base">{group.facilitator.name}</h4>
                <p className="text-xs font-medium text-[#855b85] mb-1">{group.facilitator.role}</p>
                <p className="text-xs text-zinc-600 font-light leading-relaxed">{group.facilitator.bio}</p>
              </div>
            </div>
          </div>

          {/* RSVP Form / Confirmation */}
          {!joined ? (
            <form onSubmit={handleRSVP} className="bg-zinc-50 p-6 rounded-2xl border border-zinc-200 space-y-4">
              <div className="flex items-center justify-between">
                <h3 className="text-lg font-medium text-zinc-900">
                  Request to Join Circle
                </h3>
                <span className="text-xs text-emerald-700 bg-emerald-100 px-2.5 py-0.5 rounded-full font-medium">
                  {group.maxCapacity - group.memberCount} Spots Available
                </span>
              </div>

              <div>
                <label className="block text-xs font-semibold text-zinc-600 mb-1">
                  Select Upcoming Session Date
                </label>
                <select
                  value={selectedDate}
                  onChange={(e) => setSelectedDate(e.target.value)}
                  className="w-full p-3 rounded-xl border border-zinc-300 bg-white text-xs text-zinc-800 focus:border-[#855b85] focus:outline-none"
                  required
                >
                  <option value="">Choose a date...</option>
                  {group.upcomingDates.map((date, idx) => (
                    <option key={idx} value={date}>{date} &bull; {group.meetingSchedule}</option>
                  ))}
                </select>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-zinc-600 mb-1">
                    Your Name (First name or alias)
                  </label>
                  <input
                    type="text"
                    value={userName}
                    onChange={(e) => setUserName(e.target.value)}
                    placeholder="e.g. Alex"
                    required
                    className="w-full p-3 rounded-xl border border-zinc-300 bg-white text-xs text-zinc-800 focus:border-[#855b85] focus:outline-none"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-zinc-600 mb-1">
                    Your Confidential Email
                  </label>
                  <input
                    type="email"
                    value={userEmail}
                    onChange={(e) => setUserEmail(e.target.value)}
                    placeholder="alex@example.com"
                    required
                    className="w-full p-3 rounded-xl border border-zinc-300 bg-white text-xs text-zinc-800 focus:border-[#855b85] focus:outline-none"
                  />
                </div>
              </div>

              <button
                type="submit"
                className="w-full py-3.5 rounded-full bg-[#855b85] text-white font-semibold text-sm hover:bg-[#734a73] transition shadow-md cursor-pointer"
              >
                Confirm Circle Reservation
              </button>

              <div className="flex items-center justify-center gap-1.5 text-[11px] text-zinc-500">
                <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
                <span>Your information is encrypted & shared only with facilitator {group.facilitator.name}</span>
              </div>
            </form>
          ) : (
            <div className="bg-emerald-50 border border-emerald-200 p-6 rounded-2xl text-center space-y-3">
              <div className="w-12 h-12 bg-emerald-100 text-emerald-700 rounded-full flex items-center justify-center mx-auto">
                <CheckCircle2 className="w-7 h-7" />
              </div>

              <h3 className="text-xl font-medium text-emerald-950">
                Spot Reserved for {userName}!
              </h3>

              <p className="text-xs text-emerald-800 font-light max-w-md mx-auto leading-relaxed">
                A calendar invitation and secure video link for <strong>{selectedDate || group.upcomingDates[0]}</strong> have been dispatched to <strong>{userEmail}</strong>.
              </p>

              <button
                onClick={onClose}
                className="px-6 py-2 rounded-full bg-emerald-800 text-white text-xs font-semibold hover:bg-emerald-900 transition cursor-pointer"
              >
                Close & Return to Browsing
              </button>
            </div>
          )}

        </div>

      </div>
    </div>
  );
};
